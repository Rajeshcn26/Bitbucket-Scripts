# Jenkins Pipeline Rewiring

After a successful migration, you may want to update any Jenkins and Groovy files in the repository and update any Jenkins UI pipelines on the server with the newly migrated repository locations. This is called a "re-wire". To re-wire a pipeline simply add a `cmd-jenkins-rewire` or `cmd-jenkins-rewire-dryrun` label to the same issue used to perform the repository migration. This will kick off the _Rewire Jenkins Pipeline_ GitHub action, which will do the following:

- Crawl the repository for Jenkins files and update the repository links and create a pull request
- Crawl the repository for Groovy files and update the repository links and create a pull request
- Scan the Jenkins server for any inline UI jobs and scripts that may reference the repository and update the repository links and the SCM Credential, if found.

## Pipeline Requirements

### App and Permissions

In order for the Jenkins and Groovy file replacement scripts to work, they need to be able to access the contents of other repositories and create pull requests. Since the repository GitHub token does not cross repository boundaries, a GitHub App will need to be create with the following permissions:

- `Contents`: Read & Write
- `Issues`: Read & Write
- `Metadata`: Read
- `Pull Requests`: Read & Write

> [!NOTE]
> These permissions are encapsulated by the Siphon GitHub App. Therefore, you do not need to create a separate, new GitHub App.

---

### Pipeline Secrets and Variables

For the UI replacement job the following secrets are needed to connect to the server and edit the jobs:

- `JENKINS_SERVER_URL` (variable)
- `JENKINS_API_USER`
- `JENKINS_API_TOKEN`
- `JENKINS_REWIRE_PREFIXES` (variable, see [here](#prefixes))

For the GitHub App the following are needed:

- `SIPHON_APP_ID` (variable)
- `SIPHON_APP_PRIVATE_KEY`

> [!NOTE]
> As mentioned before, these GitHub App secrets/variables should already exist if you have followed the setup in [README.md](../README.md).

## Pipeline Operation

### Working With Issues

The Jenkins pipeline rewire workflow gets triggered when the `cmd-jenkins-rewire` or `cmd-jenkins-rewire-dryrun` label is added to an issue. For the workflow to complete properly the issue must contain the following key/value pairs in the body contents, each on a separate line:

> [!NOTE]
> If any of the below are missing, the workflow will fail.

- `bitbucket-source-project-key: {value}`
- `bitbucket-source-repo-slug: {value}`
- `github-target-org: {value}`
- `github-target-repo-name: {value}`

As the workflow progresses, the issue will be updated with new labels indicating whether the rewire is `jenkins-rewire-in-progress`, `jenkins-rewire-success` or `jenkins-rewire-failed`. If the rewire failed, you can view the workflow logs to determine the exact reason.

---

### Dry Runs

Each of the tasks in the Jenkins rewire can be set to perform a `dry-run`. A dry run will perform all basic operations on the files or Jenkins jobs but will not make any modifications. Set the `cmd-jenkins-rewire-dryrun` label on a issue to enable the dry-run mode for all scripts in the workflow.

---

### Prefixes

The pipeline operates by parsing the issue body for source and target repository names. But this doesn't cover how the repository names are used within the Jenkins scripts. There can be different formats, such as SSH and HTTPS. Prefixes are a way to reduce redundancy and increase performance. Prefixes are a JSON structure that contains key/object values. The key being the prefix to search for and the object value being the replacement term and type. For example, the following code denotes that there are two prefixes, one SSH and the other HTTPS, to be appended to the source and target repository names.

```json
{
  "git@github.domain.com:": { "replacement": "git@github.com:", "type": "SSH" },
  "https://github.domain.com/": {
    "replacement": "https://github.com/",
    "type": "HTTPS"
  }
}
```

If we take the an example source repository of `owner1/repo` and a target repository of `owner2/repo` and use the prefixes above, the code will search for both `git@github.domain.com:owner1/repo` and `https://github.domain.com/owner1/repo` within the scripts or jobs, and replace those with the same prefix and `owner2/repo`. This value can be set in the repository settings under the variable `JENKINS_REWIRE_PREFIXES`.

---

### Task Parameters

For each Jenkins task there is a script that runs and requires certian parameters. Please reference those scripts for more details.

- [Jenkinsfile Replacement](replace_jenkinsfile_urls.rb)
- [Groovy File Replacement](replace_groovy_urls.rb)
- [Jenkins UI Job Replacement](ui_find_replace.rb)
