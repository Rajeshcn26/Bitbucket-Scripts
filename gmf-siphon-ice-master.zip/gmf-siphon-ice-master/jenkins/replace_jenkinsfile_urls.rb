# frozen_string_literal: true

#!/usr/bin/env ruby
# replace_jenkinsfile_urls.rb
# Searches for Jenkinsfile pipelines to replace old URLs with a new URL.

require 'optparse'
require 'json'
require_relative '../lib/log_manager'
require_relative '../lib/backup_manager'
require_relative '../lib/file_processor'
require_relative '../lib/pipeline_processor'
require_relative '../lib/git_helper'

# --- Default Configurations ---
LOG_FILE = File.join('logs', 'jenkinsfile_replacement_log.txt')
DEFAULT_BACKUP_DIR = 'backup/jenkinsfile'
DRY_RUN = false

def parse_options
  options = {
    prefixes: [],
    repo_path: '.',
    dry_run: false,
    quiet: false
  }

  OptionParser.new do |opts|
    opts.banner = "Usage: #{$0} [options]"
    opts.on('-b', '--backup-dir DIRECTORY', 'Directory to store backups') { |dir| options[:backup_dir] = dir }
    opts.on('-r', '--repo-path', 'Path to the repository') { |path| options[:repo_path] = path }
    opts.on('-p', '--prefixes JSON', 'JSON array of key-array replacement values') do |json|
      options[:prefixes] = JSON.parse(json) unless json.nil? || json.empty?
    end
    opts.on('-d', '--dry-run', 'Enable dry-run mode') { options[:dry_run] = true }
    opts.on('-q', '--quiet', 'Suppress console output') { options[:quiet] = true }
    opts.on('-h', '--help', 'Show this help message') { puts opts; exit }
  end.parse!

  options
end

def initialize_utilities(options)
  FileUtils.mkdir_p('logs')

  logger = LogManager.new(LOG_FILE, quiet: options[:quiet])
  backup_manager = BackupManager.new(
    backup_dir: options[:backup_dir] || DEFAULT_BACKUP_DIR,
    logger: logger,
    dry_run: options[:dry_run]
  )
  return [logger, backup_manager]
end

# --- Main ---
options = parse_options()
logger, backup_manager = initialize_utilities(options)

logger.log("Starting Jenkinsfile URL replacement script", level: "INFO")
logger.log("Dry-run mode enabled", level: "INFO") if options[:dry_run]
logger.log("Backup directory: #{options[:backup_dir] || DEFAULT_BACKUP_DIR}", level: "INFO")

file_processor = FileProcessor.new(logger, backup_manager, dry_run: options[:dry_run])
updated_files = []

# --- Process files, one run for each prefix ---
prefixes = options[:prefixes].each do |original_prefix, details|
  replacement_prefix = details['replacement']
  replacement_type = details['type']

  old_url_pattern = Regexp.new(Regexp.escape("#{original_prefix}#{ARGV[0]}"), Regexp::IGNORECASE)
  new_url = "#{replacement_prefix}#{ARGV[1]}"

  # --- Process Jenkinsfiles ---
  logger.log("Starting #{replacement_type} replacement...", level: "INFO")
  jenkins_pipeline = PipelineProcessor.new(logger, file_processor, file_name: 'Jenkinsfile')
  updated_files += jenkins_pipeline.process_files(old_url_pattern, new_url)

  logger.log("Jenkinsfile #{replacement_type} replacement completed.", level: "INFO")
end

# --- Git Operations ---
if updated_files.any? && !options[:dry_run]
  git_helper = GitHelper.new(repo_path: '.', dry_run: options[:dry_run], logger: logger, pr_title: pr_title)
  git_helper.create_branch
  git_helper.commit_and_push_changes
  git_helper.create_pull_request
else
  logger.log("No files updated or dry-run mode enabled. Skipping Git operations.", level: "INFO")
end

class PipelineProcessor
  # Simplified to only find Jenkinsfiles
  def initialize(file_name: "Jenkinsfile")
    @file_name = file_name
  end # end of initialize method

  def find_files(repo_path)
    Dir.glob(File.join(repo_path, "**", @file_name))
  end # end of find_files method
end # end of PipelineProcessor class