# frozen_string_literal: true

#   Usage: script.rb [options]
#         --jenkins-server-url URL     Jenkins server URL
#         --jenkins-username USERNAME  Jenkins username
#         --jenkins-api-token TOKEN    Jenkins API token
#         --search-term TERM           Search term
#         --replacement-term TERM      Replacement term
#         --prefixes JSON              JSON array of key-value replacement pairs for prefixes
#         --scm-credential ID          SCM credential ID
#         --dry-run BOOL               Dry run mode
#     -h, --help                       Prints this help

require "jenkins_api_client"
require "nokogiri"
require "cgi"
require "optparse"
require_relative "../lib/log_manager"

# --- Default Configurations ---
LOG_FILE = File.join("logs", "jenkins_job_ui_replacement_log.txt")

def parse_options
  options = {
    jenkins_server_url: "",
    jenkins_username: "",
    jenkins_api_token: "",
    search_term: "",
    replacement_term: "",
    prefixes: [],
    scm_credential: "",
    dry_run: false
  }

  OptionParser.new do |opts|
    opts.banner = "Usage: script.rb [options]"

    opts.on("--jenkins-server-url URL", "Jenkins server URL") { |url| options[:jenkins_server_url] = url }
    opts.on("--jenkins-username USERNAME", "Jenkins username") { |username| options[:jenkins_username] = username }
    opts.on("--jenkins-api-token TOKEN", "Jenkins API token") { |token| options[:jenkins_api_token] = token }
    opts.on("--search-term TERM", "Search term") { |term| options[:search_term] = term }
    opts.on("--replacement-term TERM", "Replacement term") { |term| options[:replacement_term] = term }
    opts.on("--prefixes JSON", "JSON array of key-value replacement pairs for prefixes") do |json|
      options[:prefixes] = JSON.parse(json) unless json.nil? || json.empty?
    end
    opts.on("--scm-credential ID", "SCM credential") { |id| options[:scm_credential] = id }
    opts.on("--dry-run", "Run script in dry-run mode") { options[:dry_run] = true }
    opts.on("-h", "--help", "Prints this help") { puts opts; exit }
  end.parse!

  return options
end

def initialize_utilities(options)
  FileUtils.mkdir_p("logs")
  logger = LogManager.new(LOG_FILE, quiet: options[:quiet])
  return logger
end

def is_ui_job?(job_details)
  return !job_details.key?("definition") && job_details.key?("scm")
end

def perform_update(node, search_term, replacement_term)
  original_content = node.content
  updated_content = original_content.gsub(search_term, replacement_term)

  if original_content != updated_content
    $logger.log("Original content:\n#{original_content}", level: "DEBUG", group_header: "Original Content")
    $logger.log("Updated content:\n#{updated_content}", level: "DEBUG", group_header: "Updated Content")

    node.content = updated_content
    return true
  else
    return false
  end
end

def update_scm_url(doc, search_term, replacement_term, scm_credential)
  $logger.log("Checking SCM URL in job config", level: "DEBUG")

  scm_url_node = doc.at_xpath("//scm/userRemoteConfigs/hudson.plugins.git.UserRemoteConfig/url")
  scm_credential_node = doc.at_xpath("//scm/userRemoteConfigs/hudson.plugins.git.UserRemoteConfig/credentialsId")

  if scm_url_node && scm_url_node.content.include?(search_term)
    $logger.log("Found search term in SCM URL", level: "INFO")

    perform_update(scm_url_node, search_term, replacement_term)
    perform_update(scm_credential_node, scm_credential_node, scm_credential)

    return true;
  end

  return false
end

def update_inline_groovy_script(doc, search_term, replacement_term)
  $logger.log("Checking inline Groovy script in job config", level: "DEBUG")

  script_node = doc.at_xpath('//definition[@class="org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition"]/script')
  if script_node && script_node.content.include?(search_term)
    $logger.log("Found search term in inline Groovy script", level: "INFO")
    return perform_update(script_node, search_term, replacement_term)
  end

  return false
end

def update_inline_shell_scripts(doc, search_term, replacement_term)
  $logger.log("Checking inline shell scripts in job config", level: "DEBUG")

  doc.xpath("//builders/hudson.tasks.Shell/command").each do |shell_node|
    if shell_node.content.include?(search_term)
      $logger.log("Found search term in inline shell script", level: "INFO")
      return perform_update(shell_node, search_term, replacement_term)
    end
  end

  return false
end

def update_job_config(client, job, prefixes, search_term, replacement_term, scm_credential, dry_run)
  begin
    job_config = client.job.get_config(job[:path])
    doc = Nokogiri::XML(job_config)
    updated = false

    prefixes.each do |prefix_key, prefix_value|
      full_search_term = "#{prefix_key}#{search_term}"
      full_replacement_term = "#{prefix_value}#{replacement_term}"

      $logger.log("Checking for search term: #{full_search_term}", level: "DEBUG")

      updated |= update_scm_url(doc, full_search_term, full_replacement_term, scm_credential)
      updated |= update_inline_groovy_script(doc, full_search_term, full_replacement_term)
      updated |= update_inline_shell_scripts(doc, full_search_term, full_replacement_term)
    end

    if updated
      if dry_run
        $logger.log("Dry run: Changes for job would be:\n#{doc.to_xml}", level: "INFO")
      else
        client.job.post_config(job[:path], doc.to_xml)
        $logger.log("Job updated successfully", level: "INFO")
      end
    else
      $logger.log("No updates required for job", level: "INFO")
    end
  rescue StandardError => e
    $logger.log("Error updating job config:\n#{e.message}", level: "ERROR")
    raise "Error updating job config:\n#{e.message}"
  end
end

def fetch_and_process_jobs_recursively(client, folder_path = "", prefixes, search_term, replacement_term, scm_credential, dry_run)
  api_path = folder_path.empty? ? "/api/json" : "/job/#{folder_path}/api/json"
  response = client.api_get_request(api_path)

  response["jobs"].each do |job|
    if job["_class"] == "com.cloudbees.hudson.plugins.folder.Folder"
      nested_folder_path = folder_path.empty? ? job["name"] : "#{folder_path}/job/#{job['name']}"
      fetch_and_process_jobs_recursively(client, nested_folder_path, prefixes, search_term, replacement_term, scm_credential, dry_run)
    elsif job["_class"] == "hudson.model.FreeStyleProject"
      full_job_path = folder_path.empty? ? job["name"] : "#{folder_path}/job/#{job['name']}"
      full_job_path_url = CGI.escape(full_job_path).gsub("%2F", "/").gsub("+", "%20")

      $logger.log(" ", level: "DEFAULT")
      $logger.log("-" * full_job_path.length, level: "DEFAULT")
      $logger.log("#{full_job_path}", level: "DEFAULT")
      $logger.log("-" * full_job_path.length, level: "DEFAULT")

      job_details = client.api_get_request("/job/#{full_job_path_url}/api/json")

      if is_ui_job?(job_details)
        update_job_config(client, { name: job["name"], path: full_job_path }, prefixes, search_term, replacement_term, scm_credential, dry_run)
      end
    end
  end
end


# --- Main ---
if __FILE__ == $0
  options = parse_options
  $logger = initialize_utilities(options)

  silent_logger = Logger.new(nil)

  client = JenkinsApi::Client.new(
    server_url: options[:jenkins_server_url],
    username: options[:jenkins_username],
    password: options[:jenkins_api_token],
    logger: silent_logger
  )

  fetch_and_process_jobs_recursively(
    client,
    "",
    options[:prefixes],
    options[:search_term],
    options[:replacement_term],
    options[:scm_credential],
    options[:dry_run])
end
