require "octokit"
require_relative "../client/frozen/frozen_lib.rb"
require_relative "../lib/github_helper"

ACCESS_TOKEN = ENV["GITHUB_TOKEN"]
DEST_ORG = ENV["DEST_ORG"]
client = Octokit::Client.new(access_token: ACCESS_TOKEN)

def fetch_all_repositories(client, org)
  all_repositories = []
  page = 1
  last_count = -1
  while last_count != 0
    repos_page = client.org_repositories(org, type: "all", per_page: 100, page: page)
    last_count = repos_page.size
    all_repositories.concat(repos_page)
    page += 1
  end

  return all_repositories
end

repositories = fetch_all_repositories(client, DEST_ORG)

#   Custom properties to set
#     * bbs-source-link
#     * bbs-source-project-key
#     * bbs-source-repo
#     * bsn
#     * IaC
#     * cldbid

pull_down_repos_repo
puts "Total repositories fetched: #{repositories.size}"
total=0
repositories.each do |repo|
  repo_cust_props = repo.custom_properties || {}

  # From repo.json
  bsn = repo_cust_props["bsn"]
  cldbid = repo_cust_props["cldbid"]

  # IaC = repo_cust_props["IaC"]
  # bbs_source_link = repo_cust_props["bbs-source-link"]
  # bbs_source_project_key = repo_cust_props["bbs-source-project-key"]
  # bbs_source_repo = repo_cust_props["bbs-source-repo"]
  if bsn == "00000000" || cldbid == "0000"
    full_repo = repo.full_name
    gh_repo_name = full_repo.split("/").first
    gh_org_name = full_repo.split("/").last
    bb_repo_name = repo.name.split(".").last
    bb_proj_name = repo.name.split(".").first

    metadata = get_cldbid_and_bsn(bb_proj_name, bb_repo_name)
    if metadata != nil

      puts "--------------------------------"
      puts "Processing repository: #{full_repo}"
      if bsn == "00000000"
        bsn = metadata["BSN"]
        set_github_custom_property(gh_repo_name, gh_org_name, "bsn", bsn)
      end

      if cldbid == "0000"
        cldbid = metadata["CLDBID"]
        set_github_custom_property(gh_repo_name, gh_org_name, "cldbid", cldbid)
      end
      total += 1
      if total % 250 == 0
        break
      end
    end

  end

end

puts "Total repositories with missing custom properties: #{total}"
puts "Rate limit remaining: #{client.rate_limit.remaining}"
