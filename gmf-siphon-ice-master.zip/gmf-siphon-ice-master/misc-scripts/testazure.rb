require "azure/storage/blob"

# Replace with your Azure Storage connection string
connection_string = "Defau6asdfasdfasdfasdfasdfasdfasdfasdHWrSSGT"
# Parse the connection string to create a client
client = Azure::Storage::Common::Client.create_from_connection_string(connection_string)
blob_service_client = Azure::Storage::Blob::BlobService.new(client: client)

# Replace with your container and blob names
container_name = "try"
blob_name = "try2.txt"
data = "Another try"

# Create the container if it doesn't exist
begin
  blob_service_client.create_container(container_name)
rescue Azure::Core::Http::HTTPError => e
  puts "Container already exists or another error occurred: #{e.message}" unless e.message.include?("409")
end

# Upload the data to the blob
blob_service_client.create_block_blob(container_name, blob_name, data)

# Fetch and display detailed blob properties
blob_properties = blob_service_client.get_blob_properties(container_name, blob_name)
puts "Blob '#{blob_name}' written to container '#{container_name}'."
puts "Blob Properties:"
puts "  - Blob Type: #{blob_properties.properties[:blob_type]}" # Blob type (e.g., BlockBlob)
puts "  - Content Length: #{blob_properties.properties[:content_length]} bytes" # Size of the blob
puts "  - Content Type: #{blob_properties.properties[:content_type]}" # MIME type of the blob
puts "  - Last Modified: #{blob_properties.properties[:last_modified]}" # Last modification timestamp
puts "  - ETag: #{blob_properties.properties[:etag]}" # Unique identifier for the blob version
