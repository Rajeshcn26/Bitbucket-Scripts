#!/usr/bin/env bash
set -euo pipefail

RAND_HASH=$(head /dev/urandom | tr -dc a-z0-9 | head -c4)

SOURCE_ORG="RTSQA"
SOURCE_REPO="regression.otc_rebus"
DEST_ORG="OWNER"
DEST_REPO="$SOURCE_ORG.$SOURCE_REPO_dryrun_$RAND_HASH"


git clone --no-single-branch "ssh://git@stash.OWNER.net:7999/$SOURCE_ORG/$SOURCE_REPO.git"
cd $SOURCE_REPO

git remote set-url --push origin "git@github.com:$DEST_ORG/$DEST_REPO.git"

git lfs install --local
git lfs fetch --all
git lfs checkout

git push --all origin
git push --tags origin
git lfs push --all origin
