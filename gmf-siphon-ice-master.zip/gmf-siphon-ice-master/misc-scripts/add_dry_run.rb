require "octokit"

def comment_on_issue(client, repo, issue_number, message)
  client.add_comment(repo, issue_number, message)
end

def in_progress_run_count(client, repo, workflow_name)
  runs = client.workflow_runs(repo, workflow_name, status: "in_progress")
  count = runs.total_count
  puts "In-progress runs for #{workflow_name}: #{count}"
  count
end

def add_comments_to_issues(client, repo, comment, query, max)
  results = []
  page = 1
  page_size = max

  response = client.search_issues(query, per_page: page_size, page: page)
  results.concat(response.items)

  puts "Found #{results.size} matching issues."
  return true if results.empty?

  commented=0
  results.each do |issue|
    puts "Commenting: #{issue.number} - #{issue.title}"
    comment_on_issue(client, repo, issue.number, comment)
    commented += 1

    if commented >= max
      puts "Reached the limit of #{max} comments. Stopping."
      break
    end
  end

  return false
end

if ARGV.length != 2
  puts "Usage: ruby my_script.rb comment labels"
  exit 1
end

ACCESS_TOKEN = ENV["GITHUB_TOKEN"]
REPO = ENV["SIPHON_REPO"]
client = Octokit::Client.new(access_token: ACCESS_TOKEN)
comment = ARGV[0].split("/").last
comment = "/#{comment}"
labels = ARGV[1]
query = "is:issue state:open #{labels} repo:#{REPO} "

while true
  in_progress_count = in_progress_run_count(client, REPO, "migrate-repos.yml")
  max = 10 # Maximum number of issues to comment on
  in_progress_max = max/2
  if in_progress_count <= in_progress_max
    has_wf_to_run = add_comments_to_issues(client, REPO, comment, query, max)
    if has_wf_to_run
      break
    end
  end

  minutes=1
  sleep(60 * minutes)
end
