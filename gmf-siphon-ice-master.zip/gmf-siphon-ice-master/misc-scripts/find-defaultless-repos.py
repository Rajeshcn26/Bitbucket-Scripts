import requests
import os

# Set globals (env vars mostly)
BBS_SERVER = os.environ.get("BB_SERVER_URL")
BBS_USERNAME = os.environ.get("BB_ACCT_USER")
BBS_PASSWORD = os.environ.get("BB_ACCT_PASSWORD")

# Make a request to the Bitbucket Server API using basic auth to get a list of all projects
projects = []
last_page = False
start = 0
limit = 50
while not last_page:
    response = requests.get(f"{BBS_SERVER}/rest/api/1.0/projects?start={start}&limit={limit}", auth=(BBS_USERNAME, BBS_PASSWORD))
    projects += [project['key'] for project in response.json()["values"]]
    last_page = response.json()["isLastPage"]
    start += limit

# For each project...
for project in projects:
    # Get a list of all repositories in the project - this is another paged API
    repos = []
    last_page = False
    start = 0
    limit = 50
    while not last_page:
        response = requests.get(f"{BBS_SERVER}/rest/api/1.0/projects/{project}/repos?start={start}&limit={limit}", auth=(BBS_USERNAME, BBS_PASSWORD))
        repos += [repo['slug'] for repo in response.json()["values"]]
        last_page = response.json()["isLastPage"]
        start += limit
    
    # For each repo, go get the default branch...  If it doesn't have one, print the repo name.
    for repo in repos:
        response = requests.get(f"{BBS_SERVER}/rest/api/1.0/projects/{project}/repos/{repo}/branches/default", auth=(BBS_USERNAME, BBS_PASSWORD))
        if response.status_code == 404:
            print(f"{project}/{repo}")
