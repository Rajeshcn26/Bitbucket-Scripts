require "octokit"
require "date"
require "optparse"
require "io/console"

# Get the GitHub token from an environment variable
github_token = ENV["GH_PAT"]

if github_token.nil?
  puts "\n\nGitHub token is not set. Please set the GH_PAT environment variable.\n\n"
  puts "For instructions on how to manage Personal Access Tokens (PATs), please refer to the GitHub documentation:"
  puts "https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/creating-a-personal-access-token"
  puts "You can create a new token with the required scopes here:"
  puts "https://github.com/settings/tokens/new?scopes=repo,delete_repo,read:org"
  exit
end

# Initialize Octokit client
client = Octokit::Client.new(access_token: github_token)
client.auto_paginate = true

def parse_options
  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: rmReposByName.rb --org=ORG --repo-pattern=PATTERN [--list] [--execute]"

    opts.on("--org=ORG", "The organization to process") do |org|
      options[:org] = org
    end

    opts.on("--repo-pattern=PATTERN", "The repository name pattern to remove") do |pattern|
      options[:repo_pattern] = pattern
    end

    opts.on("--list", "List all repositories in the organization") do
      options[:list] = true
    end

    opts.on("--execute", "Actually remove the repositories") do
      options[:execute] = true
    end
  end.parse!

  if options[:list]
    unless options[:org]
      puts "\e[31mError: The --org option is mandatory when using --list.\e[0m"
      puts
      puts "Usage: rmReposByName.rb --org=ORG --list"
      exit
    end
  else
    unless options[:org] && options[:repo_pattern]
      puts "\e[31mError: Both --org and --repo-pattern options are mandatory.\e[0m"
      puts
      puts "Usage: rmReposByName.rb --org=ORG --repo-pattern=PATTERN [--execute]"
      exit
    end
  end

  options
end # end of parse_options

options = parse_options
org_to_process = options[:org]
repo_name_pattern_to_remove = options[:repo_pattern]

# if the --list option is used, list all repositories in the organization and exit
if options[:list]
  repos = client.org_repos(org_to_process)
  repo_names = repos.map(&:name).join(", ")
  puts repo_names
  exit
end

# Fetch all repositories from the organization
repos = client.org_repos(org_to_process)

matching_repos = repos.select { |repo| repo.name.include?(repo_name_pattern_to_remove) }
total_matching_repos = matching_repos.size

# Display repositories to be removed
matching_repos.each_with_index do |repo, index|
  puts "\e[33m[#{index}/#{total_matching_repos}] #{repo.full_name}\e[0m"
end # end of matching_repos display

if options[:execute]
  puts "\nDo you want to delete all the listed repositories? (y/n)"
  confirmation = $stdin.getch.downcase

  if confirmation == "y"
    matching_repos.each do |repo|
      client.delete_repo(repo.full_name)
      puts "\e[34m   Deleted repository: #{repo.full_name}\e[0m"
    end # end of matching_repos deletion
  end # end of confirmation
end # end of execute check
