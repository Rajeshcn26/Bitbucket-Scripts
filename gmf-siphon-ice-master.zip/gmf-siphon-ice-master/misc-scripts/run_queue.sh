
while true; do
  ruby misc-scripts/run_queue.rb 
  sleep 60
done