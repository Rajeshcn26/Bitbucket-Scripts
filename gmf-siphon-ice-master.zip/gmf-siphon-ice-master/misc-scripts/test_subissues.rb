require_relative "../lib/github_sub_issues"
require "base64"
require "logger"

logger = Logger.new($stdout)
logger.level = Logger::INFO

token = ENV["GITHUB_TOKEN"] || abort("Set GITHUB_TOKEN in your environment.")
repo_full = "OWNER/daves_test"
issue_number = 69

owner, repo = repo_full.split("/", 2)

client = GitHubSubIssueClient.new(logger, token)

puts "Fetching assignees for #{owner}/#{repo}##{issue_number}..."

assignees = client.get_issue_assignees(owner: owner, repo: repo, issue_number: issue_number)

if assignees.empty?
  puts "No assignees found."
else
  puts "Assignees:"
  assignees.each { |login| puts "  - #{login}" }
end
