#!/bin/bash
# Token is valid for 1 hour
# requires openssl, jq to be installed
#    sudo apt-get update && sudo apt-get install -y openssl jq

APP_ID="121"
INSTALLATION_ID="64"
PRIVATE_KEY_PATH="private-key.pem"

NOW=$(date +%s)
EXP=$((NOW + 600))

HEADER='{"alg":"RS256","typ":"JWT"}'
PAYLOAD=$(printf '{"iat":%s,"exp":%s,"iss":%s}' "$NOW" "$EXP" "$APP_ID")

B64_HEADER=$(echo -n "$HEADER" | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')
B64_PAYLOAD=$(echo -n "$PAYLOAD" | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')

SIGNATURE=$(printf '%s.%s' "$B64_HEADER" "$B64_PAYLOAD" | openssl dgst -sha256 -sign "$PRIVATE_KEY_PATH" | openssl base64 -e -A | tr '+/' '-_' | tr -d '=')

JWT="$B64_HEADER.$B64_PAYLOAD.$SIGNATURE"

TOKEN=$(curl -s -X POST \
  -H "Authorization: Bearer $JWT" \
  -H "Accept: application/vnd.github+json" \
  https://api.github.com/app/installations/$INSTALLATION_ID/access_tokens | jq -r '.token')

echo "GitHub Installation Token: $TOKEN"
 