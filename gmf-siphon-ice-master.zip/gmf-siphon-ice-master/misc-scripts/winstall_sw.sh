# note winget may not run from bash, may have to run it in powershell

winget install jqlang.jq
winget install --id Microsoft.VisualStudioCode -e --scope user

# Install Ruby
winget install --id  winget search RubyInstallerTeam.Ruby -e --scope user # havent tested this yet

gem update --system 3.6.7
gem install octokit
gem install csv
gem install rubyXL
gem install json
gem install optparse
gem install fileutils
gem install base64
gem install net-http
gem install uri
gem install rufus-scheduler
gem install concurrent
gem install tzinfo-data


# GitHub CLI.. https://github.com/cli/cli/releases/download/v2.69.0/gh_2.69.0_windows_amd64.zip (unzip, find the exe and put it in your path somewhere…

gh extension install github/gh-gei
gh extension install github/gh-bbs2gh
gh extension install github/gh-ado2gh

# Download https://github.com/git-for-windows/git/releases/download/v2.49.0.windows.1/PortableGit-2.49.0-64-bit.7z.exe  -- I installed to C:\utils\PortableGit so I set my path to C:\utils\PortableGit\bin