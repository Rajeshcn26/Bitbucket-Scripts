#!/bin/bash

main(){
  repo=$1 # org/repo
  total=0

  gh api repos/$repo/actions/runs --paginate \
    --jq '.workflow_runs[] | select(.conclusion=="skipped") | .id' |
  while read run_id; do
    # echo "Deleting skipped workflow run with ID: $run_id"
    gh api --method DELETE repos/$repo/actions/runs/$run_id
    total=$((total + 1)) # increment total by 1
    if (( total % 50 == 0 )); then
      echo "Total deleted so far: $total"
    fi 
  done 
  echo "Total deleted: $total"
}

i=0
while true; do
  i=$((i + 1))
  echo "Starting iteration $i"
  main "$@"
  sleep 60
done 