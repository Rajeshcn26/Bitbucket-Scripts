require "net/http"
require "json"
require "uri"

# -------- CONFIG --------
token = ENV["GITHUB_TOKEN"] # Set this as an environment variable for security
repo_owner = "OWNER"
repo_name = "xsiphon"
project_id = "PROJ_ID"
# ------------------------

def graphql_query(query, variables = {}, token:)
  uri = URI.parse("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  headers = {
    "Authorization" => "Bearer #{token}",
    "Content-Type" => "application/json",
    "Accept" => "application/vnd.github+json"
  }

  request = Net::HTTP::Post.new(uri.request_uri, headers)
  request.body = JSON.dump({ query: query, variables: variables })
  response = http.request(request)
  JSON.parse(response.body)
end

# Step 1: Get all issue IDs
issue_query = <<~GRAPHQL
  query($owner: String!, $name: String!, $cursor: String) {
    repository(owner: $owner, name: $name) {
      issues(first: 100, after: $cursor) {
        nodes {
          id
          number
        }
        pageInfo {
          hasNextPage
          endCursor
        }
      }
    }
  }
GRAPHQL

issue_ids = []
cursor = nil

loop do
  result = graphql_query(issue_query, { owner: repo_owner, name: repo_name, cursor: cursor }, token: token)
  issues = result.dig("data", "repository", "issues", "nodes") || []
  issue_ids += issues.map { |i| i["id"] }

  page_info = result.dig("data", "repository", "issues", "pageInfo")
  break unless page_info["hasNextPage"]

  cursor = page_info["endCursor"]
end

puts "Found #{issue_ids.size} issues."

add_to_project_mutation = <<~GRAPHQL
  mutation($projectId: ID!, $contentId: ID!) {
    addProjectV2ItemById(input: {projectId: $projectId, contentId: $contentId}) {
      item {
        id
      }
    }
  }
GRAPHQL

issue_details_query = <<~GRAPHQL
  query($owner: String!, $name: String!, $cursor: String) {
    repository(owner: $owner, name: $name) {
      issues(first: 100, after: $cursor) {
        nodes {
          id
          number
          title
        }
        pageInfo {
          hasNextPage
          endCursor
        }
      }
    }
  }
GRAPHQL

filtered_issue_ids = []
cursor = nil

loop do
  result = graphql_query(issue_details_query, { owner: repo_owner, name: repo_name, cursor: cursor }, token: token)
  issues = result.dig("data", "repository", "issues", "nodes") || []
  issues.each do |issue|
    title = issue["title"] || ""
    unless title.include?("Dryrun Failure") || title.include?("Migrate Failure")
      filtered_issue_ids << issue["id"]
    end
  end

  page_info = result.dig("data", "repository", "issues", "pageInfo")
  break unless page_info["hasNextPage"]

  cursor = page_info["endCursor"]
end
puts "Filtered to #{filtered_issue_ids.size} issues (excluding 'Dryrun Failure' and 'Migrate Failure')."

issue_ids.each do |issue_id|
  response = graphql_query(add_to_project_mutation, { projectId: project_id, contentId: issue_id }, token: token)
  item_id = response.dig("data", "addProjectV2ItemById", "item", "id")
  # Only add open issues (filtered_issue_ids contains only open issues)
  if filtered_issue_ids.include?(issue_id)
    if item_id
      puts "Added issue #{issue_id} to project as item #{item_id}"
    else
      puts "Failed to add issue #{issue_id}: #{response}"
    end
  else
    puts "Skipping closed issue #{issue_id}"
  end
end
