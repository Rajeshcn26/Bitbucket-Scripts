require "fileutils"
require "json"
require "csv"
require_relative "../../lib/helpers"
require_relative "./frozen_lib"

def get_vars_from_issue(issue_body)
  project_line = issue_body.lines.find { |line| line.strip.start_with?("bitbucket-source-project-key:") }
  project_name = project_line.split(":", 2)[1].strip if project_line

  org_line = issue_body.lines.find { |line| line.strip.start_with?("github-target-org:") }
  org_name = org_line.split(":", 2)[1].strip if org_line

  [project_name, org_name]
end

def add_codeowners
  gh_repo = ENV["GH_REPO"]
  token = ENV["GH_TOKEN"]
  bb_project, github_org = get_vars_from_issue(ENV["ISSUE_BODY"])
  codeowners = get_codeowners_for_team(bb_project)

  if codeowners.nil? || codeowners.empty?
    puts "No codeowners found for the project: #{bb_project}"
    exit 0
  end

  if token.nil? || token.empty?
    puts "GitHub token is not set. Please set the GH_TOKEN environment variable."
    exit 1
  end

  repo_url = "https://#{token}@github.com/#{github_org}/#{gh_repo}.git"
  puts "repo_url: #{repo_url}"
  clone_dir = "./output/#{gh_repo}"
  system("git clone --depth 1 #{repo_url} #{clone_dir}")

  codeowners_file = "#{clone_dir}/.github/CODEOWNERS"
  FileUtils.mkdir_p(File.dirname(codeowners_file)) unless Dir.exist?(File.dirname(codeowners_file))

  File.open(codeowners_file, "w") do |file|
    codeowners.each do |codeowner|
      file.puts "* @#{codeowner}_CLD"
    end
    file.puts ".github/workflows/* @#{github_org}/recore"
  end

  system("cd #{clone_dir} && git config user.email \"#{ENV['SIPHON_APP_ID']}+#{ENV['SIPHON_APP_NAME']}[bot]@users.noreply.github.com\"")
  system("cd #{clone_dir} && git config user.name \"#{ENV['SIPHON_APP_NAME']}[bot]\"")
  system("cd #{clone_dir} && git add .github/CODEOWNERS")
  system("cd #{clone_dir} && git commit -m 'Add CODEOWNERS [skip ci]'")

  default_branch = `cd #{clone_dir} && git symbolic-ref refs/remotes/origin/HEAD`.strip.split("/").last
  system("cd #{clone_dir} && git push origin #{default_branch}")
end

add_codeowners
