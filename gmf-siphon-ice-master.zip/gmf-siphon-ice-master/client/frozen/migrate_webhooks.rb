#
#   Migrates webhooks using the links in the teams.json file. Thi sprocess is specific to CLD
#

require "octokit"
require "optparse"
require "base64"
require_relative "frozen_lib"
require_relative "../../lib/helpers"


def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def parse_arguments
  options = {}

  OptionParser.new do |opts|
    opts.on("-c", "--comment COMMENT", "The comment") do |v|
      options[:comment] = v
    end
    opts.on("-b", "--body BODY", "The body") do |v|
      options[:body] = v
    end
  end.parse!

  if options[:comment].nil? || options[:comment].empty?
    puts "Error: Issue Comment must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body'"
    abort
  end

  if options[:body].nil? || options[:body].empty?
    puts "Error: Issue Body must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body'"
    abort
  end

  options
end

def create_github_webhooks(client, gh_org, gh_repo, url, dry_run: false)
  repo_full_name = "#{gh_org}/#{gh_repo}"

  config = {
    url: url,
    content_type: "form",
    insecure_ssl: "1"
  }

  events = ["*"]
  active = !dry_run

  begin
    client.create_hook(repo_full_name, "web", config, { events: events, active: active })
    puts "Webhook created for #{repo_full_name}"
  rescue Octokit::UnprocessableEntity => e
    if e.message.include?("Hook already exists")
      puts "Hook already exists for #{repo_full_name} with URL #{config[:url]}. Skipping..."
    else
      raise e
    end
  end
end


def main
  begin
    options = parse_arguments

    comment = Base64.decode64(options[:comment])
    body = Base64.decode64(options[:body])

    migration_details = Helper.parse_issue_body(body, comment)

    is_dry_run = comment.match?(/\/dryrun/)
    project_key = migration_details[:bb_project]
    webhook = get_webhook_for_team(project_key)

    puts "Webhook for team #{project_key}: #{webhook}"

    if webhook.nil?
      puts "No webhook found for team #{project_key}."
    else
      create_github_webhooks(client, migration_details[:gh_org], migration_details[:gh_repo], webhook, dry_run: is_dry_run)
    end
  rescue StandardError => e
    puts "An error occurred: #{e.message}"
  end
end

main
