# frozen_string_literal: true

require "octokit"
require "json"
require "net/http"

GITHUB_TOKEN = ENV["GH_TOKEN"] || ENV["GITHUB_TOKEN"]
REPO = "OWNER/xsiphon"
WRONG_TARGET_ORG   = "github-target-org: OWNER"
CORRECT_TARGET_ORG = "github-target-org: OWNER"


def github_graphql_query(token, query, variables)
  uri = URI("https://api.github.com/graphql")
  req = Net::HTTP::Post.new(uri)
  req["Authorization"] = "bearer #{token}"
  req["Content-Type"] = "application/json"
  req.body = { query: query, variables: variables }.to_json

  res = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) { |http| http.request(req) }
  raise "GitHub API error: #{res.code} #{res.body}" unless res.is_a?(Net::HTTPSuccess)
  JSON.parse(res.body)
end # end of github_graphql_query

def fetch_issues_with_target_org(token, owner, repo, target_org)
  issues_with_target_org = []
  after_cursor = nil

  loop do
    query = <<~GRAPHQL
      query($owner: String!, $repo: String!, $after: String) {
        repository(owner: $owner, name: $repo) {
          issues(first: 100, states: OPEN, after: $after) {
            pageInfo {
              hasNextPage
              endCursor
            }
            nodes {
              number
              body
            }
          }
        }
      }
    GRAPHQL

    variables = { owner: owner, repo: repo, after: after_cursor }
    data = github_graphql_query(token, query, variables)
    issues = data.dig("data", "repository", "issues", "nodes") || []
    issues_with_target_org += issues.select { |issue| issue["body"] && issue["body"].include?(target_org) }.map { |issue| issue["number"] }

    page_info = data.dig("data", "repository", "issues", "pageInfo")
    break unless page_info && page_info["hasNextPage"]
    after_cursor = page_info["endCursor"]
  end

  issues_with_target_org
end # end of fetch_issues_with_target_org

def write_issue_numbers_to_file(issue_numbers, filename)
  FileUtils.mkdir_p(File.dirname(filename))
  File.open(filename, "w") do |f|
    issue_numbers.each { |num| f.puts num }
  end
end

def update_issues_target_org(token, owner, repo, issue_numbers, wrong_org, correct_org)
  octokit = Octokit::Client.new(access_token: token)
  issue_numbers.each do |issue_number|
    # Fetch the issue body
    query = <<~GRAPHQL
      query($owner: String!, $repo: String!, $number: Int!) {
        repository(owner: $owner, name: $repo) {
          issue(number: $number) {
            body
            title
          }
        }
      }
    GRAPHQL

    variables = { owner: owner, repo: repo, number: issue_number }
    data = github_graphql_query(token, query, variables)
    issue_body = data.dig("data", "repository", "issue", "body")
    issue_title = data.dig("data", "repository", "issue", "title")
    next unless issue_body && issue_body.include?(wrong_org)

    new_body = issue_body.gsub(wrong_org, correct_org)

    # PATCH /repos/{owner}/{repo}/issues/{issue_number}
    # Only send fields that should be updated; do not send nil for title
    begin
      octokit.update_issue("#{owner}/#{repo}", issue_number, issue_title, new_body)
      puts "Updated issue ##{issue_number}: replaced '#{wrong_org}' with '#{correct_org}'"
    rescue Octokit::UnprocessableEntity => e
      puts "Failed to update issue ##{issue_number}: #{e.message}"
    end
  end
end

def main
  if GITHUB_TOKEN.nil? || REPO.nil?
    puts "Set GH_TOKEN (or GITHUB_TOKEN) and REPO (owner/repo) in the environment."
    exit 1
  end

  owner, repo = REPO.split("/", 2)
  output_file = "output/issues_with_OWNER.txt"

  if File.exist?(output_file)
    puts "File #{output_file} exists. Processing issues to update target org..."
    issue_numbers = File.readlines(output_file).map(&:strip).reject(&:empty?).map(&:to_i)
    update_issues_target_org(GITHUB_TOKEN, owner, repo, issue_numbers, WRONG_TARGET_ORG, CORRECT_TARGET_ORG)
    puts "Processing complete."
    return
  end

  issues_with_target_org = fetch_issues_with_target_org(GITHUB_TOKEN, owner, repo, WRONG_TARGET_ORG)
  write_issue_numbers_to_file(issues_with_target_org, output_file)

  puts "Found #{issues_with_target_org.size} issues with '#{WRONG_TARGET_ORG}' in the body."
  puts "Saved to #{output_file}"
end # end of main

main
