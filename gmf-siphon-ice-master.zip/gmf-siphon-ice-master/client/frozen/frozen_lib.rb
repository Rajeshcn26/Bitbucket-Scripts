require "fileutils"
require "json"
require "csv"
require_relative "../../lib/helpers"

# Define constants for webhook-related labels
STATUS_WEBHOOK_NA = "status-webhook-NA"
STATUS_WEBHOOK_TRUE = "status-webhook-true"
STATUS_WEBHOOK_FALSE = "status-webhook-false"

MAX_PAGES = (ENV["MAX_PAGES"] && ENV["MAX_PAGES"].to_i > 0) ? ENV["MAX_PAGES"].to_i : 5000 # Define max_pages as a constant from ENV or default to 5000

def get_org_from_env
  # puts "getting ENV['SDLC_ORG']: #{ENV['SDLC_ORG']}"
  ENV["SDLC_ORG"] || "ORG"
end # end of get_org_from_env method

def get_repos_repo_name
  # puts "getting ENV['REPOS']: #{ENV['REPOS']}"
  ENV["REPOS"] || "ghec.repo"
end # end of get_repos_repo_name method

def get_teams_repo_name
  # puts "getting ENV['TEAMS']: #{ENV['TEAMS']}"
  ENV["TEAMS"] || "ghec.teams"
end # end of get_teams_repo_name method

#
# method to pull down the Repos repo, and put it in the output folder off the base path
def pull_down_repos_repo
  token = ENV["GH_TOKEN"]
  org = get_org_from_env
  repos = get_repos_repo_name
  if token && !token.empty?
    repos_repo_url = "https://#{token}:x-oauth-basic@github.com/#{org}/#{repos}.git"
    puts "repos_repo_url (with token): #{repos_repo_url}"
  else
    repos_repo_url = "https://github.com/#{org}/#{repos}.git"
    puts "repos_repo_url (no token): #{repos_repo_url}"
  end

  output_folder = File.join(Dir.pwd, "output")
  repos_folder = File.join(output_folder, "repos")

  # Ensure the output folder exists
  FileUtils.mkdir_p(output_folder)

  # Clone the repos repo into the output folder
  if Dir.exist?(repos_folder)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos repo already exists at #{repos_folder}. Pulling latest changes...", true)
    system("git -C #{repos_folder} pull")
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Cloning repos repo from #{repos_repo_url} to #{repos_folder} with shallow clone...", true)
    system("git clone --depth 1 #{repos_repo_url} #{repos_folder}")
  end

  Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos repo is ready at #{repos_folder}", true)
end # end of pull_down_repos_repo method



# method to pull down the Teams repo, and put it in the output folder off the base path
def pull_down_teams_repo
  puts "pull_down_teams_repo() : pulling down the Teams repo"
  token = ENV["GH_TOKEN"]
  org = get_org_from_env
  teams = get_teams_repo_name
  if token && !token.empty?
    teams_repo_url = "https://#{token}:x-oauth-basic@github.com/#{org}/#{teams}.git"
    # puts "teams_repo_url (with token): #{teams_repo_url}"
  else
    teams_repo_url = "https://github.com/#{org}/#{teams}.git"
    # puts "teams_repo_url (no token): #{teams_repo_url}"
  end

  output_folder = File.join(Dir.pwd, "output")
  teams_folder = File.join(output_folder, "teams")

  # Ensure the output folder exists
  FileUtils.mkdir_p(output_folder)

  # Clone the teams repo into the output folder
  if Dir.exist?(teams_folder)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Teams repo already exists at #{teams_folder}. Pulling latest changes...", true)
    system("git -C #{teams_folder} pull")
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Cloning teams repo from #{teams_repo_url} to #{teams_folder} with shallow clone...", true)
    system("git clone --depth 1  #{teams_repo_url} #{teams_folder}")  # use --verbose for debugging if clone problems
  end

  # Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Teams repo is ready at #{teams_folder}", true)
end # end of pull_down_teams_repo method

#
# method to get Teams from the *Teams* repo
#
def get_teams_from_repo
  # puts "get_teams_from_repo() : getting teams from the Teams repo"
  teams_file_path = File.join(Dir.pwd, "output", "teams", "teams", "teams.json")

  unless File.exist?(teams_file_path)
    # Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Teams file not found at #{teams_file_path}. Pulling Teams repo..", true)
    pull_down_teams_repo
  end

  teams_data = File.read(teams_file_path)
  JSON.parse(teams_data)
end # end of get_teams_from_repo method

# method to get projects from the Repos repo. in the repo folder is a bunch of json files
# each file is named with the project key and ends with _repos.json. this method should find all the file
# in that folder and return the project keys
def get_projects_from_repo
  repos_folder_path = File.join(Dir.pwd, "output", "repos", "repos")

  unless Dir.exist?(repos_folder_path)
    Helper.log_type(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos folder not found at #{repos_folder_path}. Ensure the Repos repo is pulled.", true, Helper::ERROR)
    pull_down_repos_repo
  end

  keys = []
  Dir.glob(File.join(repos_folder_path, "*_repos.json")).each do |file|
    key = File.basename(file, "_repos.json")
    keys << key
  end

  keys
end # end of get_projects_from_repo method

# method to pull back all data for a specific Team - json file we need is in teams\teams.json (in the repo)
def get_team_data(project_key)
  # Find the team name for the given project_key
  team_name = get_team_for_project(project_key)
  unless team_name
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Team not found for project key '#{project_key}'.", true)
    return nil
  end
  # puts "team_name: #{team_name} for project_key: #{project_key}"
  teams_data = get_teams_from_repo

  # Ensure teams_data is a hash and contains the 'teams' key
  unless teams_data.is_a?(Hash) && teams_data["teams"].is_a?(Array)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Invalid teams.json structure.", true)
    return nil
  end

  # Find the team by name
  team_data = teams_data["teams"].find { |team| team["Name"] == team_name }
  unless team_data
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Team '#{team_name}' not found in teams.json", true)
    return nil
  end
  # puts "get_team_data() team_data: #{team_data}"
  team_data
end # end of get_team_data method

# method to pull back all repos for a specific BB project key - each bb key has a file like repos\AAP_repos.json
def get_repos_for_project_key(project_key)
  repos_folder_path = File.join(Dir.pwd, "output", "repos", "repos")

  unless Dir.exist?(repos_folder_path)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos folder not found at #{repos_folder_path}. Ensure the Repos repo is pulled.", true)
    pull_down_repos_repo
  end

  repos_file_path = File.join(repos_folder_path, "#{project_key}_repos.json")
  unless File.exist?(repos_file_path)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos file not found for project key '#{project_key}' at #{repos_file_path}.", true)
    return "nil"
  end

  repos_data = File.read(repos_file_path)
  JSON.parse(repos_data)["repositories"].map do |repo|
    "#{repo['Name']}"
  end
end # end of get_repos_for_project_key method

# method to get CodeOwners for a Team
def get_codeowners_for_team(project_key)
  # Use get_team_for_project to find the team name for the given project key
  team_name = get_team_for_project(project_key)
  unless team_name
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Team not found for project key '#{project_key}'.", true)
    return []
  end

  teams_file_path = File.join(Dir.pwd, "output", "teams", "teams", "teams.json")

  unless File.exist?(teams_file_path)
    # Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Teams file not found at #{teams_file_path}. Ensure the Teams repo is pulled.", true)
    pull_down_teams_repo
  end

  teams_data = JSON.parse(File.read(teams_file_path))
  team = teams_data["teams"].find { |t| t["Name"] == team_name }

  if team && team["CodeOwners"]
    team["CodeOwners"]
    for code_owner in team["CodeOwners"]

      code_owner.is_a?(String) ? code_owner.strip : nil

      puts "Code Owner: #{code_owner}"
    end
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "No CodeOwners found for team '#{team_name}'.", true)
    []
  end
end # end of get_codeowners_for_team method

# method to take in a project name and return the team. it looks in the teams.json file
def get_team_for_project(project_key)
  teams_data = get_teams_from_repo

  # Ensure teams_data is a hash and contains the 'teams' key
  return nil unless teams_data.is_a?(Hash) && teams_data["teams"].is_a?(Array)

  # Find the team where ProjectKey matches the given project_key (case-insensitive)
  team = teams_data["teams"].find do |t|
    t["ProjectKey"] && t["ProjectKey"].casecmp(project_key.to_s) == 0
  end

  team ? team["Name"] : nil
end # end of get_team_for_project method




# method to get metadata (BSN, CLDBID, etc) for a Repo
def get_repo_metadata(project_key, repo_name)
  # First, find the team name for the given project_key
  team_name = get_team_for_project(project_key)
  puts "team_name: #{team_name} for project_key: #{project_key}"
  return nil unless team_name

  repos_folder_path = File.join(Dir.pwd, "output", "repos", "repos")

  unless Dir.exist?(repos_folder_path)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos folder not found at #{repos_folder_path}. Ensure the Repos repo is pulled.", true)
    pull_down_repos_repo
  end

  # Use the team name to find the file
  repos_file_path = File.join(repos_folder_path, "#{team_name}_repos.json")
  unless File.exist?(repos_file_path)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repos file not found for team '#{team_name}' at #{repos_file_path}.", true)
    return nil
  end

  repos_data = JSON.parse(File.read(repos_file_path))
  full_repo_name = "#{team_name}.#{repo_name}"
  # full_repo_name = "#{repo_name}"
  repo = repos_data["repositories"].find { |r| r["Name"].casecmp(full_repo_name) == 0 }

  if repo
    {
      "BSN" => repo["BSN"],
      "CLDBID" => repo["CLDBID"],
      "Name" => repo["Name"],
      "Description" => repo["Description"],
      "Visibility" => repo["Visibility"],
      "Team" => repo["Team"],
      "Roles" => repo["Roles"],
      "Repository_Project" => repo["Repository_Project"]
    }
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repo '#{full_repo_name}' not found in team '#{team_name}'.", true)
    nil
  end
end # end of get_repo_metadata method

# method to get CLDBID and BSN for a specific BB key and repo
# This method calls get_repo_metadata and extracts CLDBID and BSN
def get_cldbid_and_bsn(project_key, repo_name)
  metadata = get_repo_metadata(project_key, repo_name)
  if metadata
    {
      "CLDBID" => metadata["CLDBID"],
      "BSN" => metadata["BSN"],
      "Repository_Project" => metadata["Repository_Project"]
    }
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Metadata not found for repo '#{repo_name}' in project '#{project_key}'.", true)
    nil
  end
end # end of get_cldbid_and_bsn method



# method to get all members for a team. for a team passed in, pull back the Approvers.
def get_approvers_for_team(project_key)
  team_data = get_team_data(project_key)

  if team_data
    team_data["Approvers"]
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Approvers not found for team '#{team_name}'.", true)
    []
  end
end # end of get_members_for_team method



# method to get the list of teams that a repo should be added to. these are listed as Roles in the repo.
# it will use the get_repo_metadata method to get the metadata for the repo, and then pull out the Roles

#########################################################################################################
# method to get teams from the Roles section in the repos JSON files
# bb key and repo name need to be passed in.
#########################################################################################################
def get_teams_to_add_to_repo(project_key)
  metadata = get_team_data(project_key)
  if metadata && metadata["Roles"]
    # Return just the role names (keys)
    metadata["Roles"]
  else
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Roles not found for repo '#{repo_name}' in project '#{project_key}'.", true)
    []
  end
end # end of get_teams_to_add_to_repo method

# method that will get IAC and cldbid/bsn for a repo. it will call get_cldbid_and_bsn and find_iac_code_in_repo
def get_custom_properties_for_repo(project_key, repo_name)
  cldbid_and_bsn = get_cldbid_and_bsn(project_key, repo_name)
  return [] unless cldbid_and_bsn.is_a?(Hash)

  props = []
  props << { property_name: "cldbid", value: cldbid_and_bsn["CLDBID"].to_s } if cldbid_and_bsn["CLDBID"]
  props << { property_name: "bsn", value: cldbid_and_bsn["BSN"].to_s } if cldbid_and_bsn["BSN"]
  props << { property_name: "repository_project", value: cldbid_and_bsn["Repository_Project"].to_s } if cldbid_and_bsn["Repository_Project"]
  props
end # end of get_custom_properties_for_repo method

#########################################################################################################
# method to search for authors of commits in a cloned-down bare repo by service accounts
#########################################################################################################
def get_service_accounts_with_commits(repo)
  puts "in get_service_accounts_with_commits()"
  service_accounts_file = File.join(Dir.pwd, "output", "service_accounts.csv")

  unless File.exist?(service_accounts_file)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Service accounts file not found at #{service_accounts_file}.", true)
    return { labels: [], issue_body: "" }
  end

  puts "extracting repo path"
  repo_path = extract_repo_path(repo)

  return { labels: [], issue_body: "" } unless repo_path

  unless Dir.exist?(repo_path)
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Repo path not found at #{repo_path}.", true)
    return { labels: [], issue_body: "" }
  end

  # Read email addresses from column 2 of the CSV
  puts "reading service accounts from CSV file"
  service_accounts = CSV.read(service_accounts_file).map { |row| row[1] }.compact
  if service_accounts.empty?
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "No service accounts found in #{service_accounts_file}.", true)
    return { labels: [], issue_body: "" }
  end

  # Run the Git log command for the last year's commits and capture the output
  command = "git -C \"#{File.expand_path(repo_path)}\" log --all --since=\"1 year ago\" --pretty=format:\"%ae\""
  puts "finding service accounts command: #{command}"
  all_accounts = `#{command}`

  if all_accounts.empty?
    Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Failed to retrieve Git log for #{repo_path}.", true)
    return { labels: [], issue_body: "" }
  end

  # Search for service accounts in the Git log output
  puts "searching for service accounts in the Git log output"
  accounts_with_commits = service_accounts.select { |account| all_accounts.include?(account) }

  # Prefix each label in accounts_with_commits with "svc-"
  accounts_with_commits.map! { |account| "svc-#{account}" }.uniq

  # Ensure the list is unique
  accounts_with_commits.uniq

  # treat all_accounts string as a list of email addresses, i just want the unique ones
  puts "getting unique email addresses"
  all_accounts = all_accounts.split("\n").map(&:downcase).uniq.join(", ")

  if accounts_with_commits
    issue_body_string = <<~MARKDOWN
      |  Commiters Last Year | #{all_accounts} |
      |----------------------|-----------------|
    MARKDOWN
  end

  if issue_body_string && issue_body_string.length > 65_000
    puts "::warning:: issue_body_string exceeds 65k characters."
  end
  puts "exiting get_service_accounts_with_commits(): accounts_with_commits: #{accounts_with_commits}"
  {
    labels: accounts_with_commits.empty? ? [] : accounts_with_commits,
    issue_body: issue_body_string || ""
  }
end # end of get_service_accounts_with_commits method



def execute_extensions(repo)
  puts "::: Executing Frozen Lib Extension execute_extensions()"
 # puts "\nRepo: #{repo}"

  # Call get_service_accounts_with_commits
  puts "before Calling get_service_accounts_with_commits"
  service_accounts = get_service_accounts_with_commits(repo)
  puts "after getting service Accounts with Commits: #{service_accounts}"

  # Call get_codeowners_for_team
  # codeowners = get_codeowners_for_team(team_name)
  # puts "Code Owners for Team '#{team_name}': #{codeowners}"

  labels = nil
  issue_body = nil

  {
      labels: Array(service_accounts.is_a?(Hash) ? service_accounts[:labels] : []).uniq,
      issue_body: service_accounts[:issue_body].to_s
  }
end

def extract_repo_path(repo)
  begin
    full_url = repo["links"]["clone"][0]["href"]
  rescue => e
    Helper.log_type(File.join(Dir.pwd, "output", "frozenlib.log"), "Invalid JSON structure for repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
    return nil
  end

  # Extract just the repository name from the URL
  File.join("_repos", File.basename(full_url))
end # end of extract_repo_path method


def extract_team_names
  teams_file = File.join(Dir.pwd, "output", "teams", "teams", "teams.json")
  unless File.exist?(teams_file)
    puts "[ERROR] Team file not found at #{teams_file}. Please run pull_down_teams_repo first."
    puts "[DEBUG] Current working directory: #{Dir.pwd}"
    puts "[DEBUG] Directory listing for output/teams/teams:"
    begin
      puts Dir.entries(File.join(Dir.pwd, "output", "teams", "teams")).join(", ")
    rescue => e
      puts "[DEBUG] Could not list directory: #{e.message}"
    end
    exit
  end
  teams_data = JSON.parse(File.read(teams_file))
  teams_data["teams"].map { |team| team["ProjectKey"] }
end # end of extract_team_names method



def fetch_issues(org, repo, max_pages)
  test_filter = ""
  if false
    test_filter = 'labels: ["user-test"]'
    # test_filter = 'labels: ["so_TER"]'
  end
  query = <<-GRAPHQL
    query($cursor: String) {
      repository(owner: "#{org}", name: "#{repo}") {
        issues(first: 100, after: $cursor, states: [OPEN]  #{test_filter} ) {
          edges {
            node {
              number
              title
              labels(first: 50) {
                nodes {
                  name
                }
              }
              issueType {
                name
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
          }
        }
      }
    }
  GRAPHQL

  issues = []
  cursor = nil
  page_count = 0

  loop do
    break if max_pages && page_count >= max_pages # Stop if max pages limit is reached
    response = execute_graphql_query(query, { cursor: cursor })
    if response.code.to_i != 200
      puts "[ERROR] GraphQL query failed with status: #{response.code}"
      puts "[ERROR] Response body: #{response.body}"
      exit(1)
    end

    data = JSON.parse(response.body)
    if data["errors"]
      puts "[ERROR] GraphQL query returned errors: #{data["errors"]}"
      exit(1)
    end

    repository_data = data.dig("data", "repository")
    if repository_data.nil?
      puts "[ERROR] No repository data found in response. Check if the org/repo is correct."
      puts "[DEBUG] Response body: #{data.inspect}"
      exit(1)
    end

    issues_data = repository_data["issues"]
    if issues_data.nil? || issues_data["edges"].empty?
      puts "[DEBUG] No issues found for the repository."
      break
    end

    # Collect only issues without a type
    issues += issues_data["edges"].map { |edge| edge["node"] }.select { |issue| issue["issueType"].nil? }

    page_info = issues_data["pageInfo"]
    puts "...#{issues.size} issues"

    page_count += 1
    break unless page_info["hasNextPage"]

    cursor = page_info["endCursor"]
  end # end of loop

  issues
end # end of fetch_issues method

def execute_graphql_query(query, variables = {})
  # puts "[DEBUG] Executing GraphQL query with variables: #{variables.inspect}"
  uri = URI("https://api.github.com/graphql")
  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{$token}"
  request["Content-Type"] = "application/json"
  request.body = { query: query, variables: variables }.to_json

  response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
    http.request(request)
  end

  # puts "[DEBUG] Received response with status: #{response.code}"
  response
end # end of execute_graphql_query method


# Adds the "status-team" or "status-repo" label to every issue in the xsiphon repo
def add_status_team_repo_labels_to_issues

  # Fetch issues from GitHub (paginated)
  puts "\nmax_pages: #{MAX_PAGES} -- each page has 100 issues\n\n"

  # Set up org, repo, and token from environment or defaults
  $org = ENV["GITHUB_ORG"] || get_org_from_env
  $repo = ENV["GITHUB_REPO"] || "xsiphon"
  $token = ENV["GITHUB_TOKEN"]
  unless $org && $repo && $token
    puts "[ERROR] Missing required environment variables: GITHUB_ORG, GITHUB_REPO, or GITHUB_TOKEN."
    return
  end
  puts "Adding 'status-team' or 'status-repo' label to issues in #{$org}/#{$repo} repo..."

  repo_full = "#{$org}/#{$repo}"

  # Get all team names for matching against issue titles
  team_names_from_json = extract_team_names.map(&:to_s)
  puts "Team count from JSON: #{team_names_from_json.size}"
  # puts "\n\n######\nTeam names: #{team_names_from_json}######\n"

  # Get all project keys, teams, and repos for repo label matching
  # projects_teams_repos = get_all_projects_teams_and_repos
  projects_teams_repos = get_all_projects_teams_and_repos_stripped

  # Build a list of patterns like ::PROJECTKEY/repo_name for fast matching in issue titles
  repos_from_json = []
  repo_pattern_to_name = {}
  projects_teams_repos.each do |project_key, data|
    Array(data[:repos]).each_with_index do |repo_name, idx|
      pattern = "::#{project_key}/#{repo_name}"
      repos_from_json << pattern
      repo_pattern_to_name[pattern] = { project_key: project_key, repo_name: repo_name }
    end
  end

  # Track which repo patterns are matched (either skipped or updated)
  matched_repo_patterns = Set.new

  issues = fetch_issues($org, $repo, MAX_PAGES)

  puts "\nFetched #{issues.size} issues from GitHub\n\n"
  puts "\n\nWARNING: Max pages set to #{MAX_PAGES} so only the first #{MAX_PAGES * 100} issues will be processed due to pagination limits.\n\n\n" if issues.size == MAX_PAGES * 100

  issues_to_update = []
  matched_repo_patterns = Set.new # Tracks all repo patterns that match any issue (skipped or updated)
  updated_repo_patterns = Set.new # Tracks only those that result in a label being added

  issues.each do |issue|
    node = issue["node"] || issue
    next unless node.is_a?(Hash) && node["title"]
    label_names = node.dig("labels", "nodes")&.map { |l| l["name"] } || []

    # Check existing labels
    has_status_team = label_names.include?("status-team")
    has_status_repo = label_names.include?("status-repo")
    has_status_webhook_NA = label_names.include?(STATUS_WEBHOOK_NA)
    has_status_webhook_true = label_names.include?(STATUS_WEBHOOK_TRUE)
    has_status_webhook_false = label_names.include?(STATUS_WEBHOOK_FALSE)

    # puts "Processing Issue #{node['title']} has_status_team=#{has_status_team}, has_status_repo=#{has_status_repo}, has_status_webhook_NA=#{has_status_webhook_NA}, has_status_webhook_true=#{has_status_webhook_true}, has_status_webhook_false=#{has_status_webhook_false}"

    # Match repo patterns to issue titles (full, exact, downcased match)
    matched_pattern = repos_from_json.find do |pattern|
      node_title = node["title"].downcase.strip
      pattern_downcase = pattern.downcase.strip
      node_title.end_with?(pattern_downcase)
    end

    # Match team patterns to issue titles (team pattern is ::TEAM/)
    matched_team = team_names_from_json.find do |team_name|
      node["title"].downcase.include?("::#{team_name.downcase}/")
    end

    # If neither repo nor team matches, update the issue with the webhook NA label
    unless matched_pattern || matched_team
      # If the issue already has STATUS_WEBHOOK_NA, skip to the next issue
      if label_names.include?(STATUS_WEBHOOK_NA)
        next # end of skip if already has STATUS_WEBHOOK_NA
      end
      new_labels = label_names.dup
      new_labels << STATUS_WEBHOOK_NA
      new_labels.uniq!
      issues_to_update << { number: node["number"], labels: new_labels, title: node["title"] }
      next # end of unless matched_pattern
    end

    # Determine the expected labels
    project_key = matched_pattern ? repo_pattern_to_name.dig(matched_pattern, :project_key) : matched_team
    project_key_downcased = project_key.to_s.downcase if project_key

    expected_team_label = "status-team"
    expected_repo_label = "status-repo"
    expected_webhook_label = get_webhook_status_label(project_key_downcased)

    # Determine the current webhook label from the issue's labels
    current_webhook_label = label_names.find do |label|
      [STATUS_WEBHOOK_NA, STATUS_WEBHOOK_TRUE, STATUS_WEBHOOK_FALSE].include?(label)
    end
    # puts "  #{node["title"]} | current: #{current_webhook_label} | retrieved: #{expected_webhook_label}"
    # puts "    status-team | current: #{has_status_team} | expected: #{matched_team ? expected_team_label : nil}"
    # puts "    status-repo | current: #{has_status_repo} | expected: #{matched_pattern ? expected_repo_label : nil}"

    # Check if labels are different
    team_label_diff = matched_team && !has_status_team
    repo_label_diff = matched_pattern && !has_status_repo
    webhook_label_diff = !(has_status_webhook_NA || has_status_webhook_true || has_status_webhook_false)

    # Skip if all three labels are already present and match the expected values
    skip_all_labels_match = (
      (!matched_team || has_status_team) &&
      (!matched_pattern || has_status_repo) &&
      (current_webhook_label == expected_webhook_label)
    )
    if skip_all_labels_match
      # puts "    Issue ##{node['number']} already has correct labels, skipping..."
      next
    else
      # Prepare new labels
      new_labels = label_names.dup
      new_labels << expected_team_label if team_label_diff
      new_labels << expected_repo_label if repo_label_diff

      # Remove old webhook label if different
      if (expected_webhook_label == STATUS_WEBHOOK_TRUE || expected_webhook_label == STATUS_WEBHOOK_FALSE) && new_labels.include?(STATUS_WEBHOOK_NA)
        new_labels.delete(STATUS_WEBHOOK_NA)
      elsif current_webhook_label != expected_webhook_label
        new_labels.delete(current_webhook_label)
      end
      new_labels << expected_webhook_label #if (matched_pattern || matched_team) && webhook_label_diff
      new_labels.uniq!

      issues_to_update << { number: node["number"], labels: new_labels, title: node["title"] }
      # puts "matched: #{node['title']}: #{new_labels}\n"
    end # end of if skip_all_labels_match block
  end   # end of issues.each block

  if issues_to_update.any?
    update_issues_on_github(issues_to_update, repo_full)
  else
    puts "All issues already have correct labels. No updates needed."
  end
end   # end of add_status_team_label_to_issues method

def update_issues_on_github(issues_to_update, repo_full)
  puts "\n\n\nTotal issues to update: #{issues_to_update.size}"

  client = Helper.setup_octokit_client($token)
  updated_count = 0
  issues_to_update.each do |issue|
    begin
      client.update_issue(repo_full, issue[:number], labels: issue[:labels])
      updated_count += 1
      puts "[#{updated_count}/#{issues_to_update.size}] Updated ##{issue[:number]} #{issue[:title]} with: #{issue[:labels]}"
    rescue ::Octokit::TooManyRequests => e
      Helper.log_type(File.join(Dir.pwd, "output", "frozenlib.log"), "GitHub API rate limit exceeded: #{e.message}", true, Helper::ERROR)
      puts "[ERROR] GitHub API rate limit exceeded. Exiting."
      exit(1)
    rescue ::Octokit::Error => e
      if e.message =~ /rate limit/i
        Helper.log_type(File.join(Dir.pwd, "output", "frozenlib.log"), "GitHub API rate limit error: #{e.message}", true, Helper::ERROR)
        puts "[ERROR] GitHub API rate limit error. Exiting."
        exit(1)
      else
        Helper.log_type(File.join(Dir.pwd, "output", "frozenlib.log"), "Octokit error: #{e.message}", true, Helper::ERROR)
        puts "[ERROR] Octokit error: #{e.message}"
      end # end of if e.message block
    rescue => e
      Helper.log_type(File.join(Dir.pwd, "output", "frozenlib.log"), "Unexpected error: #{e.class}: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
      puts "[ERROR] Unexpected error: #{e.class}: #{e.message}"
    end   # end of rescue block
  end     # end of issues_to_update.each block
end # end of update_issues_on_github method

# Returns a hash of all project keys to their team name and repos,
# but strips the team name and first period from the start of each repo name if it matches the team name.
def get_all_projects_teams_and_repos_stripped
  result = {}
  teams_data = get_teams_from_repo
  return result unless teams_data.is_a?(Hash) && teams_data["teams"].is_a?(Array)

  total_repos = 0
  teams_data["teams"].each do |team|
    project_key = team["ProjectKey"]
    team_name = team["Name"]
    webhook = team["Webhook"] # Extract the webhook for the team
    next unless project_key && team_name

    repos_file_path = File.join(Dir.pwd, "output", "repos", "repos", "#{team_name}_repos.json")
    repos = []
    if File.exist?(repos_file_path)
      begin
        repos_data = JSON.parse(File.read(repos_file_path))
        # puts "#{Helper::GREEN}\nProjectKey: #{project_key}, Team: #{team_name}, Webhook: #{webhook}#{Helper::NORMAL}" # Include webhook in the output
        repos = repos_data["repositories"].map.with_index do |repo, idx|
          repo_name = repo["Name"]
          # Only strip if repo_name starts with "#{team_name}." and has more after the period
          if repo_name.start_with?("#{team_name}.") && repo_name.length > team_name.length + 1
            stripped = repo_name.sub(/^#{Regexp.escape(team_name)}\./, "")
            # print "[#{idx}] #{stripped}, "
            stripped
          else
            # print "[#{idx}] #{repo_name}, "
            repo_name
          end
        end
        total_repos += repos.size
      rescue => e
        Helper.log(File.join(Dir.pwd, "output", "frozenlib.log"), "Failed to read repos for #{project_key}: #{e.message}", true)
      end
    end
    result[project_key] = { team: team_name, repos: repos, webhook: webhook } # Include webhook in the result
  end # end of teams_data.each block

  puts "\nTotal repos defined in REPOS_*.json: #{total_repos}"
  result
end # end of get_all_projects_teams_and_repos_stripped method

def get_webhook_for_team(project_key)
  team_data = get_team_data(project_key) # Call get_team_data to retrieve team information
  return nil unless team_data.is_a?(Hash) && team_data.key?("Webhook") # Ensure team_data contains the Webhook field

  team_data["Webhook"] # Return the Webhook field
end # end of get_webhook_for_team method

def get_webhook_status_label(project_key)
  # puts "get_webhook_status_label() : project_key: #{project_key}"
  team_data = get_team_data(project_key) # Retrieve team data for the project key
  if team_data
    webhook = team_data["Webhook"]
    return STATUS_WEBHOOK_FALSE if webhook.nil? || webhook.strip.empty? # Return false label if webhook is empty or nil
  else
    return STATUS_WEBHOOK_NA # Return NA label if no team/project key is found
  end
  return   STATUS_WEBHOOK_TRUE # Return true label if webhook is present
end # end of get_webhook_status_label method
