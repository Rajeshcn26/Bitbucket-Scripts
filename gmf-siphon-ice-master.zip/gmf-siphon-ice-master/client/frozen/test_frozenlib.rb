require_relative "./frozen_lib"
require "json"
require_relative "../../lib/helpers"

# Reset the log file before running tests
def reset_log_file
  log_file_path = File.join(Dir.pwd, "output", "test_log.txt")
  FileUtils.mkdir_p(File.dirname(log_file_path)) # Ensure the output folder exists
  File.write(log_file_path, "") # Clear the log file
  log_file_path
end

# Define a method to test pull_down_repos_repo
def test_pull_down_repos_repo

  Helper.log_type("test_log.txt", "\n########################################################\nTesting pull_down_repos_repo method...\n", true, Helper::INFO)
  begin
    pull_down_repos_repo
    Helper.log_type("test_log.txt", "pull_down_repos_repo executed successfully.", true, Helper::INFO)
  rescue => e
    Helper.log_type("test_log.txt", "Error during pull_down_repos_repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test pull_down_teams_repo
def test_pull_down_teams_repo

  Helper.log_type("test_log.txt", "\n########################################################\nTesting pull_down_teams_repo method...\n", true, Helper::INFO)
  begin
    pull_down_teams_repo
    Helper.log_type("test_log.txt", "pull_down_teams_repo executed successfully.", true, Helper::INFO)
  rescue => e
    Helper.log_type("test_log.txt", "Error during pull_down_teams_repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test get_teams_from_repo
def test_get_teams_from_repo

  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_teams_from_repo method...\n", true, Helper::INFO)
  begin
    teams = get_teams_from_repo
    Helper.log_type("test_log.txt", "get_teams_from_repo returned: #{teams}", true, "")
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_teams_from_repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test get_projects_from_repo
def test_get_projects_from_repo

  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_projects_from_repo method...\n", true, Helper::INFO)
  begin
    repos_keys = get_projects_from_repo
    Helper.log_type("test_log.txt", "get_projects_from_repo returned keys: #{repos_keys}", true, "")
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_projects_from_repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test get_repos_for_project_key
def test_get_repos_for_project_key(project_key)

  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_repos_for_project_key method with project key '#{project_key}'...\n", true, Helper::INFO)
  begin
    repos = get_repos_for_project_key(project_key)
    Helper.log_type("test_log.txt", "get_repos_for_project_key returned: #{repos}", true, "")
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_repos_for_project_key: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test get_codeowners_for_team
def test_get_codeowners_for_team(team_name)

  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_codeowners_for_team method with team name '#{team_name}'...\n", true, Helper::INFO)
  begin
    codeowners = get_codeowners_for_team(team_name)
    Helper.log_type("test_log.txt", "get_codeowners_for_team returned: #{codeowners}", true, "")
    if codeowners.is_a?(Array) && !codeowners.empty?
      Helper.log_type("test_log.txt", "Test passed: CodeOwners fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: No CodeOwners found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_codeowners_for_team: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test get_repo_metadata
def test_get_repo_metadata(project_key, repo_name)

  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_repo_metadata method with project key '#{project_key}' and repo name '#{repo_name}'...\n", true, Helper::INFO)
  begin
    metadata = get_repo_metadata(project_key, repo_name)
    Helper.log_type("test_log.txt", "get_repo_metadata returned: #{metadata}", true, "")
    # Accept if metadata is a Hash and has a Name field containing the repo_name (since the Name may be prefixed by team)
    if metadata.is_a?(Hash) && metadata["Name"].to_s.downcase.include?(repo_name.to_s.downcase)
      Helper.log_type("test_log.txt", "Test passed: Metadata fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Metadata not found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_repo_metadata: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end

# Define a method to test get_cldbid_and_bsn
def test_get_cldbid_and_bsn(project_key, repo_name)

  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_cldbid_and_bsn method with project key '#{project_key}' and repo name '#{repo_name}'...\n", true, Helper::INFO)
  begin
    result = get_cldbid_and_bsn(project_key, repo_name)
    Helper.log_type("test_log.txt", "get_cldbid_and_bsn returned: #{result}", true, "")
    if result.is_a?(Hash) && result["CLDBID"] && result["BSN"]
      Helper.log_type("test_log.txt", "Test passed: CLDBID and BSN fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: CLDBID and BSN not found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_cldbid_and_bsn: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end


# Define a method to test get_team_data
def test_get_team_data(project_key)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_team_data method with project key '#{project_key}'...\n", true, Helper::INFO)
  begin
    team_data = get_team_data(project_key)
    Helper.log_type("test_log.txt", "get_team_data returned: #{team_data}", true, "")
    if team_data.is_a?(Hash) && team_data["ProjectKey"].to_s == project_key.to_s && team_data.key?("Description")
      Helper.log_type("test_log.txt", "Test passed: Team data fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Team data not found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_team_data: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_team_data method

# Define a method to test get_teams_to_add_to_repo
def test_get_teams_to_add_to_repo(project_key)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_teams_to_add_to_repo method for '#{project_key}'...\n", true, Helper::INFO)
  begin
    teams = get_teams_to_add_to_repo(project_key)
    Helper.log_type("test_log.txt", "get_teams_to_add_to_repo returned: #{teams}", true, "")
    if teams.is_a?(Hash) && teams.key?("ro") && teams.key?("rw")
      Helper.log_type("test_log.txt", "Test passed: Teams fetched successfully with valid structure.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Teams not found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_teams_to_add_to_repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_teams_to_add_to_repo method

# Define a method to test get_commits_by_service_accounts
def test_get_service_accounts_with_commits(repo_path)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_service_accounts_with_commits method with repo path '#{repo_path}'...\n", true, Helper::INFO)
  begin
    accounts = get_service_accounts_with_commits(repo_path)
    Helper.log_type("test_log.txt", "get_service_accounts_with_commits returned: #{accounts}", true, "")
    if accounts.is_a?(Array) && !accounts.empty?
      Helper.log_type("test_log.txt", "Test passed: Service accounts with commits fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: No service accounts with commits found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_service_accounts_with_commits: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_service_accounts_with_commits method

# Define a method to test get_team_for_project
def test_get_team_for_project(project_key)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_team_for_project method with project key '#{project_key}'...\n", true, Helper::INFO)
  begin
    team_name = get_team_for_project(project_key)
    Helper.log_type("test_log.txt", "get_team_for_project returned: #{team_name}", true, "")
    if team_name.is_a?(String) && !team_name.empty?
      Helper.log_type("test_log.txt", "Test passed: Team name fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Team name not found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_team_for_project: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_team_for_project method

# Define a method to test get_custom_properties_for_repo
def test_get_custom_properties_for_repo(project_key, repo_name)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_custom_properties_for_repo method with project key '#{project_key}' and repo name '#{repo_name}'...\n", true, Helper::INFO)
  begin
    result = get_custom_properties_for_repo(project_key, repo_name)
    Helper.log_type("test_log.txt", "get_custom_properties_for_repo returned: #{result}", true, "")
    if result.nil? || result.is_a?(Hash)
      Helper.log_type("test_log.txt", "Test passed: Custom properties fetched (or nil if not implemented).", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Unexpected return type for custom properties.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_custom_properties_for_repo: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_custom_properties_for_repo method

# Define a method to test extract_team_names
def test_extract_team_names
  names = extract_team_names
  # puts "names: #{names}"
end

def test_add_status_team_repo_labels_to_issues
  puts "\n########################################################\nTesting add_status_team_repo_labels_to_issues method...\n"
  add_status_team_repo_labels_to_issues
end # end of test_add_status_team_label_to_issues method

# Define a method to test get_all_projects_teams_and_repos
def test_get_all_projects_teams_and_repos
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_all_projects_teams_and_repos method...\n", true, Helper::INFO)
  begin
    result = get_all_projects_teams_and_repos
    Helper.log_type("test_log.txt", "get_all_projects_teams_and_repos returned: #{result}\n\nEnd test results\n", true, "")
    if result.is_a?(Hash)
      Helper.log_type("test_log.txt", "Test passed: Returned a hash mapping project keys to teams and repos.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Did not return a hash.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_all_projects_teams_and_repos: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_all_projects_teams_and_repos method

# Define a method to test get_all_projects_teams_and_repos_stripped
def test_get_all_projects_teams_and_repos_stripped
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_all_projects_teams_and_repos_stripped method...\n", true, Helper::INFO)
  begin
    result = get_all_projects_teams_and_repos_stripped
    Helper.log_type("test_log.txt", "get_all_projects_teams_and_repos_stripped returned: #{result}\n\nEnd test results\n", true, "")
    if result.is_a?(Hash)
      all_valid = result.all? do |project_key, data|
        data.is_a?(Hash) && data.key?(:team) && data.key?(:repos) && data.key?(:webhook)
      end
      if all_valid
        Helper.log_type("test_log.txt", "Test passed: Returned a hash mapping project keys to teams, repos, and webhooks.", true, Helper::INFO)
      else
        Helper.log_type("test_log.txt", "Test failed: Some entries are missing required keys (team, repos, webhook).", true, Helper::ERROR)
      end
    else
      Helper.log_type("test_log.txt", "Test failed: Did not return a hash.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_all_projects_teams_and_repos_stripped: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_all_projects_teams_and_repos_stripped method

# Define a method to test get_webhook_for_team
def test_get_webhook_for_team(project_key)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_webhook_for_team method with project key '#{project_key}'...\n", true, Helper::INFO)
  begin
    webhook = get_webhook_for_team(project_key)
    Helper.log_type("test_log.txt", "get_webhook_for_team returned: #{webhook}", true, "")
    if webhook.is_a?(String) && !webhook.empty?
      Helper.log_type("test_log.txt", "Test passed: Webhook fetched successfully.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Webhook not found or invalid data structure.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_webhook_for_team: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_webhook_for_team method

# Define a method to test get_webhook_status_label
def test_get_webhook_status_label(project_key, expected_label)
  Helper.log_type("test_log.txt", "\n########################################################\nTesting get_webhook_status_label method with project key '#{project_key}'...\n", true, Helper::INFO)
  begin
    label = get_webhook_status_label(project_key)
    Helper.log_type("test_log.txt", "get_webhook_status_label returned: #{label}", true, "")
    if label == expected_label
      Helper.log_type("test_log.txt", "Test passed: Returned expected label '#{expected_label}'.", true, Helper::INFO)
    else
      Helper.log_type("test_log.txt", "Test failed: Expected '#{expected_label}', got '#{label}'.", true, Helper::ERROR)
    end
  rescue => e
    Helper.log_type("test_log.txt", "Error during get_webhook_status_label: #{e.message}\n#{e.backtrace.join("\n")}", true, Helper::ERROR)
  end
end # end of test_get_webhook_status_label method

# Main execution
log_file = reset_log_file
Helper.log_type(log_file, "Starting tests...\n", true, Helper::INFO)

# Call each test method
# test_pull_down_repos_repo
# test_pull_down_teams_repo
# test_get_teams_from_repo
# test_get_projects_from_repo
# test_get_repos_for_project_key('RP')
# test_get_repos_for_project_key('CA')
# test_get_codeowners_for_team("CA") # this should fail
# test_get_codeowners_for_team("METRICSGAGE") # this should pass
# test_get_team_for_project("METRICSGAGE")
# test_get_repo_metadata('ROP', 'roapi_python')
# test_get_repo_metadata('ROP', 'RP.rop_automation_suite')
# test_get_cldbid_and_bsn("METRICSRAGE", "metricsgarageartifactory")
# test_get_custom_properties_for_repo("METRIGARAGE", "metricsgarageartifactory")
# test_get_cldbid_and_bsn("ROP", "shared_logging_python")
# test_get_cldbid_and_bsn("BACPOAL", "bacptalserenityapi")
# test_get_team_data('METRICSGAGE')
# test_get_teams_to_add_to_repo('METRICGARAGE')
# test_get_service_accounts_with_commits('_repos/edgeservice.git')
# test_extract_team_names
# test_get_all_projects_teams_and_repos
# test_get_all_projects_teams_and_repos_stripped
# test_get_webhook_for_team("METRICARAGE")
# test_get_webhook_for_team("BACPOAL")
# test_get_webhook_for_team("ROP")
# test_get_webhook_for_team("KPE")
# test_get_webhook_status_label("METRSGAAGE")
# test_get_webhook_status_label("BACPTAL")
# test_get_webhook_status_label("ROP")
# test_get_webhook_status_label("KPE")
# test_get_webhook_status_label("kpe")
# test_get_webhook_status_label("AMW")
# test_get_webhook_status_label("ESLIBRIES", "status-webhook-true")
# test_get_webhook_status_label("esliaries", "status-webhook-true")
# test_get_webhook_status_label("ESTLS", "status-webhook-true")
# test_get_webhook_status_label("dog", "status-webhook-NA")
# test_get_webhook_status_label("ESOL", "status-webhook-NA")
# test_get_webhook_status_label("CLSO", "status-webhook-false")
# test_get_webhook_status_label("icso", "status-webhook-false")
# test_get_webhook_status_label("BBRV", "status-webhook-false")
# test_get_webhook_status_label("apae-rick", "status-webhook-NA")
# test_get_webhook_status_label("apae", "status-webhook-false")
# test_get_webhook_status_label("naphe", "status-webhook-NA")


test_add_status_team_repo_labels_to_issues

Helper.log_type(log_file, "\n########################################################\nAll tests completed. Check the output for results.\n", true, Helper::INFO)
