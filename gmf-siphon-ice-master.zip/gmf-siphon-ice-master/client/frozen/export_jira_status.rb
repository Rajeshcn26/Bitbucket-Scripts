# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz

require "rest-client"
require "net/http"
require "json"
require "csv"
require "base64"
require "time"

# Placeholder variables for Jira server, project, and subtask title filter
JIRA_SERVER = ENV["JIRA_SERVER"] || "https://jira.OWNER.net"
JIRA_PROJECT = ENV["JIRA_PROJECT"] || "SERI"

# Jira credentials from environment variables
JIRA_USER = ENV["JIRA_USER"]
JIRA_PAT = ENV["JIRA_PAT"]

# Output CSV file
OUTPUT_CSV = "output/jira_status.csv"

# Validate Jira credentials
if JIRA_USER.nil? || JIRA_PAT.nil?
  puts "Error: Jira credentials (JIRA_USER or JIRA_PAT) are missing. Please set them as environment variables."
  puts "Ensure you have exported the following environment variables:"
  puts "  - JIRA_USER: Your Jira username or email address."
  puts "  - JIRA_PAT: Your Jira personal PASSWORD."
  exit(1)
end # end of if block

# Fetches data from a Jira API endpoint
#
# @param endpoint [String] The Jira API endpoint to call.
# @return [Hash] The parsed JSON response.
def fetch_jira_data(endpoint)
  url = "#{JIRA_SERVER}/rest/api/2/#{endpoint}"
  headers = {
    "Authorization" => "Basic #{Base64.strict_encode64("#{JIRA_USER}:#{JIRA_PAT}")}",
    "Content-Type" => "application/json"
  }

  puts " #{url}" # Log the API URL being called

  begin
    response = RestClient.get(url, headers)
    JSON.parse(response.body)
  rescue RestClient::Unauthorized => e
    puts "Error: Unauthorized (401). Check your Jira credentials."
    exit(1)
  rescue RestClient::Forbidden => e
    puts "Error: Forbidden (403). You do not have permission to access this resource."
    puts "Response Body: #{e.response.body}" # Provide additional details
    exit(1)
  rescue RestClient::ExceptionWithResponse => e
    puts "Error: HTTP #{e.response.code}. Response Body: #{e.response.body}" # Simplified error message
    exit(1)
  rescue StandardError => e
    puts "Error: An unexpected error occurred. #{e.message}" # Simplified exception message
    exit(1)
  end # end of begin-rescue block
end # end of fetch_jira_data method

# Fetches all epics with titles matching the pattern "Group <number> - <description>"
# and processes them in numeric order.
#
# @return [Array<Hash>] An array of hashes containing epic titles, extracted numbers, and keys.
def fetch_epics_with_group_in_name
  jql_query = 'issuetype = Epic AND summary ~ "Group"' # JQL to fetch epics with "Group" in the name
  endpoint = "search?jql=#{URI.encode_www_form_component(jql_query)}"
  response = fetch_jira_data(endpoint)

  epics = response["issues"] || []
  epics.select do |epic|
    title = epic.dig("fields", "summary") || ""
    title.match?(/^Group (\d+) - .+/) # Match titles like "Group <number> - <description>"
  end.sort_by do |epic|
    title = epic.dig("fields", "summary") || ""
    title.match(/^Group (\d+) - .+/)[1].to_i rescue Float::INFINITY # Sort by numeric group number
  end.map do |epic|
    title = epic.dig("fields", "summary") || "No title"
    number = title.match(/^Group (\d+) - .+/)[1] rescue "No number" # Extract the number
    {
      title: title,
      number: number,
      key: epic["key"]
    }
  end # end of select-sort-map block
end # end of fetch_epics_with_group_in_name method

# Fetches all child issues for a given epic using JQL to reduce API calls
#
# @param epic_key [String] The Jira epic key (e.g., "SERI-1234").
# @return [Array<Hash>] An array of hashes containing child issue details.
def fetch_child_issues_for_epic(epic_key)
  start_at = 0
  max_results = 50
  all_issues = []

  loop do
    jql_query = %Q("Epic Link" = #{epic_key}) # JQL to fetch child issues for the epic
    endpoint = "search?jql=#{URI.encode_www_form_component(jql_query)}&startAt=#{start_at}&maxResults=#{max_results}"
    response = fetch_jira_data(endpoint)

    issues = response["issues"] || []
    all_issues.concat(issues)

    break if issues.size < max_results # Exit loop if fewer than max_results issues are returned

    start_at += max_results
  end # end of loop block

  all_issues.map do |issue|
    {
      key: issue["key"],
      title: issue.dig("fields", "summary") || "No title",
      type: "Child Issue"
    }
  end # end of map block
end # end of fetch_child_issues_for_epic method

# Fetches all subtasks for a given issue using JQL to reduce API calls
#
# @param issue_key [String] The Jira issue key (e.g., "SERI-1234").
# @return [Array<Hash>] An array of hashes containing subtask details.
def fetch_subtasks_for_issue(issue_key)
  jql_query = %Q(parent = #{issue_key} AND issuetype = Sub-task) # JQL to fetch subtasks directly
  endpoint = "search?jql=#{URI.encode_www_form_component(jql_query)}"
  response = fetch_jira_data(endpoint)

  subtasks = response["issues"] || []
  subtasks.map do |subtask|
    fields = subtask["fields"]
    {
      title: fields["summary"] || "No title",
      url: "#{JIRA_SERVER}/browse/#{subtask['key']}",
      assignee: fields.dig("assignee", "displayName") || "Unassigned",
      status: fields.dig("status", "name") || "No status",
      created_date: fields["created"]&.then { |d| Time.parse(d).strftime("%m/%d/%y") } || "",
      resolution_date: fields["resolutiondate"]&.then { |d| Time.parse(d).strftime("%m/%d/%y") } || ""
    }
  end # end of map block
end # end of fetch_subtasks_for_issue method

# Writes epics, their child issues, and subtasks to a CSV file
#
# @param epics [Array<Hash>] The epics data to write to the CSV file.
def write_epics_and_children_to_csv(epics)
  CSV.open(OUTPUT_CSV, "w") do |csv|
    csv << ["Type", "Project", "Title", "Group Number", "URL", "Assignee", "Status", "Created Date", "Resolution Date"]
    epics.each do |epic|
      # Write epic data
      csv << ["Epic", "Group #{epic[:number]}", epic[:title], epic[:number], "#{JIRA_SERVER}/browse/#{epic[:key]}", "N/A", "N/A", "", ""]

      # Fetch and write child issues for the epic
      child_issues = fetch_child_issues_for_epic(epic[:key])
      child_issues.each do |child|
        # Extract project name from the child issue title
        project_name = child[:title].split(" - ").first.strip
        csv << ["Story", project_name, child[:title], epic[:number], "#{JIRA_SERVER}/browse/#{child[:key]}", "N/A", "N/A", "", ""] # Null date for created and resolution dates

        # Fetch and write subtasks for the child issue
        subtasks = fetch_subtasks_for_issue(child[:key])
        subtasks.each do |subtask|
          csv << ["Subtask", project_name, subtask[:title], epic[:number], subtask[:url], subtask[:assignee], subtask[:status], subtask[:created_date], subtask[:resolution_date]]
        end # end of each block for subtasks
      end   # end of each block for child issues
    end     # end of each block for epics
  end       # end of CSV.open block
  puts "Epics, their child issues, and subtasks successfully written to #{OUTPUT_CSV}"
end         # end of write_epics_and_children_to_csv method

# Main method to fetch and process Jira data
def main
  puts 'Fetching epics with "Group" in the name'
  epics = fetch_epics_with_group_in_name
  write_epics_and_children_to_csv(epics)
end # end of main method

main
