require "base64"

issue_body = <<~BODY
  bitbucket-source-project-key: METRICSGAGE
  bitbucket-source-repo-slug: c_worker_service
  github-target-org: OWNER
  github-target-repo-name: METRICSGAGE.cia_worker_service
  visibility: private
  repo-url: https://stash.OWNER.net/projects/METRICSGAGE/repos/c_worker_service/browse
BODY

encoded_body = Base64.strict_encode64(issue_body)

# Call the script with the encoded body as an argument
system("ruby add_custom_properties_to_repo.rb --body \"#{encoded_body}\"")
