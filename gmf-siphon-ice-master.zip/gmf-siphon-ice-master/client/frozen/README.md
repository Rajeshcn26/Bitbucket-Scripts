# Frozen Client Scripts

This folder contains client-specific scripts for interacting with repositories and teams. These scripts are designed to assist with issue creation, migrations, and metadata retrieval.

## Overview

The scripts in this folder perform the following tasks:

- Clone and update repositories containing metadata about teams and projects.
- Retrieve information about teams, repositories, and their metadata.
- Extract specific details such as CodeOwners, roles, and approvers for teams.
- Provide utility methods to interact with the frozen repositories.

## Files

### `frozenlib.rb`

This file contains the core methods for interacting with the frozen repositories. It includes:

- Methods to clone or update the `Repos` and `Teams` repositories.
- Methods to retrieve data from the repositories, such as:
  - Teams (`teams.json` in the `Teams` repo).
  - Repositories (`*_repos.json` files in the `Repos` repo).
  - Metadata for specific repositories.
  - Roles, approvers, and CodeOwners for teams.

### `test_frozenlib.rb`

This file contains test methods to validate the functionality of the methods in `frozenlib.rb`. It logs the results of each test to a log file.

### `find_issues_with_target_org.rb`

This script finds all open issues in a repository whose body contains a specific target org string (e.g., `github-target-org: OWNER`). It can also update those issues to replace the wrong target org with the correct one.

#### Usage

1. **Set required environment variables:**

   - `GH_TOKEN` or `GITHUB_TOKEN`: A GitHub token with repo access.
   - (Optional) `REPO`: The repository in `owner/repo` format. Defaults to `OWNER/xsiphon` if not set in the script.

2. **Run the script:**

   ```bash
   ruby ../../bb_bin/find_issues_with_target_org.rb
   ```

   - On first run, it will query GitHub for all open issues containing the wrong target org string and save their numbers to `output/issues_with_OWNER.txt`.
   - On subsequent runs, if the file exists, it will process the listed issues and update their bodies, replacing the wrong target org with the correct one.

3. **Output:**
   - The script prints the number of issues found and/or updated.
   - The file `output/issues_with_OWNER.txt` contains the list of affected issue numbers.

#### Example

```bash
export GH_TOKEN=ghp_yourtokenhere
export REPO=OWNER/xsiphon
ruby ../../bb_bin/find_issues_with_target_org.rb
```

### `export_jira_status.rb`

This script exports the status of Jira epics, their child issues, and subtasks to a CSV file. It is useful for reporting and tracking progress on grouped Jira work.

#### Usage

1. **Set required environment variables:**

   - `JIRA_SERVER`: The base URL of your Jira instance (e.g., `https://jira.OWNER.net`). Defaults to this value if not set.
   - `JIRA_PROJECT`: The Jira project key (e.g., `SERI`). Defaults to `SERI` if not set.
   - `JIRA_USER`: Your Jira username or email address.
   - `JIRA_PAT`: **Your Jira password** (not a Personal Access Token).
     > **Note:** You must use your actual Jira password (the one used for Single Sign-On), not a Jira Personal Access Token (PAT). PATs will not work with this script.

2. **Run the script:**

   ```bash
   export JIRA_USER=your CLD username .e.g rschwarz1
   export JIRA_PAT=your-jira-password
   ruby export_jira_status.rb
   ```

   The script will connect to Jira, fetch all epics with "Group" in the title, and output a CSV file at `output/jira_status.csv` containing the epics, their child issues, and subtasks.

3. **Output:**
   - The CSV file `output/jira_status.csv` will contain columns for type, project, title, group number, URL, assignee, status, created date, and resolution date.

#### Example

```bash
export JIRA_USER=your.email@domain.com
export JIRA_PAT=your-jira-password
ruby export_jira_status.rb
```

> **Important:**
>
> - Do **not** use a Jira Personal Access Token (PAT) for `JIRA_PAT`.
> - You must use your actual Jira password (the one used for Single Sign-On authentication).

## Prerequisites

Before running the scripts, ensure the following:

1. Ruby is installed on your system.
2. The required gems (`fileutils`, `json`) are available.
3. The `ORG`, `REPOS`, and `TEAMS` environment variables are set. If not, default values will be used:
   - `ORG`: `default_org`
   - `REPOS`: `default_repos`
   - `TEAMS`: `default_teams`

## How to Run

### Running the Core Scripts

1. Navigate to the `client/frozen` directory.
2. Use the methods in `frozenlib.rb` by requiring the file in your Ruby script or IRB session:

   ```ruby
   require_relative './frozenlib'
   ```

3. Call the desired methods, such as:

   ```ruby
   pull_down_repos_repo
   pull_down_teams_repo
   teams = get_teams_from_repo
   ```

### Running the Tests

1. Navigate to the `client/frozen` directory.
2. Run the `test_frozenlib.rb` script:

   ```bash
   ruby test_frozenlib.rb
   ```

3. The script will reset the log file (`output/test_log.txt`) and execute all test methods. Check the log file for results.

## Log Files

- **Location**: `output/test_log.txt`
- The log file is reset before each test run.
- It contains detailed logs of the test execution, including success and error messages.

## Key Methods in `frozenlib.rb`

### Repository Management

- `pull_down_repos_repo`: Clones or updates the `Repos` repository.
- `pull_down_teams_repo`: Clones or updates the `Teams` repository.

### Data Retrieval

- `get_teams_from_repo`: Retrieves all teams from the `Teams` repository.
- `get_projects_from_repo`: Retrieves all project keys from the `Repos` repository.
- `get_repos_for_project_key(project_key)`: Retrieves all repositories for a specific project key.
- `get_repo_metadata(project_key, repo_name)`: Retrieves metadata for a specific repository.

### Team and Role Information

- `get_team_data(team_name)`: Retrieves data for a specific team.
- `get_codeowners_for_team(team_name)`: Retrieves CodeOwners for a specific team.
- `get_approvers_for_team(team_name)`: Retrieves approvers for a specific team.
- `get_teams_to_add_to_repo(project_key, repo_name)`: Retrieves roles (teams) for a specific repository.

### Metadata Extraction

- `get_cldbid_and_bsn(project_key, repo_name)`: Retrieves CLDBID and BSN for a specific repository.

## Troubleshooting

- **Missing Repositories**: If the `Repos` or `Teams` repositories are not cloned, the scripts will attempt to clone them automatically.
- **Invalid Data**: Ensure the JSON files in the repositories are correctly structured.
- **Environment Variables**: If the `ORG`, `REPOS`, or `TEAMS` environment variables are not set, default values will be used.

## Example Usage

```ruby
require_relative './frozenlib'

# Pull down the repositories
pull_down_repos_repo
pull_down_teams_repo

# Get all teams
teams = get_teams_from_repo
puts "Teams: #{teams}"

# Get metadata for a specific repository
metadata = get_repo_metadata('AP', 'ap_ara')
puts "Metadata: #{metadata}"

# Get roles for a repository
roles = get_teams_to_add_to_repo('CI', 'CI.ci_worker_service')
puts "Roles: #{roles}"
```

## Notes

- Ensure the `output` folder exists and is writable, as logs and cloned repositories will be stored there.
- Modify the `frozenlib.rb` file as needed to customize the behavior for your specific use case.
