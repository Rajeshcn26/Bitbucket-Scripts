require "fileutils"
require "json"
require "csv"
require_relative "../../lib/helpers"
require_relative "./frozen_lib"
require_relative "../../lib/github_helper"

def get_vars_from_issue(issue_body)
  bitbucket_source_project_key_line = issue_body.lines.find { |line| line.strip.start_with?("bitbucket-source-project-key:") }
  bitbucket_source_project_key_name = bitbucket_source_project_key_line.split(":", 2)[1].strip if bitbucket_source_project_key_line

  bitbucket_source_repo_slug_line = issue_body.lines.find { |line| line.strip.start_with?("bitbucket-source-repo-slug:") }
  bitbucket_source_repo_slug_name = bitbucket_source_repo_slug_line.split(":", 2)[1].strip if bitbucket_source_repo_slug_line

  github_target_repo_name_line = issue_body.lines.find { |line| line.strip.start_with?("github-target-repo-name:") }
  github_target_repo_name_name = github_target_repo_name_line.split(":", 2)[1].strip if github_target_repo_name_line

  github_target_org_line = issue_body.lines.find { |line| line.strip.start_with?("github-target-org:") }
  github_target_org_name = github_target_org_line.split(":", 2)[1].strip if github_target_org_line

  [bitbucket_source_project_key_name, bitbucket_source_repo_slug_name, github_target_repo_name_name, github_target_org_name]
end

def is_iac(org = nil, repo = nil)
  issue_id = ENV["ISSUE_ID"]
  repo = ENV["SIPHON_REPO"] || ""
  issue_labels = get_issue_labels(repo, issue_id)

  for label in issue_labels
    puts "Checking label: #{label.name}"
    if label.name.start_with?("iac-")
      return true
    end
  end
  return false
end

def cldbid_and_bsn
  bb_project, bb_repo_name, gh_repo, github_org = get_vars_from_issue(ENV["ISSUE_BODY"])

  gh_repo = ENV["GH_REPO"] || gh_repo
  token = ENV["GH_TOKEN"]

  custom_props = get_custom_properties_for_repo(bb_project, bb_repo_name)

  if custom_props.nil? || custom_props.empty?
    puts "No custom properties found for the project: #{bb_project}"
    return [nil, nil]
  end

  cldbid = custom_props.find { |prop| prop[:property_name] == "cldbid" }&.dig(:value)
  bsn = custom_props.find { |prop| prop[:property_name] == "bsn" }&.dig(:value)
  repo_proj = custom_props.find { |prop| prop[:property_name] == "repository_project" }&.dig(:value)

  [cldbid, bsn, repo_proj]
end

def set_custom_properties_for_repo
  cldbid, bsn, repo_proj = cldbid_and_bsn
  is_iac_value = is_iac("OWNER", "xsiphon") ? "true" : "false"

  bb_project, bb_repo_name, gh_repo, gh_org = get_vars_from_issue(ENV["ISSUE_BODY"])
  repo = ENV["MIGRATED_REPO_NAME"]

  set_github_custom_property(gh_org, repo, "cldbid", cldbid) if cldbid
  set_github_custom_property(gh_org, repo, "bsn", bsn) if bsn
  set_github_custom_property(gh_org, repo, "IaC", is_iac_value)
  set_github_custom_property(gh_org, repo, "repository_project", repo_proj) if repo_proj
end

set_custom_properties_for_repo
