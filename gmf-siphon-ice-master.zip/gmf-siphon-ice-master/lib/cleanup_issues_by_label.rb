# frozen_string_literal: true
#
# copyright © Xebia. All rights reserved. No unauthorized duplication, distribution or copying.
# Date: 2025-05-08
# Author: Rich Schwarz
#
# This software is provided "as is," without warranty of any kind, express or implied, including but not limited to
# the warranties of merchantability, fitness for a particular purpose, and noninfringement. In no event shall the
# authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract,
# tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.
# Use of this software is at your own risk, and no indemnification is provided for any damages or losses incurred.
#
# Summary:
# This script deletes GitHub issues with a specific label from a repository. It uses the GitHub GraphQL API to delete issues.
# The script fetches issues with the specified label, displays them, and prompts the user for confirmation before deletion.
#
# Usage:
# ruby delete_issues_by_label.rb -o ORG -r REPO -l LABEL
#
# Options:
# -o, --org ORG       GitHub organization (can also be set via the GITHUB_ORG environment variable).
# -r, --repo REPO     GitHub repository (can also be set via the GITHUB_REPO environment variable).
# -l, --label LABEL   Label to filter issues for deletion.
#
# Example:
# ruby delete_issues_by_label.rb -o my-org -r my-repo -l "bug"
#
# Note:
# Ensure that the GH_TOKEN environment variable is set with a valid GitHub token for authentication.
#
require "octokit"
require "optparse"
require "net/http"
require "json"
require_relative "../lib/helpers"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def fetch_issues_with_label(repo, label, ignore_below)
  puts "Fetching issues with label '#{label}' from repository '#{repo}'..."
  issues = client.issues(repo, labels: label, state: "open")
  filtered_issues = issues.select { |issue| issue[:number] >= ignore_below }

  if filtered_issues.empty?
    puts "No issues found with label '#{label}' above issue number #{ignore_below}"
    exit
  end

  filtered_issues
end

def display_issues(issues)
  puts ("\nIssues with the specified label:")
  issues.each_with_index do |issue, index|
    puts ("#{index + 1}. #{issue[:title]} (##{issue[:number]})")
  end
end

def delete_issues(repo, issues)
  issues.each do |issue|
    begin
      puts "Deleting issue ##{issue[:number]}: #{issue[:title]}..."
      delete_issue_via_graphql(issue[:node_id]) # Use GraphQL to delete the issue
      # puts "  Issue ##{issue[:number]} deleted successfully."
    rescue StandardError => e
      puts "Error deleting issue ##{issue[:number]}: #{e.message}"
    end
  end
end

def delete_issue_via_graphql(issue_node_id)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  query = <<~GRAPHQL
    mutation {
      deleteIssue(input: {issueId: "#{issue_node_id}"}) {
        clientMutationId
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end
end

def update_issue_type_to_obsolete(issue_node_id, obsolete_issue_type_id)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  query = <<~GRAPHQL
    mutation {
      updateIssue(input: {id: "#{issue_node_id}", issueTypeId: "#{obsolete_issue_type_id}", state: CLOSED}) {
        issue {
          id
        }
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end
end

def update_issue_to_obsolete(repo, issues, obsolete_issue_type_id)
  issues.each do |issue|
    begin
      # puts ("Updating issue ##{issue[:number]}: '#{issue[:title]}' to type 'obsolete'...")
      update_issue_type_to_obsolete(issue[:node_id], obsolete_issue_type_id)
      puts ("Issue ##{issue[:number]}: '#{issue[:title]}' updated to 'obsolete'")
    rescue StandardError => e
      puts ("Error updating issue ##{issue[:number]}: '#{issue[:title]}': #{e.message}")
    end
  end
end

def fetch_issue_type_id(repo, issue_type_name)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  owner, repo_name = repo.split("/")

  query = <<~GRAPHQL
    query {
      repository(owner: "#{owner}", name: "#{repo_name}") {
        issueTypes(first: 10) {
          nodes {
            id
            name
          }
        }
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end

  issue_type = result.dig("data", "repository", "issueTypes", "nodes").find { |node| node["name"].downcase == issue_type_name.downcase }
  raise "Issue type '#{issue_type_name}' not found." unless issue_type

  issue_type["id"]
end

def main
  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: ruby delete_issues_by_label.rb -r REPO -l LABEL [--ignore-below NUMBER]"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end

    opts.on("-r", "--repo REPO", "GitHub repository (e.g., 'owner/repo')") do |repo|
      options[:repo] = repo
    end

    opts.on("-l", "--label LABEL", "Label to filter issues") do |label|
      options[:label] = label
    end

    opts.on("--ignore-below NUMBER", Integer, "Ignore issues with numbers below this value") do |number|
      options[:ignore_below] = number
    end
  end.parse!

  options[:org] ||= ENV["GITHUB_ORG"]
  options[:repo] ||= ENV["GITHUB_REPO"]
  options[:ignore_below] ||= 0 # Default to 0 if not provided

  missing_args = []
  missing_args << "organization (--org or GITHUB_ORG)" if options[:org].nil?
  missing_args << "repository (--repo or GITHUB_REPO)" if options[:repo].nil?
  missing_args << "label (--label)" if options[:label].nil?

  unless missing_args.empty?
    puts "#{Helper::RED}\n  Error: Missing required argument(s): #{missing_args.join(', ')}#{Helper::NORMAL}"
    puts "#{Helper::RED}  Usage: ruby delete_issues_by_label.rb -o ORG -r REPO -l LABEL [--ignore-below NUMBER]#{Helper::NORMAL}"
    exit
  end

  repo = "#{options[:org]}/#{options[:repo]}"
  label = options[:label]
  ignore_below = options[:ignore_below]

  issues = fetch_issues_with_label(repo, label, ignore_below)
  display_issues(issues)

  print "\nDo you want to DELETE these issues or MOVE them to 'obsolete'? (delete/move): "
  action = gets.chomp.downcase

  case action
  when "delete"
    delete_issues(repo, issues)
  when "move"
    obsolete_issue_type_id = fetch_issue_type_id(repo, "obsolete")
    update_issue_to_obsolete(repo, issues, obsolete_issue_type_id)
  else
    puts "Invalid option. No changes were made."
  end
end

main
