# frozen_string_literal: true

# git_helper.rb
# Provides utilities for Git operations: branch creation, committing, and pull requests.
require "fileutils"
require "open3"

class GitHelper
  attr_reader :repo_path, :branch_name, :commit_message, :pr_title, :base_branch, :dry_run

  # Initializes GitHelper with configurable options
  # @param [String] repo_path - Path to the repository (default: '.')
  # @param [String] branch_prefix - Prefix for the new branch name (default: 'feature')
  # @param [String] pr_title - Title for the pull request
  # @param [Boolean] dry_run - Enable dry-run mode to simulate Git operations
  # @param [Object] logger - Optional logger for logging Git actions
  def initialize(repo_path: ".", branch_prefix: "feature", pr_title: "Automated URL Replacement",
                 dry_run: false, logger: nil)
    @repo_path = repo_path
    @branch_name = "#{branch_prefix}/url-replacement-#{Time.now.strftime('%Y%m%d%H%M%S')}"
    @commit_message = "Automated URL replacement commit"
    @pr_title = pr_title
    @dry_run = dry_run
    @logger = logger

    # Dynamically determine the default base branch
    @base_branch = determine_default_branch
  end

  def hard_reset
    log("Performing hard reset and clean on the repository...")
    execute_command("git reset --hard origin/#{@base_branch}")
    execute_command("git clean -fdx")
  end

   # Create a new branch
  def create_branch
    log("Creating new branch: #{@branch_name}")
    execute_command("git checkout -b #{@branch_name}")
  end

  # Stage changes, commit, and push to remote
  def commit_and_push_changes
    log("Staging changes...")
    execute_command("git add .")

    log("Committing changes with message: #{@commit_message}")
    execute_command("git commit -m \"#{@commit_message}\"")

    log("Pushing changes to remote branch: #{@branch_name}")
    execute_command("git push -u origin #{@branch_name}")
  end

  # Create a pull request using GitHub CLI
  def create_pull_request
    log("Creating a pull request with title: #{@pr_title}")
    execute_command("gh pr create --title \"#{@pr_title}\" --body \"Automated changes for URL replacement.\" --base #{@base_branch} --head #{@branch_name}")
  end

  private

  # Executes a shell command and handles errors
  # @param [String] command - Shell command to execute
  def execute_command(command)
    if @dry_run
      log("[DRY-RUN] Would execute: #{command}")
      return
    end

    Dir.chdir(@repo_path) do
      log("Executing: #{command}")
      stdout, stderr, status = Open3.capture3(command)

      if status.success?
        log(stdout.strip) unless stdout.strip.empty?
      else
        log("[ERROR] #{stderr.strip}", level: "ERROR")
        raise "Command failed: #{command}\n#{stderr.strip}"
      end
    end
  end

  # Dynamically determines the default branch for the repository
  # @return [String] - The default branch name (e.g., 'main', 'develop')
  def determine_default_branch
    log("Determining default branch for the repository...")
    stdout, stderr, status = Open3.capture3('git symbolic-ref refs/remotes/origin/HEAD | sed "s@^refs/remotes/origin/@@g"')

    if status.success? && !stdout.strip.empty?
      branch = stdout.strip
      log("Default branch detected: #{branch}", level: "DEBUG")
      branch
    else
      log("[WARN] Could not determine default branch. Defaulting to 'main'.", level: "WARN")
      "main"
    end
  end

  # Logs a message, uses logger if available
  # @param [String] message - The message to log
  # @param [String] level - Log level (default: INFO)
  def log(message, level: "INFO")
    if @logger
      @logger.log(message, level: level)
    else
      puts "[#{level}] #{message}"
    end
  end
end
