require "net/http"
require "json"
require "uri"
require "base64"


class GitHubSubIssueClient
  API_VERSION = "2022-11-28"
  BASE_URL = "https://api.github.com"


  def initialize(logger, github_token)
    @logger = logger
    @github_token = github_token
  end


  # --- Helper Methods ---
  def create_sub_issue(owner:, repo:, parent_issue_id:, title:, body:, assignees: [], labels: [], type: nil)
    begin
      puts "Creating sub-issue: #{title}. body length: #{body.length}"
      new_issue = create_issue(owner: owner, repo: repo, title: title, body: body, assignees: assignees, labels: labels, type: type)
      response = add_sub_issue(owner: owner, repo: repo, parent_issue: parent_issue_id, sub_issue_id: new_issue[:id])

      return response
    rescue => e
      logger.error("Failed to create sub-issue: #{e.message}")
      return nil
    end
  end

  def create_issue(owner:, repo:, title:, body: nil, assignees: [], labels: [], milestone: nil, type: nil)
    payload = { title: title }
    payload[:body] = body if body
    payload[:assignees] = assignees unless assignees.empty?
    payload[:labels] = labels unless labels.empty?
    payload[:milestone] = milestone if milestone
    payload[:type] = type if type

    post_json("/repos/#{owner}/#{repo}/issues", payload)
  end

  def get_issue(owner:, repo:, issue_number:)
    get_json("/repos/#{owner}/#{repo}/issues/#{issue_number}")
  end

  def get_issue_assignees(owner:, repo:, issue_number:)
    begin
      issue = get_issue(owner: owner, repo: repo, issue_number: issue_number)
      assignees = issue[:assignees] || []

      return assignees.map { |a| a[:login] }
    rescue => e
      logger.warn("Failed to fetch assignees for issue ##{issue_number}: #{e.message}")
      return []
    end
  end


  # --- Sub Issue Methods ---
  def add_sub_issue(owner:, repo:, parent_issue:, sub_issue_id:, replace_parent: false)
    post_json("/repos/#{owner}/#{repo}/issues/#{parent_issue}/sub_issues", {
      sub_issue_id: sub_issue_id,
      replace_parent: replace_parent
    })
  end

  def remove_sub_issue(owner:, repo:, parent_issue:, sub_issue_id:)
    delete_json("/repos/#{owner}/#{repo}/issues/#{parent_issue}/sub_issue", {
      sub_issue_id: sub_issue_id
    })
  end

  def list_sub_issues(owner:, repo:, parent_issue:)
    get_json("/repos/#{owner}/#{repo}/issues/#{parent_issue}/sub_issues")
  end

  def reprioritize_sub_issue(owner:, repo:, parent_issue:, sub_issue_id:, after_id: nil, before_id: nil)
    body = { sub_issue_id: sub_issue_id }

    body[:after_id] = after_id if after_id
    body[:before_id] = before_id if before_id

    patch_json("/repos/#{owner}/#{repo}/issues/#{parent_issue}/sub_issues/priority", body)
  end


  private

  def auth_headers
    {
      "Authorization" => "token #{@github_token}",
      "Accept" => "application/vnd.github+json",
      "X-GitHub-Api-Version" => API_VERSION,
      "Content-Type" => "application/json"
    }
  end

  def full_uri(path)
    URI("#{BASE_URL}#{path}")
  end

  def get_json(path)
    uri = full_uri(path)
    req = Net::HTTP::Get.new(uri, auth_headers)

    send_request(uri, req)
  end

  def post_json(path, data)
    uri = full_uri(path)
    req = Net::HTTP::Post.new(uri, auth_headers)

    req.body = data.to_json
    send_request(uri, req)
  end

  def delete_json(path, data)
    uri = full_uri(path)
    req = Net::HTTP::Delete.new(uri, auth_headers)

    req.body = data.to_json
    send_request(uri, req)
  end

  def patch_json(path, data)
    uri = full_uri(path)
    request = Net::HTTP::Patch.new(uri, auth_headers)

    request.body = data.to_json
    send_request(uri, request)
  end

  def send_request(uri, request)
    puts ">>> Request: #{request.method} #{uri}"
    puts ">>> Headers:"
    request.each_header { |k, v| puts "    #{k}: #{v}" }
    puts ">>> Body:"
    puts request.body

    response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
      http.request(request)
    end

    puts "<<< Response: #{response.code}"
    puts response.body

    raise "GitHub API error: #{response.code} - #{response.body}" unless response.code.to_i < 300
    return JSON.parse(response.body, symbolize_names: true)
  end

end


# --- Workflow Entry Point ---
if $PROGRAM_NAME == __FILE__
  token = ENV["GH_TOKEN"]
  github_repo_full = ENV["GH_REPO"] # Format: "owner/repo"
  owner, repo = github_repo_full.split("/", 2)
  parent_issue_id = ENV["PARENT_ISSUE_ID"].to_i
  issue_title = ENV["ISSUE_TITLE"]
  encoded_body = ENV["ISSUE_BODY"]
  issue_body = encoded_body ? Base64.decode64(encoded_body) : nil
  labels = ENV["LABELS"] ? ENV["LABELS"].split(",") : []
  assignees = ENV["ASSIGNEES"] ? ENV["ASSIGNEES"].split(",") : []


  client = GitHubSubIssueClient.new(nil, token)

  client.create_sub_issue(
    owner: owner,
    repo: repo,
    parent_issue_id: parent_issue_id,
    title: issue_title,
    body: issue_body,
    assignees: assignees,
    labels: labels,
    type: "task"
  )
end
