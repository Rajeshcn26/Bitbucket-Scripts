# frozen_string_literal: true
#
# Script to fetch all issues that do not have a specific label.
# Date: 2025-05-15
# Author: Rich Schwarz

require "json"
require "net/http"
require "uri"
require "optparse"
require "fileutils"
require_relative "helpers"
require "rufus-scheduler"

$gh_token = ENV["GH_PAT"]
MAX_PAGES = ENV["MAX_PAGES"]&.to_i || 1000 # Default to 1000 if not set

# Define constants for labels
LABEL_HAS_JENKINSFILE = "status-jenkinsfile-true"
LABEL_NO_JENKINSFILE = "status-jenkinsfile-false"
LABEL_JENKINSFILE_ERROR = "status-jenkinsfile-error"
LABEL_REPO_DOESNT_EXIST = "status-repo-doesnt-exist"
LABEL_DO_NOT_MIGRATE = "status-do-not-migrate"

# Define a file to track repositories that failed during checkout
FAILED_REPOS_FILE = File.join(File.expand_path("../output", __dir__), "label_issues_with_jenkinsfiles_failed_repos.txt")

# Define a constant for test mode
TEST_MODE = false

def validate_bitbucket_credentials
  # Validate Bitbucket credentials are available
  bb_user = ENV["BB_ACCT_USER"]
  bb_token = ENV["BB_ACCT_TOKEN"]
  if bb_user.nil? || bb_token.nil?
    puts "[ERROR] Missing Bitbucket credentials. Ensure BB_ACCT_USER and BB_ACCT_TOKEN are set."
    exit(1)
  end
  { user: bb_user, token: bb_token }
end # end of validate_bitbucket_credentials method

# Validate credentials once at script startup
BB_CREDENTIALS = validate_bitbucket_credentials

def ensure_output_folder
  # Ensure the output folder exists
  FileUtils.mkdir_p(File.expand_path("../output", __dir__))
end # end of ensure_output_folder method

def parse_args
  options = {}
  parser = OptionParser.new do |opts|
    opts.banner = "Usage: label_issues_with_jenkinsfiles.rb [options]"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end

    opts.on("-r", "--repo REPO", "GitHub repository") do |repo|
      options[:repo] = repo
    end

    opts.on("-h", "--help", "Show this help message") do
      puts opts
      exit
    end
  end

  parser.parse!

  # Use environment variables as defaults if options are not provided
  options[:org] ||= ENV["GITHUB_ORG"] || "OWNER"
  options[:repo] ||= ENV["GITHUB_REPO"] || "xsiphon"

  if options[:org].nil? || options[:repo].nil?
    puts "Error: --org and --repo options are required."
    puts parser.help
    exit(1)
  end

  options
end # end of parse_args method

# for testing, filter labels like below and make sure some issues are labeled with "user-test"
        # issues(first: 100, after: $cursor, states: [OPEN] labels: ["user-test"]) {

TEST_FILTER = ""
if TEST_MODE
  TEST_FILTER = 'labels: ["user-test"]'
end

def fetch_issues_without_label(org, repo, label_to_exclude)
  puts "Fetching issues for org '#{org}' and repo '#{repo}'"
  query = <<-GRAPHQL
    query($cursor: String) {
      repository(owner: "#{org}", name: "#{repo}") {
        issues(first: 100, after: $cursor, states: [OPEN] #{TEST_FILTER} ) {
          edges {
            node {
              url
              title
              state
              issueType {
                name
              }
              labels(first: 50) {
                nodes {
                  name
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
          }
        }
      }
    }
  GRAPHQL

  issues = []
  cursor = nil
  page_count = 0

  loop do
    print  "#{page_count + 1}, " # Print as we go to show progress - all on one line
    break if MAX_PAGES && page_count >= MAX_PAGES # Stop if max pages limit is reached

    response = execute_graphql_query(query, { cursor: cursor })
    if response.code.to_i != 200
      puts "[ERROR] GraphQL query failed with status: #{response.code}"
      puts "[ERROR] Response body: #{response.body}"
      exit(1)
    end

    data = JSON.parse(response.body)
    if data["errors"]
      puts "[ERROR] GraphQL query returned errors: #{data["errors"]}"
      exit(1)
    end

    repository_data = data.dig("data", "repository")
    if repository_data.nil?
      puts "[ERROR] No repository data found in response. Check if the org/repo is correct."
      exit(1)
    end

    issues_data = repository_data["issues"]
    if issues_data.nil? || issues_data["edges"].empty?
      puts "No more issues found."
      break
    end

    issues.concat(issues_data["edges"].map { |edge| edge["node"] })

    page_info = issues_data["pageInfo"]
    break unless page_info["hasNextPage"]

    cursor = page_info["endCursor"]
    page_count += 1
    sleep 1
  end # end of loop

  issues.select! do |issue|
    next false if skip_due_to_label_or_type?(issue)
    true
  end # end of issues.select! block

  puts "Total issues fetched: #{issues.size}"
  issues
end # end of fetch_issues_without_label method

def skip_due_to_label_or_type?(issue)
  label_names = extract_label_names(issue)
  return true if has_status_jenkinsfile_label?(label_names, issue)
  return true if has_error_label?(label_names, issue)
  return true if is_task_issue?(issue)
  false
end # end of skip_due_to_label_or_type? method

def extract_label_names(issue)
  # Extracts all label names from the issue
  issue["labels"]["nodes"].map { |label| label["name"] }
end # end of extract_label_names method

def has_status_jenkinsfile_label?(label_names, issue)
  # Checks if any label starts with status-jenkinsfile-
  if label_names.any? { |name| name.start_with?("status-jenkinsfile-") }
    # puts "issue #{issue['url']} already searched"
    return true
  end
  false
end # end of has_status_jenkinsfile_label? method

def has_error_label?(label_names, issue)
  # Checks if the error label is present
  if label_names.include?(LABEL_JENKINSFILE_ERROR)
    puts "issue #{issue['url']} previously marked as error, skipping"
    return true
  end
  false
end # end of has_error_label? method

def is_task_issue?(issue)
  # Checks if the issue type is task
  if issue["issueType"] && issue["issueType"]["name"].to_s.downcase == "task"
    puts "Skipping task #{issue['url']}"
    return true
  end
  false
end # end of is_task_issue? method

def execute_graphql_query(query, variables = {})
  uri = URI("https://api.github.com/graphql")
  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{$gh_token}"
  request["Content-Type"] = "application/json"
  request.body = { query: query, variables: variables }.to_json

  Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
    http.request(request)
  end
end # end of execute_graphql_query method

def construct_bitbucket_repo_url(issue_title)
  # puts "Constructing Bitbucket repository URL from issue title: #{issue_title}"
  # Extract the portion after the double colon (::) and parse the project key and repository slug
  # Assuming the title format is: <some_text>::<project_key>/<repo_slug>
  match = issue_title.match(%r{::(?<project_key>[^/]+)/(?<repo_slug>[^/]+)$})
  if match
    project_key = match[:project_key]
    repo_slug = match[:repo_slug]
    bb_server_url = ENV["BB_SERVER_URL"]

    if bb_server_url.nil? || bb_server_url.strip.empty?
      puts "[ERROR] BB_SERVER_URL environment variable is not set or empty."
      return nil
    end

    # Construct the repository URL in the format: https://<bb_server_url>/scm/<project_key>/<repo_slug>.git
    repo_url = "#{bb_server_url}/scm/#{project_key}/#{repo_slug}.git"
    # puts "URL: #{repo_url}"
    return repo_url
  else
    puts "[ERROR] Unable to construct Bitbucket repository URL from issue title: #{issue_title}"
    return nil
  end
end # end of construct_bitbucket_repo_url method

def read_failed_repos
  # Read the list of failed repositories from the file
  if File.exist?(FAILED_REPOS_FILE)
    File.readlines(FAILED_REPOS_FILE).map(&:strip)
  else
    []
  end
end # end of read_failed_repos method

def add_to_failed_repos(repo_url, issue_url = nil)
  ensure_output_folder # Ensure the output folder exists
  File.open(FAILED_REPOS_FILE, "a") do |file|
    file.puts(repo_url)
  end
  puts "::error:: Repository added to failed list: #{repo_url}" # Log an error message
  if issue_url
    begin
      update_github_issue(issue_url, LABEL_JENKINSFILE_ERROR, "An error occurred while processing this repository.")
    rescue => e
      puts "[ERROR] Failed to label issue with error: #{e.message}"
    end
  end
end # end of add_to_failed_repos method

def shallow_clone_repo(repo_url, clone_path, issue_url = nil)
  timestamp = Time.now.in_time_zone("Eastern Time (US & Canada)").strftime("%H:%M:%S EST")
  puts "  #{timestamp} Cloning: #{repo_url}"
  clone_start_time = Time.now

  # Ensure the clone path is cleaned up before cloning
  clean_up_clone_path(clone_path)

  # Use --mirror for fast, all-branches clone with authorization header
  command = %(git clone --mirror "#{repo_url}" "#{clone_path}" -c core.protectNTFS=true -c core.protectHFS=true -c http.extraHeader="Authorization: Bearer #{BB_CREDENTIALS[:token]}")
  output = %x(#{command} 2>&1)
  unless $?.success?
    puts "[ERROR] Failed to clone repository: #{output}"
    handle_clone_error(repo_url, issue_url, output)
    return false
  end

  clone_end_time = Time.now
  puts "  Clone time: #{clone_end_time - clone_start_time} seconds"
  true
end # end of shallow_clone_repo method

def handle_clone_error(repo_url, issue_url, output)
  add_to_failed_repos(repo_url, issue_url)
  if issue_url && output =~ /not found/i
    begin
      update_github_issue(issue_url, [LABEL_REPO_DOESNT_EXIST, LABEL_DO_NOT_MIGRATE], "Repository not found. Marked as do not migrate.")
      puts  "Repository not found. Marked as do not migrate and repo doesn't exist."
    rescue => e
      puts "[ERROR] Failed to label issue as repo doesn't exist or do not migrate: #{e.message}"
    end
  end
end # end of handle_clone_error method

def clean_up_clone_path(clone_path)
  if Dir.exist?(clone_path)    
    FileUtils.rm_rf(clone_path)
  end
end # end of clean_up_clone_path method


def find_jenkinsfile_using_git(repo_path)
  start_time = Time.now

  Dir.chdir(repo_path) do
    # Searches for Jenkinsfile in all branches.
    # Lists all branches found to contain a Jenkinsfile at the root.
    shell_cmd = <<~SHELL.strip
      git for-each-ref --format="%(refname:short)" refs/heads refs/remotes | while read branch; do
      if git ls-tree -r --name-only "$branch" 2>/dev/null | grep -q "^Jenkinsfile$"; then
        git ls-tree -r --name-only "$branch" | grep "^Jenkinsfile$" | while read file_path; do
        echo "Branch: $branch"
        exit 0
        done
        exit 0
      fi
      done
    SHELL
    
    # finds all branches with Jenkinsfile
    # shell_cmd = 'git for-each-ref --format="%(refname:short)" refs/heads refs/remotes | while read branch; do if git ls-tree -r --name-only "$branch" 2>/dev/null | grep -q "^Jenkinsfile$"; then git ls-tree -r --name-only "$branch" | grep "^Jenkinsfile$" | while read file_path; do echo "First Branch: $branch"; done; fi; done'

    output = %x(bash -c '#{shell_cmd}')
    found = !output.strip.empty?
    puts output unless output.strip.empty?
    end_time = Time.now
    puts "  Search time: #{end_time - start_time} seconds"
    return found
  end # end of Dir.chdir block

  false
end # end of find_jenkinsfile_using_git method

def initialize_octokit_client
  puts "Initializing Octokit client locally..."

  client = Octokit::Client.new(access_token: $gh_token)
  client.auto_paginate = true

  client
end # end of initialize_octokit_client method

def update_github_issue(issue_url, label, comment)
  # puts "Updating GitHub issue: #{issue_url} with label: #{label}"
  issue_number = issue_url.split("/").last
  repo_full_name = issue_url.split("/")[-4..-3].join("/")

  labels = label.is_a?(Array) ? label : [label]
  $client.add_labels_to_an_issue(repo_full_name, issue_number, labels)
  # puts "Added label '#{label}' to issue ##{issue_number} in repo '#{repo_full_name}'"
end # end of update_github_issue method

def process_issues(org, repo, label_to_exclude)
  puts "\n\nStarting to process issues for org '#{org}' and repo '#{repo}'"
  failed_repos = read_failed_repos 
  issues = fetch_issues_without_label(org, repo, label_to_exclude)
  issues.shuffle! 
  issues.each do |issue|
    puts "\n:::: Processing: #{issue['url']}"
    repo_url = construct_bitbucket_repo_url(issue["title"])
    next unless repo_url
    if failed_repos.include?(repo_url)
      puts "Skipping previously failed repository: #{repo_url}"
      next
    end

    clone_path = File.join(Dir.pwd, "_repos")
    clean_up_clone_path(clone_path) # Ensure cleanup before processing
    if shallow_clone_repo(repo_url, clone_path, issue["url"])
      # puts "Searching for Jenkinsfile across all branches using Git..."
      has_jenkinsfile = find_jenkinsfile_using_git(clone_path)

      # Label based on the result
      label = has_jenkinsfile ? LABEL_HAS_JENKINSFILE : LABEL_NO_JENKINSFILE
      comment = has_jenkinsfile ? "A Jenkinsfile was found in the repository." : "No Jenkinsfile was found in the repository."
      puts "  Issue #{issue['url']} labeled as: #{label}"
      update_github_issue(issue["url"], label, comment)
    else
      puts "[ERROR] Skipping issue #{issue['url']} due to clone failure."
      # Labeling is handled in shallow_clone_repo/handle_clone_error
    end

    # clean_up_clone_path(clone_path) # Ensure cleanup after processing
  end # end of issues.each block
end # end of process_issues method

def read_failed_repos_file
  # Read the list of failed repositories from the file
  if File.exist?(FAILED_REPOS_FILE)
    File.readlines(FAILED_REPOS_FILE).map(&:strip)
  else
    []
  end
end # end of read_failed_repos_file method

def print_failed_repos_file
  # Print failed repos file with a row of * above and below
  if File.exist?(FAILED_REPOS_FILE)
    failed_repos_content = File.read(FAILED_REPOS_FILE)
    puts "\n" + "*" * 80
    puts "Failed repositories:"
    puts failed_repos_content
    puts "*" * 80
  end
end # end of print_failed_repos_file method

def push_failed_repos_file_to_branch
  # Commit and push the failed repos file to a dedicated branch with retries
  branch_name = "jenkinsfile_failed_repos"
  return unless File.exist?(FAILED_REPOS_FILE) && File.size(FAILED_REPOS_FILE) > 0

  # Configure git user/email
  user_email = ENV["SIPHON_APP_ID"] ? "#{ENV["SIPHON_APP_ID"]}+#{ENV["SIPHON_APP_NAME"]}[bot]@users.noreply.github.com" : "siphon[bot]@users.noreply.github.com"
  user_name = ENV["SIPHON_APP_NAME"] ? "#{ENV["SIPHON_APP_NAME"]}[bot]" : "siphon[bot]"
  system("git config user.email \"#{user_email}\"")
  system("git config user.name \"#{user_name}\"")

  # Check if branch exists remotely
  branch_exists = system("git ls-remote --exit-code --heads origin #{branch_name} > NUL 2>&1")
  if branch_exists
    # Branch exists, fetch and checkout
    fetch_ok = system("git fetch origin #{branch_name}:#{branch_name} 2>NUL")
    checkout_ok = system("git checkout #{branch_name} 2>NUL")
  else
    # Branch does not exist, create it from current branch
    checkout_ok = system("git checkout -b #{branch_name} 2>NUL")
  end

  unless checkout_ok
    puts "[ERROR] Could not create or checkout branch '#{branch_name}'. Skipping push."
    return
  end

  # Add and commit
  system("git add -f #{FAILED_REPOS_FILE}")
  system("git commit -m \"Update failed repositories list\" || true")

  # Pull before push
  system("git pull origin #{branch_name} --rebase 2>NUL || true")

  # Push with up to 5 retries
  attempts = 0
  while attempts < 5
    system("git push origin #{branch_name}")
    break if $?.success?
    attempts += 1
    puts "git push failed, attempt #{attempts}. Retrying in 2 seconds..."
    sleep 2
    system("git pull origin #{branch_name} --rebase 2>NUL || true")
  end # end of push retry loop

  # Merge branch into main so the file is in the code base
  system("git checkout main")
  system("git pull origin main")
  system("git merge #{branch_name}")
  system("git push origin main")

  # Switch back to previous branch if needed
  # (optional, can be omitted if you want to stay on main)
end # end of push_failed_repos_file_to_branch method

def setup_interrupt_handler
  # Setup signal handler for graceful shutdown on Ctrl-C
  Signal.trap("INT") do
    puts "\nInterrupt signal received. Attempting to push failed repos file before exit..."
    print_failed_repos_file
    push_failed_repos_file_to_branch
    puts "Exiting after interrupt."
    exit(1)
  end
end # end of setup_interrupt_handler method

def main
  $client = initialize_octokit_client

  setup_interrupt_handler # Setup Ctrl-C handler at the start
  ensure_output_folder # Ensure the output folder exists at the start
  options = parse_args
  org = options[:org]
  repo = options[:repo]
  label = options[:label]

  puts "Fetching issues without label: #{label}"
  process_issues(org, repo, label)
  print_failed_repos_file
  push_failed_repos_file_to_branch
end # end of main method

main

