module JenkinsfileSearchHelper
  # Searches for Jenkinsfile in all branches of the given repository path
  def self.find_jenkinsfile_using_git(repo_path)
    # Get all branches in the repository
    branches = get_all_branches(repo_path)

    # Check each branch for the presence of Jenkinsfile
    jenkinsfile_found = branches.any? do |branch|
      checkout_branch(repo_path, branch)
      File.exist?(File.join(repo_path, 'Jenkinsfile'))
    end

    # Return the appropriate label based on the search result
    return jenkinsfile_found ? 'status-jenkinsfile-true' : 'status-jenkinsfile-false'
  end # end of find_jenkinsfile_using_git method

  # Retrieves all branches in the repository
  def self.get_all_branches(repo_path)
    # Run git command to list all branches
    branches = `git -C #{repo_path} branch -r`.split("\n").map do |branch|
      branch.strip.sub('origin/', '')
    end

    return branches
  end # end of get_all_branches method

  # Checks out the specified branch in the repository
  def self.checkout_branch(repo_path, branch)
    # Run git command to checkout the branch
    `git -C #{repo_path} checkout #{branch}`
  end # end of checkout_branch method
end # end of JenkinsfileSearchHelper module