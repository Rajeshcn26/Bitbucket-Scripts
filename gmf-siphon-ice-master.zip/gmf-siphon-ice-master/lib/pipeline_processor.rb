# frozen_string_literal: true

# pipeline_processor.rb
# Orchestrates file processing for Jenkins pipelines.

require "find"
require_relative "file_processor"

class PipelineProcessor
  attr_reader :logger, :file_processor, :file_extension, :file_name

  def initialize(logger, file_processor, file_name: nil, file_extension: nil)
    @logger = logger
    @file_processor = file_processor
    @file_name = file_name
    @file_extension = file_extension
  end

  # Processes all matching files in a directory
  # @param [Regexp] pattern - Regex pattern to search for
  # @param [String] replacement - Replacement string
  # @return [Array] - Array of updated files
  def process_files(pattern, replacement)
    # If no file_name and no file_extension are provided, default to scanning for '.groovy' files
    if file_name.nil? && file_extension.nil?
      @file_extension = ".groovy"
    end

    updated_files = []
    skipped_files = []

    Find.find(".") do |path|
      next unless File.file?(path)

      # Apply filtering logic based on file_name and file_extension
      if file_name
        # If file_name is specified:
        if file_extension
          # Both file_name and file_extension must match the file exactly
          next unless File.basename(path) == "#{file_name}#{file_extension}"
        else
          # If only file_name is given (like Jenkinsfile with no extension)
          next unless File.basename(path) == file_name
        end
      else
        # If no file_name is given, rely on file_extension
        # Since we defaulted file_extension to '.groovy' if none was given,
        # this will scan all .groovy files
        if file_extension
          next unless File.extname(path) == file_extension
        end
      end

      logger.log("Processing: #{path}", level: "INFO")

      begin
        if file_processor.process_file(path, pattern, replacement)
          updated_files << path
        else
          skipped_files << path
        end
      rescue StandardError => e
        logger.log("[ERROR] Failed to process #{path}: #{e.message}", level: "ERROR")
        skipped_files << path
      end
    end

    logger.log("Processed #{updated_files.size} file(s), skipped #{skipped_files.size}.", level: "INFO")
    updated_files
  end
end
