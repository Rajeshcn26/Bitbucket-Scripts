# frozen_string_literal: true

# backup_manager.rb
# This class handles file backup operations in a safe and configurable manner.
# Features include error handling, optional backup directories, timestamped backups,
# and a dry-run mode for testing purposes.

require "fileutils" # Standard Ruby library for file and directory operations

class BackupManager
  # Initializes the BackupManager with optional configurations
  # @param [String] backup_suffix - Suffix added to backup files (default: '.bak')
  # @param [String] backup_dir - Directory to store backup files (optional)
  # @param [Boolean] dry_run - Enables dry-run mode (no actual file modifications)
  # @param [Object] logger - Optional logger for feedback (must respond to `log` method)
  def initialize(backup_suffix: ".bak", backup_dir: nil, dry_run: false, logger: nil)
    @backup_suffix = backup_suffix # Suffix for backup files
    @backup_dir = backup_dir       # Directory where backups are stored (if specified)
    @dry_run = dry_run             # Dry-run mode flag (simulates file operations)
    @logger = logger               # Logger for feedback; defaults to nil
  end

  # Creates a backup of the specified file
  # @param [String] file_path - Path to the file to back up
  # @return [String, nil] - Path to the backup file, or nil if backup failed
  def backup_file(file_path)
    # Validate that the file exists and is readable
    if file_path.nil? || file_path.strip.empty?
      log("[ERROR] Cannot back up #{file_path}: Invalid file path.")
      return nil
    end

    unless File.exist?(file_path) && File.readable?(file_path)
      log("[ERROR] Cannot back up #{file_path}: File does not exist or is not readable.")
      return nil
    end

    # Generate a unique backup file name with timestamp
    backup_filename = generate_backup_filename(file_path)

    # Determine the full backup path (in specified directory or alongside the original file)
    backup_path = @backup_dir ? File.join(@backup_dir, File.basename(backup_filename)) : backup_filename

    # Handle dry-run mode: simulate the backup operation
    if @dry_run
      log("[DRY-RUN] Would create backup: #{backup_path}")
      return backup_path
    end

    # Perform the backup operation with error handling
    begin
      ensure_backup_directory # Ensure backup directory exists if specified
      FileUtils.cp(file_path, backup_path) # Copy the original file to the backup location
      log("[BACKUP] Created backup: #{backup_path}")
      backup_path
    rescue StandardError => e
      log("[ERROR] Failed to back up #{file_path}: #{e.message}")
      nil
    end
  end

  private

  # Generates a unique backup file name with a timestamp
  # @param [String] file_path - Path to the original file
  # @return [String] - The backup file name with a timestamp
  def generate_backup_filename(file_path)
    # Add the current timestamp to the backup file name to avoid overwrites
    timestamp = Time.now.strftime("%Y%m%d%H%M%S") # Format: YYYYMMDDHHMMSS
    "#{file_path}#{@backup_suffix}.#{timestamp}"
  end

  # Ensures the backup directory exists
  # Creates the directory if it does not already exist
  def ensure_backup_directory
    return unless @backup_dir # Skip if no backup directory is specified

    # Use FileUtils.mkdir_p to create the directory and its parents if they don't exist
    FileUtils.mkdir_p(@backup_dir) unless Dir.exist?(@backup_dir)
    log("[INFO] Ensured backup directory exists: #{@backup_dir}")
  end

  # Logs messages to the logger if provided; otherwise, prints to the console
  # @param [String] message - The message to log
  def log(message)
    if @logger
      @logger.log(message) # Use the provided logger
    else
      puts message # Default to console output
    end
  end
end
