# frozen_string_literal: true

# file_processor.rb
# Handles validation, reading, updating, and writing file content.

require_relative "../lib/file_utils_ext"
require_relative "../lib/log_manager"
require "fileutils"

class FileProcessor
  attr_reader :logger, :backup_manager, :dry_run

  # Initialize with a LogManager instance as logger and a backup_manager instance
  # @param [LogManager] logger - Instance of LogManager for logging
  # @param [BackupManager] backup_manager - BackupManager instance for backing up files
  # @param [Boolean] dry_run - If true, no actual writes or backups are performed
  def initialize(logger, backup_manager, dry_run: false)
    raise ArgumentError, "Logger cannot be nil" if logger.nil?
    raise ArgumentError, "BackupManager cannot be nil" if backup_manager.nil?

    @logger = logger
    @backup_manager = backup_manager
    @dry_run = dry_run

    logger.log("FileProcessor initialized with dry_run=#{dry_run}", level: "DEBUG")
  end

  # Validates a file based on its existence, readability, and size
  # @param [String] file_path - Path to the file
  # @return [Boolean] - True if file is valid, otherwise false
  def valid_file?(file_path)
    logger.log("Checking file validity: #{file_path}", level: "DEBUG")

    unless FileUtilsExt.valid_file?(file_path)
      logger.log("#{file_path} is not a valid file.", level: "WARN")
      return false
    end

    unless FileUtilsExt.readable?(file_path)
      logger.log("#{file_path} is not readable.", level: "WARN")
      return false
    end

    if FileUtilsExt.too_large?(file_path)
      logger.log("#{file_path} is too large and was skipped.", level: "WARN")
      return false
    end

    logger.log("#{file_path} passed validation.", level: "DEBUG")
    true
  end

  # Processes a file: backs it up, replaces content, and writes the file
  # @param [String] file_path - Path to the file
  # @param [Regexp] pattern - Regex pattern to search for
  # @param [String] replacement - Replacement string
  # @return [Boolean] - True if file was updated, otherwise false
  def process_file(file_path, pattern, replacement)
    logger.log("Entering process_file with file=#{file_path}, pattern=#{pattern.inspect}, replacement=#{replacement.inspect}, dry_run=#{dry_run}", level: "DEBUG")

    raise ArgumentError, "Pattern cannot be nil" if pattern.nil?
    raise ArgumentError, "Replacement cannot be nil" if replacement.nil?

    unless valid_file?(file_path)
      logger.log("Validation failed for #{file_path}", level: "WARN")
      return false
    end

    logger.log("Reading file: #{file_path}", level: "DEBUG")
    content = read_file(file_path)
    return false if content.nil? # If read failed, error already logged

    logger.log("Original file content (#{file_path}):\n#{content}", level: "DEBUG")

    unless content.match?(pattern)
      logger.log("No matches for pattern #{pattern.inspect} in #{file_path}", level: "INFO")
      return false
    end

    new_content = content.gsub(pattern, replacement)
    logger.log("New file content after replacement (#{file_path}):\n#{new_content}", level: "DEBUG")

    if content == new_content
      logger.log("No changes detected for #{file_path}. Content remained the same.", level: "INFO")
      return false
    end

    if dry_run
      logger.log("Dry-run mode enabled. No changes will be made to #{file_path}", level: "INFO")
      return true
    end

    logger.log("Attempting to back up #{file_path}", level: "DEBUG")
    backup_path = backup_manager.backup_file(file_path)
    if backup_path.nil?
      logger.log("Backup creation failed for #{file_path}", level: "WARN")
    else
      logger.log("Backup created: #{backup_path}", level: "INFO")
    end

    logger.log("Writing updated content to #{file_path}", level: "DEBUG")
    unless write_file(file_path, new_content)
      logger.log("Failed to write updated content to #{file_path}", level: "ERROR")
      return false
    end

    # Double-check what was actually written
    post_write_content = read_file(file_path)
    logger.log("Post-write file content (#{file_path}):\n#{post_write_content}", level: "DEBUG") if post_write_content
    unless post_write_content == new_content
      logger.log("WARNING: After writing, file content does not match expected new content!\nExpected:\n#{new_content}\nGot:\n#{post_write_content}", level: "WARN")
    end

    logger.log("Updated: #{file_path}", level: "INFO")
    true
  rescue StandardError => e
    logger.log("Error during file processing at '#{file_path}': #{e.message}\nBacktrace: #{e.backtrace.join("\n")}", level: "ERROR")
    false
  end

  private

  # Reads the file content with UTF-8 encoding, returns the content or nil if an error occurs
  def read_file(file_path)
    File.read(file_path, encoding: "UTF-8")
  rescue StandardError => e
    logger.log("Error reading file #{file_path}: #{e.message}", level: "ERROR")
    nil
  end

  # Writes the given content to the file with UTF-8 encoding
  # Returns true if successful, false otherwise
  def write_file(file_path, content)
    File.write(file_path, content, encoding: "UTF-8")
    true
  rescue StandardError => e
    logger.log("Error writing file #{file_path}: #{e.message}", level: "ERROR")
    false
  end
end
