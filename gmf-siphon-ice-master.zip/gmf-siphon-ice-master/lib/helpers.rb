# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz
#

# helpers.rb

require "openssl"
require "jwt"
require "net/http"
require "json"
require "octokit"
require "active_support/time" # Ensure ActiveSupport is available for time zone conversion


module Helper
  RED = "\e[31m"
  BLUE = "\e[34m"
  GREEN = "\e[32m"
  YELLOW = "\e[33m"
  NORMAL = "\e[0m"
  DARK_GRAY = "\e[90m"
  WARNING = "warning"
  ERROR = "error"
  INFO = "info"

  #######################################################
  # Logger
  #######################################################
  # Adds a log message to a file and optionally prints it to the screen.
  #
  # Parameters:
  # - file: The file path to write the log message to.
  # - msg: The log message to be written.
  # - screenEcho: A boolean indicating whether to print the log message to the screen.
  # - include_timestamp: A boolean indicating whether to prefix the message with a timestamp.
  #
  def self.log(file, msg, screen_echo, include_timestamp = false)
    timestamp = Time.now.in_time_zone("Eastern Time (US & Canada)").strftime("[%Y-%m-%d %H:%M:%S] ") if include_timestamp
    formatted_msg = include_timestamp ? "#{timestamp}#{msg}" : msg

    directory = File.dirname(file)
    return unless File.directory?(directory)

    File.open(file, "a") do |f|
      f.puts(formatted_msg)
    end
    return unless screen_echo

    puts formatted_msg
    # end of if screenEcho
  end # end of log method

  def self.log_type(file, msg, screen_echo, type, include_timestamp = false)
    timestamp = Time.now.in_time_zone("Eastern Time (US & Canada)").strftime("[%Y-%m-%d %H:%M:%S] ") if include_timestamp
    formatted_msg = include_timestamp ? "#{timestamp}#{msg}" : msg

    File.open(file, "a") do |f|
      f.puts(formatted_msg)
    end

    return unless screen_echo

    case type
    when ERROR
      puts "#{RED}  #{formatted_msg}#{NORMAL}"
    when WARNING
      puts "#{YELLOW}  #{formatted_msg}#{NORMAL}"
    when INFO
      puts "#{GREEN}  #{formatted_msg}#{NORMAL}"
    else
      puts "  #{formatted_msg}"
    end
  end # end of log_type method

  ################################################################################################
  # Creates output folders if they don't already exist.
  def self.create_output_folders(output_folder)
    return if File.directory?(output_folder)

    Dir.mkdir(output_folder)
  end # end of create_output_folders

  #######################################################
  # Create CSV files for output
  def self.create_output_csv_file(file_name, header)
    File.open(file_name, "w") do |file|
      file.puts(header)
    end
    puts "Created #{file_name}"
  end # end of create_output_files

  #####################################################################
  def self.report_rate_limit(extra_msg, force_print)
    $numberOfCalls += 1
    rateLimit = $client.rate_limit!
    return unless $numberOfCalls % 25.zero? || force_print

    puts "::: API Rate Limit: #{extra_msg}: #{rateLimit.remaining} of #{rateLimit.limit} requests. Resets at: #{rateLimit.resets_at}"
  end # end of reportRateLimit

  #######################################################
  # creates an Octokit client using a github token that is store in an environment variable

  def self._generate_app_token
    private_pem = ENV["SIPHON_APP_PRIVATE_KEY"]
    private_key = OpenSSL::PKey::RSA.new(private_pem)

    payload = {
      iss: ENV["SIPHON_APP_ID"],
      iat: Time.now.to_i,
      exp: Time.now.to_i + (60 * 10) # Expire in 10 minutes
    }

    jwt = JWT.encode(payload, private_key, "RS256")

    uri = URI("https://api.github.com")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true
    http.verify_mode = OpenSSL::SSL::VERIFY_NONE

    request = Net::HTTP::Get.new("https://api.github.com/orgs/#{ENV["GITHUB_ORG"]}/installation")
    request["Authorization"] = "Bearer #{jwt}"
    response = http.request(request)

    installation_id = JSON.parse(response.body)["id"]
    puts "Installation ID: #{installation_id}"

    request = Net::HTTP::Post.new("https://api.github.com/app/installations/#{installation_id}/access_tokens")
    request["Authorization"] = "Bearer #{jwt}"
    request["Accept"] = "application/vnd.github.v3+json"
    response = http.request(request)
    access_token = JSON.parse(response.body)["token"]

    access_token #Return the access token
  end

  def self.setup_octokit_client(github_token = nil)
    if github_token.nil? || github_token.empty?
      puts "GitHub token is missing. Generating one from the GitHub App." # QQQ-RAS testing
      github_token = _generate_app_token
    end

    client = Octokit::Client.new(access_token: github_token)
    client.auto_paginate = true
    # client.api_endpoint = ghes_api_url unless ghes_api_url.nil?
    client.connection_options[:ssl] = { verify: false } # unless ghes_api_url.nil?
    client
  end # end of setupOctokitClient

  #######################################################
  # asserts that GH Issue Labels exist - if it doesn't exist, it'll
  #   create it
  def self.assert_gh_issue_labels(client, labels)
    repo_full_name = "#{ENV['GITHUB_ORG']}/#{ENV['GITHUB_REPO']}"
    labels.each do |label|
      client.label(repo_full_name.to_s, label.to_s)
    rescue Octokit::NotFound
      client.add_label(repo_full_name.to_s, label.to_s, "000000")
    end
  end

  #######################################################
  # Parse the issue body to extract key info...
  def self.parse_issue_body(issue_body, command)
    # puts "\n In helpers.rb::parse_issue_body. Issue Body:\n #{issue_body} \n --------"

    migration_details = {
      gh_org: nil,
      gh_repo: nil,
      bb_project: nil,
      bb_repo: nil,
      visibility: nil,
      bb_url: nil
    }

    # Parse the issue body to extract key info...
    # Example relevant parts of issue body:
    #
    # bitbucket-source-project-key: IN
    # bitbucket-source-repo-slug: rust-starter
    # github-target-org: mdo-test-org
    # github-target-repo-name: IN_rust-starter
    # visibility: private
    # repo-url:http://localhost:7990/projects/IN/repos/rust-starter/browse
    mapping = {
      /bitbucket-source-project-key:/ => :bb_project,
      /bitbucket-source-repo-slug:/   => :bb_repo,
      /github-target-org:/            => :gh_org,
      /github-target-repo-name:/      => :gh_repo,
      /visibility:/                   => :visibility,
      /repo-url:/                     => :bb_url
    }

    issue_body.split("\n").map(&:strip).reject(&:empty?).each do |line|
      mapping.each do |pattern, key|
        if (match = line.match(/#{pattern.source}\s*(.+)$/))
          migration_details[key] = match[1].strip
        end
      end
    end

    migration_details.each do |key, value|
      if value.nil?
        puts "Error: Issue Body is missing '#{key}'"
        abort
      end
    end

    puts "\nParsed Issue Body:"
    puts "  Bitbucket Source Project Key: #{migration_details[:bb_project]}"
    puts "  Bitbucket Source Repo Slug: #{migration_details[:bb_repo]}"
    puts "  Bitbucket URL: #{migration_details[:bb_url]}\n"
    puts "  GitHub Target Org: #{migration_details[:gh_org]}"
    puts "  GitHub Target Repo Name: #{migration_details[:gh_repo]}"
    puts "  Visibility: #{migration_details[:visibility]}\n"

    if command && command.include?("/dryrun") # change name of repo, and hardcode GH org
      migration_details[:gh_org] = ENV["SANDBOX_ORG"]

      if ENV["MIGRATED_REPO_NAME"]
        migration_details[:gh_repo] = ENV["MIGRATED_REPO_NAME"]
      else
        timestamp = Time.now.strftime("%H%M")
        migration_details[:gh_repo] = "#{migration_details[:gh_repo]}_dryrun_#{timestamp}".gsub(" ", "-")
      end
    end

    migration_details
  end
end # end of module Helpers
