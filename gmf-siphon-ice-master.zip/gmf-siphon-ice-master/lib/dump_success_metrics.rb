# frozen_string_literal: true
#
# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2025-07-01
# Author: Rich Schwarz


require "json"
require "csv"
require "net/http"
require "uri"
require "optparse"
require "time"
require "active_support/time" # Ensure ActiveSupport is available for time zone conversion

GITHUB_TOKEN = ENV["GH_PAT"]

# Set this variable to limit the number of issue pages to fetch (nil for no limit)
MAX_ISSUE_PAGES = 5

LABEL_REPO_DOESNT_EXIST = "status-repo-doesnt-exist"

def parse_args
  options = {}
  parser = OptionParser.new do |opts|
    opts.banner = "Usage: get_issues_with_status_labels.rb [options]"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end

    opts.on("-r", "--repo REPO", "GitHub repository") do |repo|
      options[:repo] = repo
    end

    opts.on("-h", "--help", "Show this help message") do
      puts opts
      exit
    end
  end

  parser.parse!

  # Use environment variables as defaults if options are not provided
  options[:org] ||= ENV["GITHUB_ORG"]
  options[:repo] ||= ENV["GITHUB_REPO"]

  if options[:org].nil? || options[:repo].nil?
    puts "Error: Both --org and --repo options are required."
    puts parser.help
    exit(1)
  end

  options
end

def fetch_issues_with_status_labels(org, repo)
  query = <<-GRAPHQL
    query($cursor: String) {
      repository(owner: "#{org}", name: "#{repo}") {
        issues(first: 100, after: $cursor) {
          edges {
            node {
              url
              body
              state
              updatedAt
              issueType {
                name
              }
              labels(first: 50) {
                nodes {
                  name
                }
              }
              timelineItems(first: 100, itemTypes: [LABELED_EVENT]) {
                nodes {
                  __typename
                  ... on LabeledEvent {
                    createdAt
                    label { name }
                  }
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
          }
        }
      }
    }
  GRAPHQL

  issues = []
  cursor = nil
  page_count = 0

  loop do
    break if MAX_ISSUE_PAGES && page_count >= MAX_ISSUE_PAGES

    # puts "[DEBUG] Fetching issues with cursor: #{cursor.inspect}"
    response = execute_graphql_query(query, { cursor: cursor })
    if response.code.to_i != 200
      puts "[ERROR] GraphQL query failed with status: #{response.code}"
      puts "[ERROR] Response body: #{response.body}"
      exit(1)
    end

    data = JSON.parse(response.body)
    if data["errors"]
      puts "[ERROR] GraphQL query returned errors: #{data["errors"]}"
      exit(1)
    end

    repository_data = data.dig("data", "repository")
    if repository_data.nil?
      puts "[ERROR] No repository data found in response. Check if the org/repo is correct."
      puts "[DEBUG] Response body: #{data.inspect}"
      exit(1)
    end

    issues_data = repository_data["issues"]
    if issues_data.nil? || issues_data["edges"].empty?
      puts "[DEBUG] No issues found for the repository."
      break
    end

    # Only include issues without an issue type
    issues.concat(
      issues_data["edges"].map { |edge| edge["node"] }.select do |issue|
        if issue.dig("issueType", "name").nil?
          true
        else
          puts "Skipping #{issue['url']}: '#{issue.dig('issueType', 'name')}'"
          false
        end
      end
    )
    page_info = issues_data["pageInfo"]
    puts "..#{issues.size} issues"

    page_count += 1
    break unless page_info["hasNextPage"]

    cursor = page_info["endCursor"]

    sleep 1

  end

  issues
end

def execute_graphql_query(query, variables = {})
  # puts "[DEBUG] Executing GraphQL query with variables: #{variables.inspect}"
  uri = URI("https://api.github.com/graphql")
  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{GITHUB_TOKEN}"
  request["Content-Type"] = "application/json"
  request.body = { query: query, variables: variables }.to_json

  response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
    http.request(request)
  end

  # puts "[DEBUG] Received response with status: #{response.code}"
  response
end # end of execute_graphql_query method


def extract_metadata_from_body(body)
  # puts "[DEBUG] Extracting metadata from issue body."
  metadata = {}

  body.lines.each do |line|
    if line.start_with?("bitbucket-source-project-key:")
      metadata[:bbs_project_key] = line.split(":").last.strip
    elsif line.start_with?("bitbucket-source-repo-slug:")
      metadata[:bbs_repo_slug] = line.split(":").last.strip
    end
  end

  # puts "[DEBUG] Extracted metadata: #{metadata.inspect}"
  metadata
end # end of extract_metadata_from_body method

def write_issues_to_csv(issues, file_path)
  puts "[DEBUG] Writing issues to CSV file: #{file_path}"

  # Sort issues by BB Project and BB Repo
  sorted_issues = issues.sort_by do |issue|
    metadata = extract_metadata_from_body(issue["body"])
    [metadata[:bbs_project_key].to_s, metadata[:bbs_repo_slug].to_s]
  end

  CSV.open(file_path, "w") do |csv|
    csv << [
      "ID", "BB Project", "BB Repo",
      "Dryrun Time",
      "Status:Migration", "Size", "Record Count", "Blob Size", "Age",
      "Webhooks", "Cross-Reference", "IaC",
      "Last Dryrun", "Last Migration",
      "Status:Archive",
      "Last Archived",
      "Status:Cutover",
      "Last Cutover",
      "Has Jenkinsfile",
      "Status:Webhook",
      "Status:CICDVal-Passed",     # new column
      "Last CICDVal-Passed",       # new column
      "Status-Team Added",          # new column
      "Status-Repo Added",           # new column
      "Status-CICDVal-Validation-Required" # new column
    ]


    def label_last_added_date(issue, label_prefix)
      # If timelineItems is missing, this will always return []
      return [] unless issue["timelineItems"] && issue["timelineItems"]["nodes"]
      events = issue["timelineItems"]["nodes"].select do |event|
        event["__typename"] == "LabeledEvent" && event["label"] && event["label"]["name"].start_with?(label_prefix)
      end
      events.map { |event| event["createdAt"] }
    end # end of label_last_added_date method

    # Helper to get the last date a label with exact name was added
    def label_last_added_date_exact(issue, label_name)
      return "" unless issue["timelineItems"] && issue["timelineItems"]["nodes"]
      events = issue["timelineItems"]["nodes"].select do |event|
        event["__typename"] == "LabeledEvent" && event["label"] && event["label"]["name"] == label_name
      end
      events.max_by { |event| event["createdAt"] }&.dig("createdAt") || ""
    end # end of label_last_added_date_exact method

    # Helper to get the first date a label with a prefix was added
    def label_first_added_date(issue, label_prefix)
      return "" unless issue["timelineItems"] && issue["timelineItems"]["nodes"]
      events = issue["timelineItems"]["nodes"].select do |event|
        event["__typename"] == "LabeledEvent" && event["label"] && event["label"]["name"].start_with?(label_prefix)
      end
      events.min_by { |event| event["createdAt"] }&.dig("createdAt") || ""
    end # end of label_first_added_date method

    sorted_issues.each do |issue|
      labels = issue["labels"]["nodes"].map { |label| label["name"] }

      # Extract metadata for this issue
      metadata = extract_metadata_from_body(issue["body"])

      # Defensive: handle missing keys to avoid nil + string error
      bb_project = metadata[:bbs_project_key] || ""
      bb_repo = metadata[:bbs_repo_slug] || ""
      bb_id = (bb_project.empty? && bb_repo.empty?) ? "" : "#{bb_project}.#{bb_repo}"

      # Extract Jenkinsfile status
      jenkinsfile_status = labels.find { |label| label.start_with?("status-jenkinsfile-") }&.sub("status-jenkinsfile-", "")

      status_cutover = labels.find { |label| label.start_with?("status-cutover") }&.sub("status-cutover-", "")
      status_dryrun = labels.find { |label| label.start_with?("status-dryrun") }&.sub("status-dryrun-", "")
      status_migration = labels.find { |label| label.start_with?("status-migration") }&.sub("status-migration-", "")
      status_archive = labels.find { |label| label.start_with?("status-archive") }&.sub("status-archive-", "")
      dryrun_time = labels.find { |label| label.start_with?("dryrun-time") }&.match(/\d+/)&.to_s
      status_webhook = labels.find { |label| label.start_with?("status-webhook") }&.sub("status-webhook-", "")
      size_label = labels.find { |label| label.start_with?("size-") }
      recordcount_label = labels.find { |label| label.start_with?("recordcount-") }
      blob_size_label = labels.find { |label| label.start_with?("blob-size-") }
      age_label = labels.find { |label| label.start_with?("age-") }
      label_webhooks = labels.find { |l| l.downcase == "webhooks" } || ""
      label_crossref = labels.find { |l| l.downcase == "cross-reference" } || ""
      label_iac = labels.select { |l| l.downcase.start_with?("iac-") }.join(": ")
      dryrun_label_last_added    = label_last_added_date(issue, "status-dryrun")
      migration_label_last_added = label_last_added_date(issue, "status-migration")
      archive_label_last_added   = label_last_added_date(issue, "status-archive")
      cutover_label_last_added   = label_last_added_date(issue, "status-cutover")

      # Extract error-* labels for the new column (should be label names, not joined string)
      error_labels_arr = labels.select { |label| label.start_with?("error-") }
      error_labels = error_labels_arr.join(": ")

      status_do_not_migrate = labels.include?("status-do-not-migrate") ? "status-do-not-migrate" : ""



      status_cicdval_passed = labels.find { |label| label.start_with?("status-cicdval-passed") }&.sub("status-cicdval-passed-", "")
      last_cicdval_passed_true = safe_format_date(
        label_last_added_date_exact(issue, "status-cicdval-passed-true")
      )

      # Get first time status-team and status-repo were added
      first_team_added = safe_format_date(
        label_first_added_date(issue, "status-team")
      )
      first_repo_added = safe_format_date(
        label_first_added_date(issue, "status-repo")
      )

      # Add extraction for status-cicdval-validation-required
      status_cicdval_validation_required = labels.include?("status-cicdval-validation-required") ? "status-cicdval-validation-required" : ""

      # Get all dryrun, migration, archive, and cutover label dates (arrays)
      dryrun_label_dates    = label_last_added_date(issue, "status-dryrun")
      migration_label_dates = label_last_added_date(issue, "status-migration")
      archive_label_dates   = label_last_added_date(issue, "status-archive")
      cutover_label_dates   = label_last_added_date(issue, "status-cutover")

      # For each combination of label date arrays, output a row per date (cartesian product)
      # If any of these arrays is empty, use [""] so zip works as expected
      dryrun_label_dates    = dryrun_label_dates.empty?    ? [""] : dryrun_label_dates
      migration_label_dates = migration_label_dates.empty? ? [""] : migration_label_dates
      archive_label_dates   = archive_label_dates.empty?   ? [""] : archive_label_dates
      cutover_label_dates   = cutover_label_dates.empty?   ? [""] : cutover_label_dates

      # Find the max length among the arrays
      max_rows = [dryrun_label_dates.size, migration_label_dates.size, archive_label_dates.size, cutover_label_dates.size].max

      (0...max_rows).each do |i|
        csv << [
          bb_id,
          bb_project,
          bb_repo,
          dryrun_time || "",
          status_migration || "",
          size_label || "",
          recordcount_label || "",
          blob_size_label || "",
          age_label || "",
          label_webhooks,
          label_crossref,
          label_iac,
          safe_format_date(dryrun_label_dates[i % dryrun_label_dates.size]),
          safe_format_date(migration_label_dates[i % migration_label_dates.size]),
          status_archive || "",
          safe_format_date(archive_label_dates[i % archive_label_dates.size]),
          status_cutover || "",
          safe_format_date(cutover_label_dates[i % cutover_label_dates.size]),
          jenkinsfile_status || "",
          status_webhook || "",
          status_cicdval_passed,
          last_cicdval_passed_true,
          first_team_added,
          first_repo_added,
          status_cicdval_validation_required
        ]
      end # end of per-label-date row block
    end # end of sorted_issues.each
  end   # end of CSV.open
  puts "[DEBUG] Issues successfully written to CSV."
end # end of write_issues_to_csv method


# Helper to safely format date or return empty string (date only, no time)
def safe_format_date(date_str)
  if date_str.is_a?(Array)
    return date_str.map { |d| safe_format_date(d) }.join(": ")
  end
  return "" if date_str.nil? || date_str.empty?
  Time.parse(date_str).in_time_zone("Eastern Time (US & Canada)").strftime("%Y-%m-%d")
rescue => e
  puts "[ERROR] Failed to parse date string: #{date_str.inspect} - #{e.class}: #{e.message}"
  ""
end # end of safe_format_date method


def main
  options = parse_args
  org = options[:org]
  repo = options[:repo]

  puts "[DEBUG] Starting script with org: #{org}, repo: #{repo}"
  issues = fetch_issues_with_status_labels(org, repo)
  if issues.empty?
    puts "[DEBUG] No issues found with status labels."
  else
    puts "[DEBUG] Total issues fetched: #{issues.size}"
  end

  output_path = File.join(File.dirname(__FILE__), "../output/metrics.csv")
  write_issues_to_csv(issues, output_path)
  puts "Issues written to #{output_path}"
end

main
main
