#   A basic Excel Helper Class
#   This class provides methods to read data from Excel files using the Roo gem.
#   It supports reading columns by letter or by header names, and allows switching between sheets.
#
#   Usage:
#     excel_helper = ExcelHelper.new("path/to/excel_file.xlsx")
#     data = excel_helper.read_columns_by_letter(["A", "B", "C"], start_row: 2)
#     data = excel_helper.read_columns_by_header(["Header1", "Header2"], header_row: 1, data_starts_at: 2)
#     excel_helper.switch_tab("Sheet2")
#     current_tab = excel_helper.current_tab_name

require "roo"


class ExcelHelper

  def initialize(file_path)
    raise ArgumentError, "File does not exist: #{file_path}" unless File.exist?(file_path)

    @file_path = file_path
    @workbook = Roo::Spreadsheet.open(file_path)
    @default_sheet = @workbook.sheets.first
    @workbook.default_sheet = @default_sheet
  end

  def switch_tab(tab_name)
    raise "Sheet '#{tab_name}' not found" unless @workbook.sheets.include?(tab_name)

    @default_sheet = tab_name
    @workbook.default_sheet = @default_sheet
  end

  def current_tab_name
    @default_sheet
  end

  def col_letter_to_index(letter)
    letter.upcase.chars.reduce(0) { |sum, char| sum * 26 + (char.ord - "A".ord + 1) } - 1
  end

  def read_columns_by_letter(col_letters, start_row: 1)
    data = []
    (start_row..@workbook.last_row).each do |row_idx|
      row_hash = {}
      col_letters.each do |letter|
        col_index = col_letter_to_index(letter) + 1
        row_hash[letter] = @workbook.cell(row_idx, col_index)
      end

      data << row_hash
    end

    data
  end

  def read_columns_by_header(header_names, header_row:, data_starts_at:)
    header_map = {}

    (1..@workbook.last_column).each do |col|
      header_value = @workbook.cell(header_row, col).to_s.strip
      header_map[header_value] = col if header_names.include?(header_value)
    end

    missing = header_names - header_map.keys
    raise "Missing headers: #{missing.join(', ')}" unless missing.empty?

    data = []
    (data_starts_at..@workbook.last_row).each do |row_idx|
      row_hash = {}

      header_map.each do |name, col_idx|
        row_hash[name] = @workbook.cell(row_idx, col_idx)
      end

      data << row_hash
    end

    data
  end
end
