# frozen_string_literal: true

# file_utils_ext.rb
# Utility module for extended file operations, such as file size checks and validations.

module FileUtilsExt
  DEFAULT_MAX_FILE_SIZE_MB = 10 # Default file size limit in megabytes

  # Checks if a file exceeds the specified size limit
  # @param [String] file_path - Path to the file
  # @param [Integer] max_size_mb - Maximum file size in MB (default: 10)
  # @return [Boolean] - True if file size exceeds the limit, false otherwise
  def self.too_large?(file_path, max_size_mb = DEFAULT_MAX_FILE_SIZE_MB)
    begin
      # Validate that the file exists before checking size
      if !File.exist?(file_path)
        raise Errno::ENOENT, "File not found: #{file_path}"
      end

      # Check the file size
      file_size_mb = File.size(file_path).to_f / (1024 * 1024)
      file_size_mb > max_size_mb
    rescue Errno::EACCES
      puts "[ERROR] Permission denied: #{file_path}"
      true # Treat inaccessible files as "too large" to prevent further processing
    rescue StandardError => e
      puts "[ERROR] Failed to check file size: #{e.message}"
      true # Treat unknown errors as "too large"
    end
  end

  # Checks if a file is readable
  # @param [String] file_path - Path to the file
  # @return [Boolean] - True if the file exists and is readable, false otherwise
  def self.readable?(file_path)
    File.exist?(file_path) && File.readable?(file_path)
  end

  # Validates that the file exists and is a regular file
  # @param [String] file_path - Path to the file
  # @return [Boolean] - True if the file exists and is a regular file, false otherwise
  def self.valid_file?(file_path)
    File.exist?(file_path) && File.file?(file_path)
  end
end
