# Xebia Siphon Scripts

This document provides an overview of the scripts available in the `lib` and `client/frozen` directories. Each script's purpose and usage are described below.

---

## Table of Contents

- [lib Scripts](#lib-scripts)
  - [label_do_not_migrate_repos.rb](#label_do_not_migrate_reposrb)
  - [Other Scripts](#other-scripts)
- [bb_bin Scripts](#bb_bin-scripts)
  - [find-new-bitbucket-repos.sh](#find-new-bitbucket-repossh)
- [misc-scripts](#misc-scripts)
  - [rm_repos_by_name.rb](#rm_repos_by_namerb)
- [client/frozen Scripts](#clientfrozen-scripts)
  - [Other Scripts](#other-scripts-1)

---

## lib Scripts

### label_do_not_migrate_repos.rb

**Purpose:**  
Scans open GitHub issues in a specified repository, extracts a project key from each issue's title, and compares it against a list of project keys to ignore (from a text file).  
If an issue's project key matches one in the ignore list and does not already have the `status-do-not-migrate` label, the script can apply this label to the issue using the GitHub GraphQL API.  
The script prompts for confirmation before labeling any issues.

**Usage:**

```sh
ruby label_do_not_migrate_repos.rb -o ORG -r REPO
```

- `-o`, `--org ORG`: GitHub organization (can also be set via the `GITHUB_ORG` environment variable)
- `-r`, `--repo REPO`: GitHub repository (can also be set via the `GITHUB_REPO` environment variable)

**Example:**

```sh
ruby label_do_not_migrate_repos.rb -o my-org -r my-repo
```

---

## bb_bin Scripts

### find-new-bitbucket-repos.sh

**Purpose:**  
Finds Bitbucket repositories that are not present in the migration Excel file.  
This script exports a list of all Bitbucket repositories (optionally ignoring some projects), then compares them to the repositories listed in the migration Excel file, and outputs a CSV file containing any new Bitbucket repositories not found in the Excel.

**Usage:**
#### note: you must have an updated copy of the tracker in the output folder for this to work
```sh
export BB_SERVER_URL="http://your-bitbucket-server"
export BB_ACCT_USER="your-username"
export BB_ACCT_PASSWORD="your-password"
./bb_bin/find-new-bitbucket-repos.sh
```

- The script will generate:
  - `output/trimmed_bbs_repo_file.csv`: All Bitbucket repos (trimmed)
  - `output/new_repos_not_in_excel.csv`: New Bitbucket repos not in Excel

You can override file locations by setting environment variables in the script.


---

## misc-scripts

### rm_repos_by_name.rb

**Purpose:**  
Removes repositories in a GitHub organization that match a given name pattern.

**Usage:**

```sh
ruby "c:\code\xsiphon\misc-scripts\rm_repos_by_name.rb" --org OWNER --repo-pattern "_dryrun_" --execute
```

- `--org`: GitHub organization name
- `--repo-pattern`: Pattern to match repository names
- `--execute`: Actually perform the deletion (omit for dry run)

---

## client/frozen Scripts

### Other Scripts

_To be documented..._
