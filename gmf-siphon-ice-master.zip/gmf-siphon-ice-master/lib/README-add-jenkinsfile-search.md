# Integrating Jenkinsfile Search into the Bitbucket-to-GitHub Analysis Process

This guide explains how to incorporate the Jenkinsfile search logic (as used in `label_issues_with_jenkinsfiles.rb` and its workflow) into the main Bitbucket-to-GitHub analysis process (`create_gh_issues_for_bbs_projects.rb`). This will allow Jenkinsfile presence to be detected and labeled as part of the initial migration analysis.

---

## 1. Understand the Jenkinsfile Search Logic

The Jenkinsfile search logic is implemented in `lib/label_issues_with_jenkinsfiles.rb` and works as follows:
- For each repo, it clones the Bitbucket repository (using credentials).
- It searches all branches for a file named `Jenkinsfile` at the root.
- It applies a label (`status-jenkinsfile-true` or `status-jenkinsfile-false`) to the corresponding GitHub issue.

---

## 2. Where to Integrate Jenkinsfile Search

**You should perform Jenkinsfile detection immediately after the repository is cloned as part of the analysis process.**  
In the current architecture, the repository is cloned in `bb_bin/analyze_repo.rb` inside the `get_metadata` method.  
The main repo analysis and issue creation happens in the `create_github_issue` method in `bb_bin/create_gh_issues_for_bbs_projects.rb`, but the repo is cloned and analyzed in `analyze_repo.rb`.  
**Therefore, the Jenkinsfile search should be performed in `get_metadata` in `analyze_repo.rb`, after the clone step and before any cleanup.**

---

## 3. How to Integrate the Jenkinsfile Search

- Copy or adapt the Jenkinsfile search logic (such as `find_jenkinsfile_using_git`) from `lib/label_issues_with_jenkinsfiles.rb`.
- Place this logic in `bb_bin/analyze_repo.rb`.
- After the repo is cloned in `get_metadata`, call the Jenkinsfile search logic, passing the path to the cloned repo.
- Add the resulting Jenkinsfile label (`status-jenkinsfile-true` or `status-jenkinsfile-false`) to the metadata hash returned by `get_metadata`.

---

## 4. How to Propagate the Jenkinsfile Label

- In `get_metadata` in `bb_bin/analyze_repo.rb`, after the Jenkinsfile search, add the label to the metadata hash (e.g., `metadata[:jenkinsfile] = { labels: [jenkinsfile_label], issue_body: "" }`).
- In `create_github_issue` in `bb_bin/create_gh_issues_for_bbs_projects.rb`, when collecting labels for the issue, include the Jenkinsfile label from the metadata:
  ```ruby
  if result[:metadata] && result[:metadata][:jenkinsfile] && result[:metadata][:jenkinsfile][:labels]
    labels.concat(result[:metadata][:jenkinsfile][:labels])
    labels.uniq!
  end
  ```
- This ensures the Jenkinsfile status is labeled on the created GitHub issue as part of the initial analysis.

---

## 5. Example Integration Flow

1. **Clone the repo in `get_metadata` (already done).**
2. **Immediately after cloning, search for Jenkinsfile in all branches.**
3. **Add the Jenkinsfile label to the metadata hash.**
4. **When creating the GitHub issue, include the Jenkinsfile label from the metadata.**

---

## 6. Additional Guidance

- Make sure the Jenkinsfile search happens only after the repo is cloned and before any cleanup or deletion of the repo directory.
- Do not duplicate the clone logic; use the already-cloned repo for the Jenkinsfile search.
- If both the workflow and the analysis process need Jenkinsfile search, consider moving the logic to a shared helper file (e.g., `lib/jenkinsfile_search_helper.rb`).

---

## 7. Test the Integration

- Run the analysis process for a small set of repos.
- Verify that the correct Jenkinsfile status labels are applied to the created GitHub issues.

---

**Summary:**  
By following these steps, Jenkinsfile detection will be part of your Bitbucket-to-GitHub migration analysis, and the results will be visible as labels on the created GitHub issues.

- Run the analysis process for a small set of repos.
- Verify that the correct Jenkinsfile status labels are applied to the created GitHub issues.

---

## 8. (Optional) Refactor for Reuse

- If both the workflow and the analysis process need Jenkinsfile search, consider moving the logic to a shared helper file (e.g., `lib/jenkinsfile_search_helper.rb`).

---

**Summary:**  
By following these steps, you will have Jenkinsfile detection as part of your Bitbucket-to-GitHub migration analysis, and the results will be visible as labels on the created GitHub issues.

