# Extension Manager

This directory contains the `extension_manager.rb` module, which provides a framework for loading and running extensions (plugins) defined in YAML files. Extensions are Ruby scripts that analyze repositories and return results in a standard format.

## How It Works

- **Extension YAML**: Extensions are defined in a YAML file (see below for format).
- **Ruby Entry Points**: Each Analysis extension must provide a Ruby method (entry point) that accepts a `repo` parameter and any additional keyword arguments.
  - Migration extensions receive a parameter called `migration_details`, which is a hash describing the migration context (see below).
- **Result Format**: Each extension returns a hash with `:labels` (array of strings) and `:issue_body` (markdown string).

## YAML Format

Example `extensions.yml`:

```yaml
libs:
  - name: file_searcher
    location: "../file_searcher/search_files"
    entry_point: start_scanner
    enabled: true
    args:
      - name: keyword_file
        value: "keywords.txt"
      - name: write_issue_body
        value: true
      - name: issue_header
        value: "Sensitive Keywords"
      - name: default_label
        value: "security"
```

- `name`: Name of the extension.
- `location`: Relative path to the Ruby file.
- `entry_point`: Method to call (defaults to `start_<name>` if omitted).
- `enabled`: Set to `false` to skip loading.
- `args`: List of keyword arguments to pass to the entry point.

## Usage

You can use the ExtensionManager in your scripts. Example from `analyze_repo.rb`:

```ruby
require_relative "lib/extension_manager"

repo = { slug: "my-repo", project: { key: "PROJ" } }
ExtensionManager.process_extensions("extensions.yml")

ExtensionManager.extensions.each do |ext|
  result = ExtensionManager.run_extension(ext, repo)
  puts result[:issue_body]
end
```

- Call `process_extensions(yaml_file)` to load extensions.
- Use `ExtensionManager.extensions` to get the loaded extension configs.
- Call `run_extension(ext, repo)` to execute an extension.

## Extension Requirements

- Entry point must accept at least one parameter: `repo`.
- Must return a hash: `{ labels: [...], issue_body: "..." }`.

## The `repo` Parameter

Each extension receives a `repo` parameter describing the repository being analyzed.

This parameter is populated from the Bitbucket Server API response for repositories:

```
GET /rest/api/1.0/projects/{project-key}/repos
```

The `repo` hash typically contains fields such as:

```ruby
{
  "slug" => "important-large-repo",
  "id" => 107816,
  "name" => "important-large-repo",
  "state" => "AVAILABLE",
  "project" => {
    "key" => "XEB",
    "id" => 17582,
    "name" => "Xebia",
    "public" => false,
    ... # other project fields
  },
  "public" => false,
  "links" => { ... },
  ... # other Bitbucket repo fields
}
```

See [`output/important-large-repo.json`](../output/important-large-repo.json) for a real example.

- `:slug` — Repository slug (short name, used in URLs and paths)
- `:name` — Human-readable repository name
- `:project[:key]` — Project key/group identifier
- Other fields as returned by the Bitbucket API

## The `migration_details` Parameter (for Migration Extensions)

Migration extensions receive a single parameter named `migration_details`, which is a hash containing migration-specific information. Example structure:

```ruby
{
  "bitbucket-source-project-key" => "OMEGA",
  "bitbucket-source-repo-slug"   => "omega-idc",
  "github-target-org"            => "OWNER",
  "github-target-repo-name"      => "OMEGA.omega-idc",
  "visibility"                   => "private",
  "repo-url"                     => "https://stash.OWNER.net/projects/OMEGA/repos/omega-idc/browse"
}
```

- `bitbucket-source-project-key`: Source Bitbucket project key.
- `bitbucket-source-repo-slug`: Source Bitbucket repository slug.
- `github-target-org`: Target GitHub organization.
- `github-target-repo-name`: Target GitHub repository name.
- `visibility`: Repository visibility (`private` or `public`).
- `repo-url`: URL to the source repository.

## Notes

- Labels from all extensions are merged and deduplicated.
- Issue bodies are appended in order of execution.
- See comments in `extension_manager.rb` for more details.

## See Also

- [file_searcher/README.md](../file_searcher/README.md) for an example extension.
