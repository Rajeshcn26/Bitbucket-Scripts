# frozen_string_literal: true

require "fileutils"
require "thread"

class LogManager
  # Color codes for console output
  RED = "\e[31m"
  GREEN = "\e[32m"
  YELLOW = "\e[33m"
  BLUE = "\e[34m"
  GREY = "\e[37m"
  NORMAL = "\e[0m"

  # Initializes the LogManager with a log file, optional settings for log rotation, and quiet mode
  #
  # @param [String] log_file - Path to the log file (defaults to './log/application.log')
  # @param [String] timestamp_format - Format for timestamps (default: '%Y-%m-%d %H:%M:%S')
  # @param [Boolean] quiet - Suppress console output if true
  # @param [Integer] max_log_size_mb - Maximum log file size in MB before rotating (optional)
  def initialize(log_file = nil, timestamp_format: "%Y-%m-%d %H:%M:%S", quiet: false, max_log_size_mb: nil)
    @log_file = log_file && !log_file.strip.empty? ? log_file : "log/application.log"
    @timestamp_format = timestamp_format
    @quiet = quiet
    @max_log_size = max_log_size_mb ? max_log_size_mb * 1024 * 1024 : nil
    @mutex = Mutex.new # Ensures thread-safe logging

    ensure_log_directory
    FileUtils.touch(@log_file) # Ensure the log file exists
  end

  # Logs a message with the specified log level and color-codes the output
  # @param [String] message - The message to log
  # @param [String] level - The log level (e.g., DEFAULT, INFO, WARN, ERROR, DEBUG)
  # @param [Boolean] grouped - Whether to group the log message (optional GITHUB ONLY)
  def log(message, level: "DEFAULT", group_header: "")
    original_level = level
    level = "INFO" if level.downcase == "default"

    timestamped_message = format_message(message, level)
    colorized_message = colorize_message(timestamped_message, level, original_level)

    @mutex.synchronize do
      # Write to the log file
      check_log_rotation if @max_log_size
      File.open(@log_file, "a") { |file| file.puts(timestamped_message) }

      # Output to console unless quiet mode is enabled
      unless @quiet
        if group_header && !group_header.empty?
          puts "::group::#{group_header}"
          puts "#{colorized_message}"
          puts "::endgroup::"
        else
          puts colorized_message
        end
      end
    end
  end

  private

  # Ensures the directory for the log file exists
  def ensure_log_directory
    dir = File.dirname(@log_file)
    FileUtils.mkdir_p(dir) unless Dir.exist?(dir)
  end

  # Formats the message with timestamp and log level
  # @param [String] message - The log message
  # @param [String] level - Log level to include
  # @param [Boolean] grouped - Whether to group the log message (optional GITHUB ONLY)
  # @return [String] - Formatted log message
  def format_message(message, level)
    level = "INFO" if level.downcase == "default"
    timestamp = Time.now.strftime(@timestamp_format)

    return "[#{timestamp}] [#{level}] #{message}"
  end

  # Applies color coding to the message based on the log level
  # @param [String] message - The formatted log message
  # @param [String] level - Log level to determine color
  # @return [String] - Colorized log message
  def colorize_message(message, level, original_level)
    case level.upcase
    when "ERROR"
      RED + message + NORMAL
    when "WARN", "WARNING"
      YELLOW + message + NORMAL
    when "INFO"
      if original_level.downcase == "default"
        GREY + message + NORMAL
      else
        GREEN + message + NORMAL
      end
    when "DEFAULT"
      GREY + message + NORMAL
    when "DEBUG"
      BLUE + message + NORMAL
    else
      message # No color for unrecognized levels
    end
  end

  # Checks the log file size and rotates if it exceeds the maximum size
  def check_log_rotation
    return unless File.exist?(@log_file) && File.size(@log_file) > @max_log_size

    rotated_file = "#{@log_file}.#{Time.now.strftime('%Y%m%d%H%M%S')}.bak"
    FileUtils.mv(@log_file, rotated_file)
    FileUtils.touch(@log_file) # Create a new log file

    puts "[LOG ROTATION] Rotated log file to: #{rotated_file}" unless @quiet
  end
end
