# frozen_string_literal: true
#
# Script to find duplicate issues and move one to obsolete (closed).
# Duplicates are detected by identical titles.
# If one has a "success" status (label contains "success", "dry run", or "migration"), keep that one.
# Otherwise, keep the newer one.
#
require "octokit"
require "optparse"
require "net/http"
require "json"
require_relative "../lib/helpers"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end # end of client of the block

def fetch_open_issues(repo, max_pages: nil)
  issues = []
  page = 1
  per_page = 100
  owner, repo_name = repo.split("/")
  cursor = nil # initialize cursor before loop

  loop do
    # GraphQL query to fetch open issues with pagination, ordered by CREATED_AT descending (newest first)
    query = <<~GRAPHQL
      query($owner: String!, $name: String!, $perPage: Int!, $cursor: String) {
        repository(owner: $owner, name: $name) {
          issues(first: $perPage, after: $cursor, states: OPEN, orderBy: {field: CREATED_AT, direction: DESC}) {
            pageInfo {
              endCursor
              hasNextPage
            }
            nodes {
              number
              title
              createdAt
              node_id: id
              issueType {
                name
              }
              labels(first: 20) {
                nodes {
                  name
                }
              }
            }
          }
        }
      }
    GRAPHQL

    variables = {
      owner: owner,
      name: repo_name,
      perPage: per_page,
      cursor: (page == 1 ? nil : cursor)
    }

    uri = URI("https://api.github.com/graphql")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(uri)
    request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
    request["Content-Type"] = "application/json"
    request.body = { query: query, variables: variables }.to_json

    response = http.request(request)
    result = JSON.parse(response.body)

    if result["errors"]
      raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
    end

    data = result.dig("data", "repository", "issues")
    batch = data["nodes"].map do |node|
      {
        number: node["number"],
        title: node["title"],
        created_at: node["createdAt"],
        node_id: node["node_id"],
        issue_type: node["issueType"] ? node["issueType"]["name"] : nil,
        labels: node["labels"]["nodes"].map { |l| { name: l["name"] } }
      }
    end

    puts "page #{page}"
    break if batch.empty?
    issues.concat(batch)
    break unless data["pageInfo"]["hasNextPage"]
    cursor = data["pageInfo"]["endCursor"]
    page += 1
    break if max_pages && page > max_pages
  end
  # Filter out issues with titles like "Migrate Failure"
  issues.reject! { |issue| issue[:title].strip.downcase.include?("migrate failure") }
  # Filter out issues that are of type 'task'
  issues.reject! { |issue| issue[:issue_type].to_s.strip.downcase == "task" }
  issues
end # end of fetch_open_issues of the method


def group_issues_by_title(issues)
  issues.group_by { |issue| issue[:title].strip.downcase }
end # end of group_issues_by_title of the block

def has_success_label?(issue)
  labels = issue[:labels].map { |l| l[:name].downcase }
  labels.any? { |l| l.include?("success") || l.include?("dryrun") || l.include?("migration") }
end # end of has_success_label? of the block

def fetch_issue_type_id(repo, issue_type_name)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  owner, repo_name = repo.split("/")

  query = <<~GRAPHQL
    query {
      repository(owner: "#{owner}", name: "#{repo_name}") {
        issueTypes(first: 10) {
          nodes {
            id
            name
          }
        }
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end

  issue_type = result.dig("data", "repository", "issueTypes", "nodes").find { |node| node["name"].downcase == issue_type_name.downcase }
  raise "Issue type '#{issue_type_name}' not found." unless issue_type

  issue_type["id"]
end # end of fetch_issue_type_id of the block

def update_issue_type_to_obsolete(issue_node_id, obsolete_issue_type_id)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  query = <<~GRAPHQL
    mutation {
      updateIssue(input: {id: "#{issue_node_id}", issueTypeId: "#{obsolete_issue_type_id}", state: CLOSED}) {
        issue {
          id
        }
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end
end # end of update_issue_type_to_obsolete of the block

def main
  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: ruby find_and_obsolete_duplicate_issues.rb -o ORG -r REPO [--execute]"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end

    opts.on("-r", "--repo REPO", "GitHub repository (e.g., 'owner/repo')") do |repo|
      options[:repo] = repo
    end

    opts.on("--execute", "Actually obsolete the duplicate issues (otherwise, just print what would be done)") do
      options[:execute] = true
    end

    opts.on("--max-pages N", Integer, "Limit the number of pages of issues to retrieve") do |n|
      options[:max_pages] = n
    end
  end.parse!

  options[:org] ||= ENV["GITHUB_ORG"]
  options[:repo] ||= ENV["GITHUB_REPO"]

  missing_args = []
  missing_args << "organization (--org or GITHUB_ORG)" if options[:org].nil?
  missing_args << "repository (--repo or GITHUB_REPO)" if options[:repo].nil?

  unless missing_args.empty?
    puts "#{Helper::RED}\n  Error: Missing required argument(s): #{missing_args.join(', ')}#{Helper::NORMAL}"
    puts "#{Helper::RED}  Usage: ruby find_and_obsolete_duplicate_issues.rb -o ORG -r REPO [--execute]#{Helper::NORMAL}"
    exit
  end

  repo = "#{options[:org]}/#{options[:repo]}"
  puts "Finding duplicate issues in #{repo}..."
  issues = fetch_open_issues(repo, max_pages: options[:max_pages])
  # Filter out issues that are subtasks (i.e., have a parent)
  issues = issues.reject { |issue| issue[:parent_id] } # Only keep issues without a parent
  puts "Found #{issues.size} open issues in #{repo}"
  grouped = group_issues_by_title(issues)
  obsolete_issue_type_id = fetch_issue_type_id(repo, "obsolete")

  total_groups = grouped.count { |_, issues_with_title| issues_with_title.size > 1 }
  group_index = 0

  grouped.each do |title, issues_with_title|
    next unless issues_with_title.size > 1
    group_index += 1
    puts "[#{group_index}/#{total_groups}] Found #{issues_with_title.size} issues with title: '#{title}'"

    # Find which to keep
    keep = nil
    if issues_with_title.any? { |i| has_success_label?(i) }
      keep = issues_with_title.find { |i| has_success_label?(i) }
    else
      # Keep the newest (by created_at)
      keep = issues_with_title.max_by { |i| i[:created_at] }
    end # end of if of the block

    puts "  keep:     #{keep[:number]} #{keep[:title]} | Labels: #{keep[:labels].map { |l| l[:name] }.join(', ')}"

    to_obsolete = issues_with_title.reject { |i| i[:number] == keep[:number] }
    to_obsolete.each do |issue|
      if options[:execute]
        begin
          puts "Obsoleting duplicate issue ##{issue[:number]}: '#{issue[:title]}'"
          update_issue_type_to_obsolete(issue[:node_id], obsolete_issue_type_id)
          puts "  Issue  #{issue[:number]} moved to obsolete and closed."
        rescue StandardError => e
          puts "Error updating issue ##{issue[:number]}: #{e.message}"
        end
      else
        label_names = issue[:labels].map { |l| l[:name] }
        puts "  obsolete: #{issue[:number]} #{issue[:title]} | Labels: #{label_names.join(', ')}"
      end # end of if of the block
    end   # end of to_obsolete.each of the block
  end     # end of grouped.each of the block
end       # end of main of the block

main
# end of file
