# frozen_string_literal: true
#
# copyright © Xebia. All rights reserved. No unauthorized duplication, distribution or copying.
# Date: 2025-05-08
# Author: Rich Schwarz
#
# This software is provided "as is," without warranty of any kind, express or implied, including but not limited to
# the warranties of merchantability, fitness for a particular purpose, and noninfringement. In no event shall the
# authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract,
# tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.
# Use of this software is at your own risk, and no indemnification is provided for any damages or losses incurred.
#
# Summary:
# This script deletes GitHub issues of type "obsolete" with issue numbers greater than 500.
# It uses the GitHub GraphQL API to fetch and delete issues.
#
# Usage:
# ruby cleanup_obsolete_issues.rb -o ORG -r REPO
#
# Options:
# -o, --org ORG       GitHub organization (can also be set via the GITHUB_ORG environment variable).
# -r, --repo REPO     GitHub repository (can also be set via the GITHUB_REPO environment variable).
#
# Note:
# Ensure that the GH_TOKEN environment variable is set with a valid GitHub token for authentication.
#
require "octokit"
require "optparse"
require "net/http"
require "json"
require_relative "../lib/helpers"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def fetch_obsolete_issues(repo, ignore_below)
  puts "Fetching issues of type 'obsolete' from repository '#{repo}'..."
  obsolete_issue_type_id = fetch_issue_type_id(repo, "obsolete")
  puts "Obsolete issue type ID: #{obsolete_issue_type_id}"

  owner, repo_name = repo.split("/")
  all_issues = []
  after_cursor = nil

  loop do
    query = <<~GRAPHQL
      query {
        repository(owner: "#{owner}", name: "#{repo_name}") {
          issues(first: 100, states: CLOSED, after: #{after_cursor.to_json}) {
            nodes {
              number
              id: id # Alias id as node_id for clarity
              title
              url
            }
            pageInfo {
              hasNextPage
              endCursor
            }
          }
        }
      }
    GRAPHQL

    uri = URI("https://api.github.com/graphql")
    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = true

    request = Net::HTTP::Post.new(uri)
    request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
    request["Content-Type"] = "application/json"
    request.body = { query: query }.to_json

    response = http.request(request)
    result = JSON.parse(response.body)

    if result["errors"]
      raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
    end

    issues = result.dig("data", "repository", "issues", "nodes") || []
    all_issues.concat(issues)

    page_info = result.dig("data", "repository", "issues", "pageInfo")
    break unless page_info["hasNextPage"]

    after_cursor = page_info["endCursor"]
  end # end of loop block

  # Output the total number of issues fetched
  puts "Total issues fetched: #{all_issues.size}"

  filtered_issues = all_issues.select do |issue|
    issue["number"] > ignore_below && issue["id"] && issue["number"] > 500 # Ensure IDs under 500 are ignored
  end # end of filtered_issues block

  if filtered_issues.empty?
    puts "No obsolete issues found above issue number #{ignore_below}"
    exit
  end

  filtered_issues.each do |issue|
    puts "Issue URL: #{issue['url']}" # Output the URL instead of the number
  end

  filtered_issues
end # end of fetch_obsolete_issues method

def delete_issues(repo, issues)
  issues.each do |issue|
    begin
      puts "Deleting issue #{issue['url']}..." # Output the URL for clarity
      delete_issue_via_graphql(issue["id"]) # Pass the correct node_id
      puts "  Issue #{issue['url']} deleted successfully."
    rescue StandardError => e
      puts "Error deleting issue #{issue['url']}: #{e.message}"
    end
  end
end # end of delete_issues method

def delete_issue_via_graphql(issue_node_id)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  query = <<~GRAPHQL
    mutation {
      deleteIssue(input: {issueId: "#{issue_node_id}"}) {
        clientMutationId
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end
end # end of delete_issue_via_graphql method

def fetch_issue_type_id(repo, issue_type_name)
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  owner, repo_name = repo.split("/")

  query = <<~GRAPHQL
    query {
      repository(owner: "#{owner}", name: "#{repo_name}") {
        issueTypes(first: 10) {
          nodes {
            id
            name
          }
        }
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end

  issue_type = result.dig("data", "repository", "issueTypes", "nodes").find { |node| node["name"].downcase == issue_type_name.downcase }
  raise "Issue type '#{issue_type_name}' not found." unless issue_type

  issue_type["id"]
end # end of fetch_issue_type_id method

def main
  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: ruby cleanup_obsolete_issues.rb -r REPO"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end

    opts.on("-r", "--repo REPO", "GitHub repository (e.g., 'owner/repo')") do |repo|
      options[:repo] = repo
    end
  end.parse!

  options[:org] ||= ENV["GITHUB_ORG"]
  options[:repo] ||= ENV["GITHUB_REPO"]

  missing_args = []
  missing_args << "organization (--org or GITHUB_ORG)" if options[:org].nil?
  missing_args << "repository (--repo or GITHUB_REPO)" if options[:repo].nil?

  unless missing_args.empty?
    puts "#{Helper::RED}\n  Error: Missing required argument(s): #{missing_args.join(', ')}#{Helper::NORMAL}"
    puts "#{Helper::RED}  Usage: ruby cleanup_obsolete_issues.rb -o ORG -r REPO#{Helper::NORMAL}"
    exit
  end

  repo = "#{options[:org]}/#{options[:repo]}"
  ignore_below = 200

  issues = fetch_obsolete_issues(repo, ignore_below)

  print "\nDo you want to proceed with deleting these issues? (yes/no): "
  confirmation = gets.chomp.downcase
  if confirmation == "yes"
    delete_issues(repo, issues)
  else
    puts "Deletion aborted by the user."
  end
end # end of main method

main
