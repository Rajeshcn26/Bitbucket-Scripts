# Extention entry points will need to accept a parameter of repo i.e. (def start_scanner(repo))
# Extension outputs must be an object of an array of labels and a string issue body
# Issue bodies can contain markdown
#   example
#   return { labels: ['label-a', 'label-b'], issue_body: '| ColA | ColB |\n|------|----------'}
#
# Issue labels and bodies will be appended in order of execution to the issue
# lables will be sanitized to be unique
#
# See extensions.yml for information about extension format

require "yaml"

module ExtensionManager
  @extensions = []

  class << self
    def process_extensions
      Dir.glob(File.join(__dir__, "*.yml")).each do |file|
        puts "\nReading extensions from: #{file}"

        extensions = read_extensions(file)
        next unless extensions

        extensions.each do |lib|
          load_extension(lib, file)
        end
      end
    end

    def read_extensions(file)
      data = YAML.load_file(file)
      return unless data.is_a?(Hash)

      extensions = data["libs"] || data["includes"]
      return unless extensions.is_a?(Array)

      return extensions.select { |lib| lib.is_a?(Hash) }
    end

    def load_extension(lib, file)
      name = lib["name"] || "(unknown)"

      if lib.key?("enabled") && !lib["enabled"]
        puts "Skipping disabled extension: #{name}"
        return
      end

      puts "Loading extension: #{name}"
      require_relative lib["location"]

      args_array = lib["args"] || []
      args_hash = args_array.each_with_object({}) do |item, hash|
        hash[item["name"].to_sym] = item["value"]
      end

      lib["parsed_args"] = args_hash unless args_hash.empty?
      @extensions << lib
    end

    def run_extension(ext, repo)
      entry_point = ext["entry_point"] || "start_#{ext["name"]}"
      args = ext["parsed_args"] || {}
      method_obj = method(entry_point)
      params = method_obj.parameters

      required_keyword_params = params.select { |type, _| type == :keyreq }.map(&:last)
      accepts_kwargs = params.any? { |type, _| type == :keyrest }

      filtered_args = if accepts_kwargs
                        args
                      else
                        args.select { |k, _| required_keyword_params.include?(k) || params.any? { |t, n| t == :key && n == k } }
                      end

      missing = required_keyword_params - filtered_args.keys
      unless missing.empty?
        raise ArgumentError, "Missing required keyword arguments: #{missing.join(', ')}"
      end

      puts " "
      puts "::: Executing #{ext['name']}"
      puts "::: Calling with args: #{filtered_args.inspect}"

      result = filtered_args.any? ? method_obj.call(repo, **filtered_args) : method_obj.call(repo)
      puts "::: Result: #{result.inspect}"

      return result
    rescue => e
      warn "Error running extension #{ext['name']}: #{e.message}"
      return { labels: [], issue_body: "Extension #{ext['name']} failed: #{e.message}" }
    end

    def extensions
      @extensions
    end

  end
end
