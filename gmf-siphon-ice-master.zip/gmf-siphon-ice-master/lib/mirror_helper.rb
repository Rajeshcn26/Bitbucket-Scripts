require_relative "../bb_bin/bbs_api_helper"
require "octokit"

def get_clone_url(bbs_project, bbs_repo)
  repo = BbsApi.get("/rest/api/1.0/projects/#{bbs_project}/repos/#{bbs_repo}")
  clone_url = repo["links"]["clone"].find { |link| link["name"].include?("http") }
  raise "Clone URL not found" unless clone_url

  clone_url["href"]
end

def parse
  issue_body = ENV["issue_body"]
  parsed_variables = {}
  puts "Processing issue body: #{issue_body}"

  if issue_body.include?("---")
    header_section = issue_body.split("---").first.strip

    header_section.each_line do |line|
      if line.include?(":")
        key, value = line.split(":", 2).map(&:strip)
        parsed_variables[key] = value
      end
    end
  end

  source_project_key = parsed_variables["bitbucket-source-project-key"]
  source_repo_slug = parsed_variables["bitbucket-source-repo-slug"]
  target_org = parsed_variables["github-target-org"]
  target_repo_name = parsed_variables["github-target-repo-name"]
  visibility = parsed_variables["visibility"]
  repo_url = parsed_variables["repo-url"]
  repo_git_url = get_clone_url(source_project_key, source_repo_slug)

  system("echo \"source_project_key=#{source_project_key}\" >> $GITHUB_ENV")
  system("echo \"source_repo_slug=#{source_repo_slug}\" >> $GITHUB_ENV")
  system("echo \"target_org=#{target_org}\" >> $GITHUB_ENV")
  system("echo \"target_repo_name=#{target_repo_name}\" >> $GITHUB_ENV")
  system("echo \"visibility=#{visibility}\" >> $GITHUB_ENV")
  system("echo \"repo_url=#{repo_url}\" >> $GITHUB_ENV")
  system("echo \"repo_git_url=#{repo_git_url}\" >> $GITHUB_ENV")
end

def add_to_issue_comment

  repo = ENV["GITHUB_REPOSITORY"]
  comment_id = ENV["COMMENT_ID"]
  token = ENV["GITHUB_TOKEN"]
  summary_path = ENV["GITHUB_STEP_SUMMARY"]

  summary = if summary_path && File.exist?(summary_path)
              File.read(summary_path)
            else
              "⚠️ No job summary available."
            end

  client = Octokit::Client.new(access_token: token)
  client.auto_paginate = true

  response = client.post(
    "/repos/#{repo}/issues/comments/#{comment_id}/replies",
    body: summary
  )

end
