# frozen_string_literal: true
#
# copyright © Xebia. All rights reserved. No unauthorized duplication, distribution or copying.
# Date: 2025-05-08
# Author: Rich Schwarz
#
# This script scans open GitHub issues in a specified repository, extracts a project key from each issue's title, and compares
# it against a list of project keys to ignore (from a text file).  If an issue's project key matches one in the ignore list
# and does not already have the "status-do-not-migrate" label, the script can apply this label to the issue using the GitHub GraphQL API.
# The script prompts for confirmation before labeling any issues.
# It should be run any time new projects are added to the ignore list output/projects_to_ignore.txt.
#
# Usage:
# ruby label_do_not_migrate_repos.rb -o ORG -r REPO
#
# Options:
# -o, --org ORG       GitHub organization (can also be set via the GITHUB_ORG environment variable).
# -r, --repo REPO     GitHub repository (can also be set via the GITHUB_REPO environment variable).
#
# Example:
# ruby label_do_not_migrate_repos.rb -o my-org -r my-repo
#
# Note:
# Ensure that the GH_TOKEN environment variable is set with a valid GitHub token for authentication.
#
require "octokit"
require "optparse"
require "net/http"
require "json"
require_relative "../lib/helpers"

LABEL_VALUE = "status-do-not-migrate" # Constant for the label value


def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def fetch_issues(repo)
  puts "\nFetching open issues from repository '#{repo}' via GraphQL...\n"
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  owner, repo_name = repo.split("/")
  issues = []
  cursor = nil

  loop do
    query = <<~GRAPHQL
      query {
        repository(owner: "#{owner}", name: "#{repo_name}") {
          issues(first: 100, states: OPEN, after: #{cursor.nil? ? "null" : "\"#{cursor}\""}) {
            nodes {
              number
              title
              url
              id
              labels(first: 10) {
                nodes {
                  name
                }
              }
            }
            pageInfo {
              endCursor
              hasNextPage
            }
          }
        }
      }
    GRAPHQL

    request = Net::HTTP::Post.new(uri)
    request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
    request["Content-Type"] = "application/json"
    request.body = { query: query }.to_json

    response = http.request(request)
    result = JSON.parse(response.body)

    if result["errors"]
      raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
    end

    data = result.dig("data", "repository", "issues")
    issues.concat(data["nodes"].map do |issue|
      {
        number: issue["number"],
        title: issue["title"],
        html_url: issue["htmlUrl"],
        node_id: issue["id"],
        labels: issue.dig("labels", "nodes").map { |label| label["name"] }
      }
    end)

    page_info = data["pageInfo"]
    break unless page_info["hasNextPage"]

    cursor = page_info["endCursor"]
    print "."
  end # end of loop

  if issues.empty?
    puts "No open issues found in repository '#{repo}'."
    exit
  end

  issues
end # end of fetch_issues method

def extract_pattern_from_title(title)
  match = title.match(/::([^\/]+)\//) # Match the full string between "::" and "/"
  match ? match[1] : nil
end # end of extract_pattern_from_title method

def load_patterns
  file = File.join(File.dirname(__FILE__), "../output/projects_to_ignore.txt")
  puts "Loading patterns from file '#{file}'..."
  patterns = File.readlines(file).map(&:strip).reject(&:empty?)
  puts "\nLoaded Projects to Ignore: #{patterns.join(', ')}" # Output all patterns on one line
  patterns
end # end of load_patterns method

def fetch_label_id(repo, label_name)
  puts "Fetching label ID for '#{label_name}'..."
  uri = URI("https://api.github.com/graphql")
  http = Net::HTTP.new(uri.host, uri.port)
  http.use_ssl = true

  owner, repo_name = repo.split("/")

  query = <<~GRAPHQL
    query {
      repository(owner: "#{owner}", name: "#{repo_name}") {
        labels(first: 100) {
          nodes {
            id
            name
          }
        }
      }
    }
  GRAPHQL

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{ENV['GH_TOKEN']}"
  request["Content-Type"] = "application/json"
  request.body = { query: query }.to_json

  response = http.request(request)
  result = JSON.parse(response.body)

  if result["errors"]
    raise "GraphQL Error: #{result['errors'].map { |e| e['message'] }.join(', ')}"
  end

  label = result.dig("data", "repository", "labels", "nodes").find { |node| node["name"] == label_name }
  raise "Label '#{label_name}' not found in repository '#{repo}'." unless label

  label["id"]
end # end of fetch_label_id method

def label_issue(repo, issue_number, label_name)
  # puts "Updating issue ##{issue_number} in repository '#{repo}' with label '#{label_name}'..."
  client.add_labels_to_an_issue(repo, issue_number, [label_name])
end # end of label_issue method

def label_matching_issues(repo, issues, patterns)
  matching_issues = issues.select do |issue|
    pattern = extract_pattern_from_title(issue[:title])
    pattern && patterns.include?(pattern) && !issue[:labels].include?(LABEL_VALUE)
  end # end of select block

  if matching_issues.empty?
    puts "No matching issues found to label."
    return
  end

  puts "\n\nThe following issues will be labeled with '#{LABEL_VALUE}':"
  matching_issues.each do |issue|
    puts "  #{issue[:title]}"
  end # end of each block
  puts "Total issues to label: #{matching_issues.size}"

  print "Do you want to proceed with labeling these issues? (yes/no): "
  confirmation = gets.chomp.downcase

  if confirmation == "yes"
    matching_issues.each do |issue|
      begin
        puts "Labeling ##{issue[:number]}: '#{issue[:title]}'"
        label_issue(repo, issue[:number], LABEL_VALUE)
        # puts "Issue ##{issue[:number]} labeled successfully."
      rescue StandardError => e
        puts "Error processing issue ##{issue[:number]}: #{e.message}"
      end
    end # end of each block
  else
    puts "No issues were labeled."
  end
end # end of label_matching_issues method

def main
  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: ruby label_do_not_migrate_repos.rb -r REPO"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end

    opts.on("-r", "--repo REPO", "GitHub repository (e.g., 'owner/repo')") do |repo|
      options[:repo] = repo
    end
  end.parse! # end of OptionParser block

  options[:org] ||= ENV["GITHUB_ORG"]
  options[:repo] ||= ENV["GITHUB_REPO"]

  missing_args = []
  missing_args << "organization (--org or GITHUB_ORG)" if options[:org].nil?
  missing_args << "repository (--repo or GITHUB_REPO)" if options[:repo].nil?

  unless missing_args.empty?
    puts "#{Helper::RED}\n  Error: Missing required argument(s): #{missing_args.join(', ')}#{Helper::NORMAL}"
    puts "#{Helper::RED}  Usage: ruby label_do_not_migrate_repos.rb -o ORG -r REPO#{Helper::NORMAL}"
    exit
  end

  repo = "#{options[:org]}/#{options[:repo]}"

  patterns = load_patterns
  issues = fetch_issues(repo)
  label_matching_issues(repo, issues, patterns)
end # end of main method

main # end of script
