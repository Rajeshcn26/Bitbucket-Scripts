# frozen_string_literal: true
require "octokit"

def create_github_issue_body(issue_data)
  metadata = issue_data["metadata"]

  # Ensure metadata is a hash
  unless metadata.is_a?(Hash)
    raise ArgumentError, "Expected metadata to be a Hash, got #{metadata.class}"
  end # end of unless block

  # Safely access metadata fields
  general_issue_body = metadata.dig(:general, :issue_body) || ""
  combined_issue_body = metadata[:combined_issue_body] || ""

  # Construct the final issue body
  issue_body = <<~MARKDOWN
    bitbucket-source-project-key: #{issue_data["bbs_project_key"]}
    bitbucket-source-repo-slug: #{issue_data["bbs_repo_slug"]}
    github-target-org: #{issue_data["gh_org"]}
    github-target-repo-name: #{issue_data["gh_repo"]}
    visibility: #{issue_data["visibility"]}
    repo-url: #{issue_data["bbs_repo_url"]}

  MARKDOWN

  puts metadata.inspect
  if metadata
    issue_body += <<~TEXT
      ---
      <details open>
      <summary>Repository Metadata</summary>

      #{metadata.dig(:general, :issue_body) || ''}
      #{metadata.dig(:pull_requests, :issue_body) || ''}
      #{metadata.dig(:file_size, :issue_body) || ''}
      #{metadata.dig(:webhooks, :issue_body) || ''}
      #{metadata.dig(:submodules, :issue_body) || ''}
      #{metadata.dig(:user_commit, :issue_body) || ''}
      #{Array(metadata.dig(:extensions, :issue_body)).map(&:strip).reject(&:empty?).join("\n\n")}


      </details>
      <details>
      <summary>Migration & Maintenance Commands Overview</summary>

      Create a comment with:
      ``/dryrun`` || ``/migrate`` || ``/remigrate`` || ``/cutover`` || ``/archive`` || ``/update-issue``
      </details>
    TEXT
  else
    issue_body += <<~TEXT
      ---
      <details>
      <summary>Repository metadata generation problem</summary>
      #{issue_data["command_result"]}
      </details>
    TEXT
  end
end # end of create_github_issue_body method

def create_github_issue_labels(issue_data)
  metadata = issue_data["metadata"]

  source = issue_data["bbs_project_key"]
  destination = issue_data["gh_org"]
  existing_labels = issue_data["labels"]
  mapping_label = issue_data["issue-user-label"]

  labels = ["so_#{source}", "to_#{destination}"]

  if existing_labels
    existing_labels = existing_labels.map(&:name)
    labels_to_keep = existing_labels.select { |label| label.start_with?("user-", "status-") }
    labels += labels_to_keep
  end

  if mapping_label
    labels += [mapping_label.start_with?("user-") ? mapping_label : "user-#{mapping_label}"]
  end

  begin
    labels += metadata ? (metadata[:general] && metadata[:general][:labels] ? metadata[:general][:labels] : []) : []
    labels += metadata ? (metadata[:pull_requests] && metadata[:pull_requests][:labels] ? metadata[:pull_requests][:labels] : []) : []
    labels += metadata ? (metadata[:file_size] && metadata[:file_size][:labels] ? metadata[:file_size][:labels] : []) : []
    labels += metadata ? (metadata[:webhooks] && metadata[:webhooks][:labels] ? metadata[:webhooks][:labels] : []) : []
    labels += metadata ? (metadata[:submodules] && metadata[:submodules][:labels] ? metadata[:submodules][:labels] : []) : []
    labels += metadata ? (metadata[:extensions] && metadata[:extensions][:labels] ? metadata[:extensions][:labels] : []) : []
    labels += metadata ? (metadata[:jenkinsfile] && metadata[:jenkinsfile][:labels] ? metadata[:jenkinsfile][:labels] : []) : []
    labels += metadata ? [] : ["error-metadata-failure"]
  rescue => e
    # Log error and return a fallback label
    puts "Error in create_github_issue_labels: #{e.class} - #{e.message}"
    labels += ["error-metadata-failure"]
    return labels.uniq
  end # end of begin-rescue block

  labels.uniq
end # end of create_github_issue_labels method

def set_github_custom_property(org, repo, variable_name, value)
  puts "Setting variable '#{variable_name}' to '#{value}' in GitHub."

  client = Octokit::Client.new(access_token: ENV["GH_TOKEN"])
  endpoint = "repos/#{org}/#{repo}/properties/values"

  response = client.patch(
    endpoint,
    {
      properties: [
        {
          "property_name" => variable_name,
          "value" => value
        }
      ],
      headers: {
        "Accept" => "application/vnd.github+json",
        "X-GitHub-Api-Version" => "2022-11-28",
        "Content-Type" => "application/json"
      }
    }
  )

  puts "Variable '#{variable_name}' set successfully."
  return response

  rescue Octokit::NotFound => e
    puts "Error: Custom property endpoint not found. Verify that custom properties are enabled for this repository or organization."
    puts "Detailed error: #{e.message}"
  rescue Octokit::Unauthorized => e
    puts "Error: Unauthorized. Check your GitHub token permissions."
    puts "Detailed error: #{e.message}"
  rescue => e
    puts "Error setting custom property: #{e.class} - #{e.message}"
end


def get_issue_labels(repo, issue_number)
  client = Octokit::Client.new(access_token: ENV["GH_TOKEN"])

  client.labels_for_issue(repo, issue_number)
end
