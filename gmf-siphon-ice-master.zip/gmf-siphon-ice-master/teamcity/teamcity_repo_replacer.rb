# frozen_string_literal: true

#!/usr/bin/env ruby

# Example usage:
# replacer = TeamCityRepoReplacer.new(
#   teamcity_root_url: 'https://teamcity.example.com',
#   api_token: 'your_api_token',
#   repository_name: 'old_repo_name',
#   new_repository_name: 'new_repo_name',
#   new_auth_credential: 'new_auth_credential',
#   project_name: 'optional_project_name',
#   build_name: 'optional_build_name',
#   dry_run: true
# )
# replacer.replace_repository


require "json"
require_relative "../lib/log_manager"
require_relative "teamcity_api_helper"


class TeamCityRepoReplacer
  attr_reader :teamcity_url, :api_token, :repository_name, :new_repository_name, :new_auth_credential, :project_name, :build_name, :dry_run, :logger, :api_helper

  def initialize(teamcity_root_url:, api_token:, repository_name:, new_repository_name:, new_auth_credential:, project_name: nil, build_name: nil, dry_run: false)
    @teamcity_root_url = teamcity_root_url
    @api_token = api_token
    @repository_name = repository_name
    @new_repository_name = new_repository_name
    @new_auth_credential = new_auth_credential
    @project_name = project_name
    @build_name = build_name
    @dry_run = dry_run
    @logger = LogManager.new("logs/teamcity_repo_replacer.log")
    @api_helper = TeamCityApiHelper.new(teamcity_root_url, api_token)
  end


  def get_projects
    response = api_helper.api_request("/app/rest/projects", :get)
    return JSON.parse(response.body)["project"]
  end

  def get_builds(project_id)
    response = api_helper.api_request("/app/rest/projects/id:#{project_id}/buildTypes", :get)
    return JSON.parse(response.body)["buildType"]
  end

  def get_vcs_roots
    response = api_helper.api_request("/app/rest/vcs-roots", :get)
    return JSON.parse(response.body)
  end

  def get_vcs_root(vcs_root_id)
    response = api_helper.api_request("/app/rest/vcs-roots/id:#{vcs_root_id}", :get)
    return JSON.parse(response.body)
  end

  # TODO: There are multiple ways to update this, but this is the way to do it. Each property is a part.
  #       authMethod, username, secure:password, url, etc.
  # NOTE: One VCS could be associated with many builds so each would need verified.
  #       DON'T FORGET THE DRY RUN!!
  def update_vcs_root(vcs_root_id)
    vcs_root = fetch_vcs_root(vcs_root_id)

    vcs_root["properties"]["property"].each do |property|
      if property["name"] == "url"
        property["value"] = property["value"].gsub(repository_name, new_repository_name)
      elsif property["name"] == "authMethod"
        property["value"] = new_auth_credential
      end
    end

    api_helper.api_request("/app/rest/vcs-roots/id:#{vcs_root_id}", :put, vcs_root.to_json)
    logger.log("Updated repository #{repository_name} to #{new_repository_name} and updated credential in VCS root #{vcs_root_id}", level: "INFO")
  end
end
