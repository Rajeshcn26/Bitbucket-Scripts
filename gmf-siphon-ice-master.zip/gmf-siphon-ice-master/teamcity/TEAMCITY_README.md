# TeamCity Repository Replacer

This script allows you to locate a project or build in TeamCity that contains a link to a specified repository, replace the repository name, and update the authorization credential. It also supports a dry run mode to perform the actions without making actual changes.

## Prerequisites

- Ruby installed on your machine
- Access to the TeamCity instance with appropriate permissions
- The `log_manager.rb` file included in the `lib` directory for logging

## Usage

To use the `teamcity_repo_replacer.rb` script, follow the instructions below:

1. Clone the repository and navigate to the root directory.

   ```sh
   git clone <repository_url>
   cd <repository_directory>
   ```

2. Install the required dependencies.

   ```sh
   bundle install
   ```

3. Run the script with the necessary input parameters.

   ```sh
   ruby teamcity/teamcity_repo_replacer.rb --teamcity_root_url <teamcity_root_url> --api_token <api_token> --repository_name <repository_name> --new_repository_name <new_repository_name> --new_auth_credential <new_auth_credential> [--project_name <project_name>] [--build_name <build_name>] [--dry_run]
   ```

### Input Parameters

- `--teamcity_root_url`: The root URL of the TeamCity instance.
- `--api_token`: The API token for authentication to the TeamCity instance.
- `--repository_name`: The name of the repository to locate and replace.
- `--new_repository_name`: The new repository name to replace the old one.
- `--new_auth_credential`: The new authorization credential to update.
- `--project_name` (optional): The name of the project to search within. If not specified, all projects will be searched.
- `--build_name` (optional): The name of the build to search within. If not specified, all builds will be searched.
- `--dry_run` (optional): If specified, the script will perform the actions without making actual changes.

### Example Usage

```sh
ruby teamcity/teamcity_repo_replacer.rb --teamcity_root_url "https://teamcity.example.com" --api_token "your_api_token" --repository_name "old_repo_name" --new_repository_name "new_repo_name" --new_auth_credential "new_auth_credential" --project_name "optional_project_name" --build_name "optional_build_name" --dry_run
```

In the example above, the script will locate the specified repository in the given project and build, replace the repository name with the new one, and update the authorization credential. If the `--dry_run` parameter is specified, the script will perform the actions without making actual changes.

## Logging

The script uses the framework logger file `log_manager.rb`, located in the lib directory, for logging. The log file will be created in the `logs` directory with the name `teamcity_repo_replacer.log`. The log file will contain detailed information about the actions performed by the script.

## Notes

- Ensure that you have the necessary permissions to access and modify the TeamCity projects and builds.
- The script requires the `log_manager.rb` file to be present in the `lib` directory for logging purposes.
