# TeamCity Pipeline Rewire

Put Stuff here

## Pipeline Requirements

### App and Permissions

In order for the workflow to run TeamCity replacement scripts, it needs to be able to access the contents of other repositories and create pull requests. Since the repository GitHub token does not cross repository boundaries, a GitHub App will need to be create with the following permissions:

- `Contents`: Read & Write
- `Issues`: Read & Write
- `Metadata`: Read
- `Pull Requests`: Read & Write

---

### Pipeline Secrets and Variables

For the UI replacement job the following secrets are needed to connect to the server and edit the jobs:

- `TEAMCITY_SERVER_URL` (variable)
- `TEAMCITY_API_USER`
- `TEAMCITY_API_TOKEN`
- `DRY_RUN` (variable)

For the GitHub App the following are needed:

- `SIPHON_APP_ID` (variable)
- `SIPHON_APP_PRIVATE_KEY`
