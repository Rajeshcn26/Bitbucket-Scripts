# frozen_string_literal: true

#!/usr/bin/env ruby

require "net/http"
require "json"
require_relative "../lib/log_manager"

class TeamCityApiHelper
  def initialize(teamcity_root_url, api_token)
    @teamcity_root_url = teamcity_root_url
    @api_token = api_token
    @logger = LogManager.new("logs/teamcity_api_helper.log")
  end

  def api_request(endpoint, method, body = nil)
    uri = URI("#{@teamcity_root_url}#{endpoint}")

    request = case method
              when :get
                Net::HTTP::Get.new(uri)
              when :put
                req = Net::HTTP::Put.new(uri, "Content-Type" => "application/json")
                req.body = body if body
                req
              else
                raise ArgumentError, "Unsupported HTTP method: #{method}"
              end

    request["Accept"] = "application/json"
    request["Authorization"] = "Bearer #{@api_token}"

    @logger.log("API Request: #{method.upcase} #{uri}", level: "DEBUG")

    response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: uri.scheme == "https") do |http|
      http.request(request)
    end

    @logger.log("API Response: #{response.code}", level: "DEBUG")
    return response
  end
end
