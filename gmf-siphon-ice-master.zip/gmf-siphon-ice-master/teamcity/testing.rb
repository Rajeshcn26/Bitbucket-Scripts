# frozen_string_literal: true

#!/usr/bin/env ruby
require "json"
require_relative "teamcity_repo_replacer"

teamcity_root_url    = "https://ddaniels.teamcity.com"
api_token            = ENV["TEAMCITY_API_TOKEN"]
repository_name      = "someorg/somerepo"
new_repository_name  = "neworg/newrepo"
new_auth_credential  = "bobjones"
project_name         = ""
build_name           = ""
dry_run              = ENV["DRY_RUN"] == "true"

project_name = nil if project_name.nil? || project_name.strip.empty?
build_name   = nil if build_name.nil? || build_name.strip.empty?


replacer = TeamCityRepoReplacer.new(
  teamcity_root_url:    teamcity_root_url,
  api_token:            api_token,
  repository_name:      repository_name,
  new_repository_name:  new_repository_name,
  new_auth_credential:  new_auth_credential,
  project_name:         project_name,
  build_name:           build_name,
  dry_run:              dry_run
)

# projects = replacer.get_projects
# puts JSON.pretty_generate(projects)
#
# projects.each do |project|
#   puts "Project: #{project['name']} (#{project['id']})"
#   builds = replacer.get_builds(project['id'])
#
#   puts JSON.pretty_generate(builds)
#
#   builds.each do |build|
#     puts "  Build: #{build['name']} (#{build['id']})"
#   end
# end

vcs_roots = replacer.get_vcs_roots
puts JSON.pretty_generate(vcs_roots)

vcs_roots["vcs-root"].each do |vcs_root|
  this_vcs = replacer.get_vcs_root(vcs_root["id"])
  puts JSON.pretty_generate(this_vcs)

  puts " "
  puts "-" * vcs_root["name"].length
end
