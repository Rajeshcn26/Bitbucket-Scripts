never remove comments when generating or changing code

For Ruby Code: at the end of every multiline block of code (ifs, case, methods, etc) add a comment at the end
    with something like "end of <name> of the block" where block is method, if, case, etc.
    use small methods, if a method is too long, try to break it into smaller methods
