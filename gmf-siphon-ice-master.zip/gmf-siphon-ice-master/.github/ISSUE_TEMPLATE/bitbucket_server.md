---
name: BitBucket Server
about: Migrate BitBucket Server repositories to GitHub
title: "[BitBucket Server]:"
labels: bitbucket-server
assignees: ""
---

## Inputs

Provide the following required inputs:

Source Organization: _Replace this text with the BitBucket Server organization to migrate pipelines from._
Team Project: _Replace this text with the BitBucket Server project to migrate pipelines from._
Source Repository Name: _Replace this text with the source repository name._
Destination Repository Name: _Replace this text with the destination repository name._

## Available commands

The following commands can be executed by adding a comment to this issue:

- `/migrate-repo`

  - Invokes the GitHub API's to migrate the repo and all PR data

  - `--target-repo-visibility <internal|private|public>` The visibility of the target repo. Defaults to private. Valid values are public, private, or internal.
