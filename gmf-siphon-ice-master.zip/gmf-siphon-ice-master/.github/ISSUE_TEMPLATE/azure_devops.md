---
name: Azure DevOps
about: Migrate Azure DevOps repositories to GitHub
title: "[Azure DevOps]:"
labels: azure-devops
assignees: ""
---

## Inputs

Provide the following required inputs:

Source Organization: _Replace this text with the Azure DevOps organization to migrate pipelines from._
Team Project: _Replace this text with the Azure DevOps project to migrate pipelines from._
Source Repository Name: _Replace this text with the source repository name._
Destination Repository Name: _Replace this text with the destination repository name._

## Available commands

The following commands can be executed by adding a comment to this issue:

- `/migrate-repo`

  - Invokes the GitHub API's to migrate the repo and all PR data

  - `--target-repo-visibility <internal|private|public>` The visibility of the target repo. Defaults to private. Valid values are public, private, or internal.

- `/integrate-boards`

  - Configures the Azure Boards<->GitHub integration in Azure DevOps.

- `/configure-autolink`

  - Configures Autolink References in GitHub so that references to Azure Boards work items become hyperlinks in GitHub.

- `/rewire-all-pipelines --service-connection-id <service-connection-id> (REQUIRED)`

  - Updates all Azure Pipelines in the source ADO repository to point to a GitHub repo instead of an Azure Repo.

  - `--ado-pipeline <ado-pipeline> (REQUIRED)` The path and/or name of your pipeline. If the pipeline is in the root pipeline folder this can be just the name. Otherwise you need to specify the full pipeline path (E.g. \Services\Finance\CI-Pipeline)

  **Note:** A global default service connection can be configured in the `global_defaults.yml` configuration file.

- `/rewire-pipeline --ado-pipeline <ado-pipeline> (REQUIRED) --service-connection-id <service-connection-id> (REQUIRED)`

  - Updates an Azure Pipeline to point to a GitHub repo instead of an Azure Repo.

  - `--ado-pipeline <ado-pipeline> (REQUIRED)` The path and/or name of your pipeline. If the pipeline is in the root pipeline folder this can be just the name. Otherwise you need to specify the full pipeline path (E.g. \Services\Finance\CI-Pipeline)

  **Note:** A global default service connection can be configured in the `global_defaults.yml` configuration file.

- `/lock-ado-repo`

  - Makes the ADO repo read-only for all users. It does this by adding Deny permissions for the Project Valid Users group on the repo.

- `/disable-ado-repo`

  - Disables the repo in Azure DevOps. This makes the repo non-readable for all.

- `/add-team-to-repo --team <team> (REQUIRED) --role <admin|maintain|pull|push|triage> (REQUIRED)`

  - Adds a team to a repo with a specific role/permission

  - `--role <admin|maintain|pull|push|triage> (REQUIRED)` The only valid values are: pull, push, admin, maintain, triage. For more details see <https://docs.github.com/en/rest/reference/teams#add-or-update-team-repository-permissions>, custom repository roles are not currently supported.

- `/reclaim-mannequin --mannequin-user <mannequin-user> --mannequin-id <mannequin-id> --target-user <target-user> --force`

  - Reclaims one or more mannequin user(s). An invite will be sent and the user(s) will have to accept for the remapping to occur.

  - `--mannequin-user <mannequin-user>` The login of the mannequin to be remapped.

  - `--mannequin-id <mannequin-id>` The Id of the mannequin, in case there are multiple mannequins with the same login you can specify the id to reclaim one of the mannequins.

  - `--target-user <target-user>` The login of the target user to be mapped.

  - `--force` Map the user even if it was previously mapped

- `/share-service-connection --service-connection-id <service-connection-id> (REQUIRED)`

  - Makes an existing GitHub Pipelines App service connection available in another team project. This is required before you can rewire pipelines.
