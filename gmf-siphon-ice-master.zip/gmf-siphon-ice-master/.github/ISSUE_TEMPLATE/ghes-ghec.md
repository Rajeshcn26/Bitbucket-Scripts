---
name: GHES / GHEC
about: Migrate GitHub to GitHub
title: "[TEAM]:"
labels: github-repo
assignees: ""
---

## Process

- Fill in your team name in the title of this issue
- Create a new comment below with the repos you want to migrate, one per line. Example:

```text
repo_one
repo_two
repo_three
```

- Save the issue comment and the migration process will start
- When complete, a new comment will be added with the status of the migration. It has 2 sections:

  1. ::: Failure logs
  1. ::: Migration logs

- If the failure section is empty then all repos were migrated successfully.
- Migration logs section:
  - These are generally informational; but if some PRs, issues or other content was not migrated or other problems were encountered, they will be listed here.

## Troubleshooting

- In the comment that is created the URL for the GitHub Actions workflow run is included. There are three key artifacts attached to the run:
  1. `include-repos` - this is a list of the repos that were included in the migration (directly copied from the issue comment)
  1. `logs` - this is the log output from the migration process.
  1. `migration-script` - this is the script that was run to migrate the repos
