# Bitbucket Migrator AKA Siphon

      ___________
     /=//==//=/  \
    |=||==||=|    |
    |=||==||=|~-, |
    |=||==||=|^.`;|
    |=||==||=|^.`;|
     \=\\==\\=\`=.:
      `"""""""`^-,`.
               `.~,'
              ',~^:,
              `.^;`.
               ^-.~=;.
                  `.^.:`.

Painlessly migrate your Bitbucket Repos to GitHub

## Table of Contents

- [Overview](#overview)
- [Requirements to Run This Tool](#requirements-to-run-this-tool)
  - [About the GitHub App for Siphon](#about-the-github-app-for-siphon)
  - [Bitbucket User Permission Requirements](#bitbucket-user-permission-requirements)
  - [Bitbucket SFTP Requirements](#bitbucket-sftp-requirements)
  - [Required GH Actions Secrets & Variables](#required-gh-actions-secrets--variables)
  - [Required Repository Custom Properties](#required-repository-custom-properties)
- [Steps to Perform a Migration](#steps-to-perform-a-migration)
  - [1. Create Project to Org Mapping File](#1-create-project-to-org-mapping-file)
  - [2. Create IssueOps Migration Issues](#2-create-issueops-migration-issues)
  - [3. Dry Run](#3-dry-run)
  - [4. Production Migration](#4-production-migration)
- [Post-Migration Tasks](#post-migration-tasks)
  - [Rewire Pipelines](#rewire-pipelines)
    - [Rewire Pipeline - Jenkins](#rewire-pipeline---jenkins)
    - [Rewire Pipeline - TeamCity](#rewire-pipeline---teamcity)
  - [Archive the Bitbucket Repository](#archive-the-bitbucket-repository)
- [FAQ / Troubleshooting](#faq--troubleshooting)
- [Implementation Details](#implementation-details)
  - [bb_bin](#bb_bin)
  - [Workflows](#workflows)
  - [Commands Overview](#commands-overview)
- [Additional Documentation](#additional-documentation)
  - [Jenkins Pipeline Rewiring](jenkins/JENKINS_PIPELINE_REWIRING.md)
  - [TeamCity Pipeline Rewiring](teamcity/TEAMCITY_PIPELINE_REWIRING.md)
- [Feature Branch Testing](#feature-branch-testing)

## Troubleshooting Overview

- [Bitbucket export failed](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Abb-failed-export) - <code>Repo need intervention</code>
- [Blob Size Error](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Ablob-size-error) - <code>Repo need intervention</code>
- [Blob Size Warning](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Ablob-size-warning) - <code>May need repo need intervention</code>
- [Migration Error](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Amigration-error)
- [Status Dryrun Failure](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Astatus-dryrun-failure)
- [Size Huge](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Asize-huge)
- [Size Large](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Asize-large)
- [Error Metadata Failure](https://github.com/OWNER/xsiphon/issues?q=is%3Aissue%20state%3Aopen%20label%3Aerror-metadata-failure)

## Requirements to run this tool

> [!IMPORTANT]
> Siphon is intended to be run as an IssueOps tool, which triggers various GitHub Actions workflows based on issue comments and/or labels. This document describes the various scripts which are run as a part of this process, however it is not intended to be run manually. If you are looking for a tool to run manually, please consult with the Xebia consulting team.

The following tools must be installed on the GitHub Actions Runners which are running this tool. These can be installed either through the GitHub Actions workflow, or by using a custom GitHub Actions Runner image (when able). Xebia recommends using a custom GitHub Actions Runner image, as this will prevent requiring the installation of these tools on every workflow run.

- `git` is required to be installed on the machine that is running this tool. For more information, see <https://git-scm.com/>
- `git lfs` is required to be installed on the machine that is running this tool. For more information, see <https://git-lfs.com/>
- `ruby` is required to be installed on the machine that is running this tool. For more information, see <https://www.ruby-lang.org/en/>
- The Bitbucket account used for the migration MUST have Admin or Super Admin permissions.

### About the GitHub App for Siphon

To use Siphon, you'll first need a GitHub App which will handle the migration activities. To do this, you'll need to create and install a GitHub App with the following permissions:

- Repository - `administration` - Read-only
- Repository - `contents` - Read & Write
- Repository - `issues` - Read & Write
- Repository - `metadata` - Read-only
- Repository - `pull requests` - Read & Write

### Bitbucket User Permission Requirements

To perform migrations, a Bitbucket user with eiter Admin or Super Admin permissions is required. This is because server-level operations are being performed as part of the migration (for example - creating the archive files) and the Bitbucket API does not allow this to be done by only using a token. Additionally, these credentials must have the ability to be used for the Bitbucket API calls using Basic Auth (username/password) - MFA must not be required for this user, and it cannot be an IDP user.

### Bitbucket SFTP Reqirements

To perform migrations, the Bitbucket server must be configured to allow SFTP access. This is because the migration process uses SFTP to retrieve the archive files that are created during the migration process. The SSH user must have access to the home directory of the Bitbucket server, and login must use key-based authentication. An example of how to set up and configure SFTP access is:

```bash
#!/bin/bash

SFTP_USER="sftpuser"
SFTP_PWD='[REDACTED]'
SFTP_USER_PUBLIC_KEY='[REDACTED]'

# NOTE - THIS SCRIPT ASSUMES DEBIAN LINUX FLAVOR IS IN USE...

# Install openssh-server
apt update && apt install -y openssh-server

# Create the SFTP user (user that'll be using SFTP)
useradd -m -g root "$SFTP_USER"
usermod --password $(echo "$SFTP_PWD" | openssl passwd -1 -stdin) "$SFTP_USER"

# Add the public key to the SFTP user as an authorized key
mkdir -p "/home/$SFTP_USER/.ssh/"
echo "$SFTP_USER_PUBLIC_KEY" >> "/home/$SFTP_USER/.ssh/authorized_keys"

# Configure openssh to use its internal server for SFTP
sed -i 's/Subsystem[[:space:]]\+sftp[[:space:]]\+\/usr\/lib\/openssh\/sftp-server/Subsystem sftp internal-sftp/' /etc/ssh/sshd_config

# Start the service - this assumes that systemd is not in play...  it usually isn't in the BBS containers
service ssh start
```

### Required GH Actions Secrets & Variables

To use Siphon, the following GH Actions Secrets & Variables are required:

#### Secrets

- `AZURE_STORAGE_CONNECTION_STRING` - the connection string for the Azure Storage account. This is used to store the repository archives generated during the migration process.
- `BB_ACCT_PASSWORD` - password for the Bitbucket account that is being used for the migration
- `BB_ACCT_TOKEN` - token for the Bitbucket account that is being used for the migration (this is used to analyze repos as part of creating issues for the migration)
- `BB_SSH_KEY` - the SSH key for the Bitbucket server. This is used to retrieve the repository archives generated during the migration process.
- `GH_PAT` - a GitHub PAT Token (classic) to be used for the migration. For more information on what permissions this token requires and why it is required, see [Required scopes for personal access tokens](https://docs.github.com/en/enterprise-cloud@latest/migrations/using-github-enterprise-importer/migrating-from-bitbucket-server-to-github-enterprise-cloud/managing-access-for-a-migration-from-bitbucket-server#required-scopes-for-personal-access-tokens)
- `SIPHON_APP_PRIVATE_KEY` - the private key for the GitHub App that was created for Siphon

#### Variables

- `BB_ACCT_USER` - username for the Bitbucket account that is being used for the migration. See above for permissions requirements.
- `BB_SERVER_URL` - the URL of the Bitbucket server, including the port and `http` or `https`.
- `BB_SSH_USER` - the SSH user for the Bitbucket server. This is used to retrieve the repository archives generated during the migration process.
- `BB_SSH_HOST` - the SSH host for the Bitbucket server. This is used to retrieve the repository archives generated during the migration process.
- `DEFAULT_GITHUB_ORG` - the GitHub organization to migrate the projects to (by default). This can be edited in the generated CSV file after this runs to change the mappings.
- `SIPHON_APP_ID` - the ID of the GitHub App that was created for Siphon
- `SIPHON_APP_NAME` - the name of the GitHub App that was created for Siphon
- [Optional] `BB_SSH_PORT` - the SSH port for the Bitbucket server. If this is not set, defaults to `22`.
- [Optional] `BB_SHARED_HOME_DIR` - the _"shared home"_ directory on the Bitbucket server. If this is not set, defaults to `/var/atlassian/application-data/bitbucket/shared`.
- [Optional] `ISSUE_LABELS` - a comma separated list of labels to apply to the issue that is created. If you don't want any labels, this can be omitted.
- [Optional] `SANDBOX_ORG` - The GitHub organization used as the _"sandbox"_ environment. This is used when the `/dry-run` command is used. If this is not set, defaults to `X-SANDBOX`.
- [Optional] `RUNNER_LABELS` - A JSON formatted array of custom runner labels to be used when executing workflows. If this is not set, defaults to `ubuntu-latest`. Ex: ["self-hosted","runners-small"] or ["image-s0"]

### Required Repository Custom Properties

Siphon will automatically add custom properties to the repositories that are migrated in order to provide traceability back to the Bitbucket source repositories. These custom properties have to be configured at the organization level, and should be added prior to the migration. The following custom properties are expected:

- `bbs-source-project-key` - the Bitbucket project key for the source repository
- `bbs-source-repo` - the Bitbucket repository slug for the source repository
- `bbs-source-link` - the Bitbucket repository URL for the source repository

## Steps to perform a migration

### 1. Create Project to Org mapping file

- Ensure the repository is set up to allow actions workflows to create Pull Requests. For more details, see ["Preventing GitHub Actions from creating or approving pull requests"](https://docs.github.com/en/enterprise-cloud@latest/repositories/managing-your-repositorys-settings-and-features/enabling-features-for-your-repository/managing-github-actions-settings-for-a-repository#preventing-github-actions-from-creating-or-approving-pull-requests).
- Run the **"Create Project to Org mapping file"** workflow.
- The workflow will create the project to org mapping file, push it to a new branch named `create-mapping-file`, and create a pull request.
- IF this workflow is not able to create the pull request, it will still create the mapping file and push it to a branch named `create-mapping-file`. You can manually open the Pull Request.
- Review the pull request. If needed, you can edit the CSV file to change the orgs that the projects will be migrated to.
- Merge the pull request.

### 2. Create IssueOps Migration Issues

Once the project to org mapping file is created, the IssueOps migration issues can be created. These are what are used to perform the actual migration. This is done by running the **"Create Issues"** workflow. This workflow will loop through all of the projects in the mapping file and create an issue for each repository in the projects. This process also performs an analysis of the repository to determine readiness for migration, and will add labels to the issues based on the analysis. Analysis points include:

- Repo size (as in the size of the repo on disk)
- Last commit date
- Default branch name
- Number of pull requests
- List of large files (> 50MB)
  - This also will flag if the repo has any files >100MB, which would be a blocker for migration. Repos with this problem will have the `blob-fail` label added to them.
- List of large files tracked by LFS

#### Setting the Maximum Repositories to Process

The script `create_gh_issues_for_bbs_projects.rb` allows you to limit the number of repositories processed per project by setting the `MAX_REPOS_TO_PROCESS` environment variable. This is useful for testing or when you want to process only a subset of repositories.

- **Default Value**: If `MAX_REPOS_TO_PROCESS` is not set, the script defaults to processing up to `10,000` repositories per Bitbucket Project.
- **How to Set**: You can set this variable in your environment before running the script. For example:

```bash
export MAX_REPOS_TO_PROCESS=2
```

This will limit the script to process only the first 50 repositories for each project.

#### Running the Refresh Script from the Command Line

The refresh script (`create_gh_issues_for_bbs_projects.rb`) can also be run directly from the command line. This script is used to refresh or create GitHub issues for repositories in Bitbucket projects based on the mapping file. It analyzes the repositories and generates metadata to determine readiness for migration.

##### General Overview

The script processes a mapping file that contains the Bitbucket project-to-GitHub organization mappings. For each repository in the specified projects, it performs the following steps:

1. Retrieves metadata about the repository, such as size, pull requests, and last commit date.
2. Creates or updates a GitHub issue in the specified repository with the metadata.
3. Labels the issue based on the analysis results.

##### Required Arguments

- `--org ORG`: The GitHub organization where the issues will be created.
- `--repo REPO`: The GitHub repository where the issues will be created.

##### Optional Arguments

- `--bbkey BB_KEY`: The Bitbucket project key to process. If not provided, all projects in the mapping file will be processed.
- `--mapping-file MAPPING_FILE`: Path to the Bitbucket project-to-GitHub organization mapping file.
- `--project-file FILE`: Path to an input file containing a list of Bitbucket project keys to process. This file must be located in the `output` directory.
- `--help`: Prints the help message and exits.

##### Example Usage

```bash
ruby bb_bin/create_gh_issues_for_bbs_projects.rb --org my-org --repo my-repo --mapping-file output/alternate_bitbucket_projects_mapping.csv
```

In this example:

- Issues will be created in the `my-github-repo` repository under the `my-github-org` organization.
- The mapping file `output/alternate_bitbucket_projects_mapping.csv` will be used to determine the Bitbucket project-to-GitHub organization mappings.

To process a specific Bitbucket project:

```bash
ruby bb_bin/create_gh_issues_for_bbs_projects.rb --org my-org --repo my-repo --bbkey MY_PROJECT_KEY
```

To process multiple projects listed in an input file:

```bash
ruby bb_bin/create_gh_issues_for_bbs_projects.rb --org my-org --repo my-repo --project-file my_projects_list
```

In this case, `my_projects_list` should be located in the `output` directory and contain one Bitbucket project key per line. Lines starting with a # are ignored as comments

### 3. Dry Run

> [!TIP]
> To perform a dry run migration in bulk, select the issues you want to perform a dry run migration on and add the `cmd-dryrun` label to them. This will trigger a dry run migration for all of the selected issues.

Create a new comment with `/dryrun` on the first line. This will trigger a dry run of the migration for the repo. This will migrate the repository to the organization defined in the `SANDBOX_ORG` actions variable. This is a good way to test the migration before actually performing it. The dry run will also give an idea of _how long_ each migration will take, as it will perform the same steps as the actual migration. Dry run times (in seconds) are recorded in the issue body, and a label is added to the issue to indicate an approximate time to migrate the repo.

The dry run will perform the following actions:

1. Export the repo from Bitbucket
2. Import the repo into GitHub
3. If there is LFS content, migrate the LFS content
4. Add custom properties to the GitHub repo that point back to the Bitbucket repo
5. If there are webhooks to be migrated, migrate the webhook events in an _INACTIVE_ state
6. Collect and process logs
7. Update the `/migrate` comment with the results of the migration

### 4. Production Migration

> [!TIP]
> To perform a migration in bulk, select the issues you want to perform a migration on and add the `cmd-migrate` label to them. This will trigger a migration for all of the selected issues.

Create a new comment with `/migrate` on the first line. This will trigger the migration of the repo for this issue. The migration will perform the following actions:

1. Export the repo from Bitbucket
2. Import the repo into GitHub
3. If there is LFS content, migrate the LFS content
4. Add custom properties to the GitHub repo that point back to the Bitbucket repo
5. If there are webhooks to be migrated, migrate the webhook events in an _ACTIVE_ state
6. Collect and process logs
7. Update the `/migrate` comment with the results of the migration

To watch the progress of the migration, you can view the Actions tab for the repo and look for the `Migrate Repository` workflow run which is named the same as the issue title. For example, if the issue is named **"crazy_lumiere::CRAZ/juice-shop"** the workflow run will be named **"Migrate Repository - crazy_lumiere::CRAZ/juice-shop"**.

#### Migration Status Labels

During a migration run, the issue will be updated with one of the following labels:

- `execution-in-progress` - the migration is in progress
- `status-migration-success` - the migration was successful
- `status-migration-failure` - the migration failed

#### Remigration

> [!TIP]
> To perform a remigration in bulk, select the issues you want to perform a remigration on and add the `cmd-remigrate` label to them. This will trigger a remigration for all of the selected issues.

If you need to remigrate a repo, you can do so by adding a comment with `/remigrate` on the first line. This will trigger a remigration of the repo for this issue. The remigration will perform the same steps as the production migration, with the added step of deleting the GitHub repo before migrating it again.

## Post-Migration Tasks

### Rewire Pipelines

Pipelines will need to be updated to use GitHub as their source. This can be done by running the **"Rewire Pipeline"** processes. Currently, there is scripting for Jenkins and TeamCity pipelines.

#### Rewire Pipeline - Jenkins

For details on how to rewire Jenkins pipelines after a successful migration, refer to the [JENKINS_PIPELINE_REWIRING.md](jenkins/JENKINS_PIPELINE_REWIRING.md) file.

#### Rewire Pipeline - TeamCity

For details on how to rewire TeamCity pipelines after a successful migration, refer to the [TEAMCITY_PIPELINE_REWIRING.md](teamcity/TEAMCITY_PIPELINE_REWIRING.md) file.

### Archive the Bitbucket Repository

> [!TIP]
> To archive Bitbucket repositories in bulk, select the issues you want to archive and add the `cmd-archive` label to them. This will trigger an archive for all of the selected issues.

Once the migration is complete, the Bitbucket repository should be archived. Archiving in Bitbucket prevents users from being able to modify the repository, while still enabling them to view it in case they need to verify something. This can be done by adding a comment with `/archive` on the first line. This will trigger the archiving of the repo for this issue.

If a repository needs to be unarchived, this can be done manually by going to the repository settings and unchecking the _"Archived"_ checkbox in Bitbucket.

## FAQ / Troubleshooting

- GitHub does not allow spaces in Repo names. You must change your name in Bitbucket before attempting the migration if there is a space in the Repo's name.
- [Post migration tasks](https://docs.github.com/en/migrations/using-github-enterprise-importer/migrating-from-bitbucket-server-to-github-enterprise-cloud/overview-of-a-migration-from-bitbucket-server-to-github-enterprise-cloud#completing-follow-up-tasks)

## Implementation Details

### bb_bin

The `bb_bin` folder contains the following Ruby scripts:

- [`migrate_repos.rb`](bb_bin/migrateRepos.rb): Performs the repository migration. This is expected to be run as part of the issueops-triggered `Migrate Repository` GitHub Actions workflow. The following ENV vars are expected:
  - `BB_ACCT_USER` - username of the Bitbucket account that is being used for the migration.
  - `BB_ACCT_PASSWORD` - password of the Bitbucket account that is being used for the migration.
  - `BB_ACCT_TOKEN` - an access token for the Bitbucket account that is being used for the migration. This is used to analyze repos as part of creating issues for the migration.
  - `BB_SERVER_URL` - the URL of the Bitbucket server, including the port and `http` or `https`.
  - `BB_SSH_USER` - the SSH user for the Bitbucket server. This is used to retrieve the repository archives generated during the migration process.
  - `BB_SSH_KEY` - the SSH key for the Bitbucket server. This is used to retrieve the repository archives generated during the migration process.
  - `GH_TOKEN` - a GitHub PAT token (classic) to be used for the migration. See above for additional information.
  - `AZURE_STORAGE_CONNECTION_STRING` - the connection string for the Azure Storage account. This is used to store the repository archives generated during the migration process.
  - `BB_SSH_PORT` [optional] - the SSH port for the Bitbucket server. If this is not set, defaults to `22`.
  - `GITHUB_ORG_SANDBOX` [optional] - the GitHub organization used as the _"sandbox"_ environment. This is used when the `/dry-run` command is used. If this is not set, defaults to `X-SANDBOX`.
  - `BB_SHARED_HOME_DIR` [optional] - the _"shared home"_ directory on the Bitbucket server. If this is not set, defaults to `/var/atlassian/application-data/bitbucket/shared`.
- [`create_bbs_projects_to_gh_org_mapping_file.rb`](bb_bin/create_bbs_projects_to_gh_org_mapping_file.rb): Reads all projects from Bitbucket and creates a CSV file that maps the Bitbucket project to the GitHub organization. This is used to create the initial issues for a migration. This script is run by the `Create Project to Org Mapping File` workflow. It can also be run manually if needed. The following ENV vars are expected:
  - `BB_ACCT_USER` - username of the Bitbucket account that is being used for the migration.
  - `BB_ACCT_PASSWORD` - password of the Bitbucket account that is being used for the migration.
  - `BB_SERVER_URL` - the URL of the Bitbucket server, including the port and `http` or `https`.
  - `GITHUB_ORG` - the GitHub organization to migrate the projects to (by default). This can be edited in the generated CSV file after this runs to change the mappings.
  - `ISSUE_LABELS` - a comma separated list of labels to apply to the issue that is created. If you don't want any labels, this can be omitted.
- [`create_gh_issues_for_bbs_projects.rb`](bb_bin/create_gh_issues_for_bbs_projects.rb): Creates the GitHub issues used by the IssueOps migration process. This uses the file output by `create_bbs_projects_to_gh_org_mapping_file.rb` as an input to know how to map projects to GitHub organizations while creating issues. The following ENV vars are expected:
  - `BB_ACCT_USER` - username of the Bitbucket account that is being used for the migration.
  - `BB_ACCT_PASSWORD` - password of the Bitbucket account that is being used for the migration.
  - `BB_ACCT_TOKEN` - an access token for the Bitbucket account that is being used for the migration. This is used to analyze repos as part of creating issues for the migration.
  - `BB_SERVER_URL` - the URL of the Bitbucket server, including the port and `http` or `https`.
  - `GITHUB_ORG` - the GitHub organization to create the issues in.
  - `GITHUB_REPO` - the GitHub repository to create the issues in.
- [`analyze-repo.rb`](bb_bin/analyze-repo.rb): Analyzes a repository to collect metadata and determine readiness for migration, along with any _"risk areas"_ which can be identified. This is used by the `cerate_gh_issues_for_bbs_projects.rb` script as part of how labels and the issue body metadata is generated.
- [`add_custom_properties_to_repo.rb`](bb_bin/add_custom_properties_to_repo.rb): Adds custom properties to the GitHub repository which point back to the Bitbucket repository that was migrated. The following ENV vars are expected:
  - `GH_TOKEN` - a GitHub PAT token (classic) to be used for the migration. See above for additional information.
- [`archive_repo.rb`](bb_bin/archive_repo.rb): Sets the Bitbucket repository to read-only and archives it. The following ENV vars are expected:
  - `BB_ACCT_USER` - username of the Bitbucket account that is being used for the migration.
  - `BB_ACCT_PASSWORD` - password of the Bitbucket account that is being used for the migration.

### Workflows

The `workflows` folder contains the following GitHub Actions workflows:

- [`migrateRepos.yml`](.github/workflows/migrateRepos.yml): upon creation of an issue comment, it kicks off the workflow that does the dry run. 90% of the work is done by the `migrateRepos.rb` ruby script. After the script runs, the workflow updates the label and logs the repos that successfully migrated.
- [`archive-repo.yml`](.github/workflows/archive-repo.yml): upon creation of an issue comment, it kicks off the workflow that archives the repo in Bitbucket. 90% of the work is done by the `archive_repo.rb` ruby script. After the script runs, the workflow updates the label to indicate success or failure.
- [`create-issues.yml`](.github/workflows/create-issues.yml): this workflow is manually triggered. It creates the issues that are used by the IssueOps migration process. 90% of the work is done by the `create_gh_issues_for_bbs_projects.rb` ruby script. This script also labels all of the issues based off of the repository metadata.
- [`create-labels.yml`](.github/workflows/create-labels.yml): this workflow is manually triggered. It creates the labels that are used by the IssueOps migration process.
- [`create-mapping-file.yml`](.github/workflows/create-mapping-file.yml): this workflow is manually triggered. It creates the project to org mapping file that is used to create the initial issues for a migration. 90% of the work is done by the `create_bbs_projects_to_gh_org_mapping_file.rb` ruby script.
- [`rewire-pipeline-jenkins.yml`](.github/workflows/rewire-pipeline-jenkins.yml): this workflow is triggered by adding the `/rewire-jenkins` comment to an issue. It will rewire the Jenkins pipeline for the repository to point to the new GitHub repository. 90% of the work is done by the `rewire_pipeline_jenkins.rb` ruby script.
- [`superlinter.yml`](.github/workflows/superlinter.yml): this workflow is used as a status check in pull requests to ensure code quality. It uses the [Super-Linter](https://github.com/super-linter/super-linter) action to lint the code using a variety of tools. It also will attempt to fix any issues that it can automatically fix. Linter configurations are stored in the `.github/linters` directory.

## Commands Overview

### `/migrate`

Triggers the migration of repositories listed in the issue comment. The migration script is generated and executed, and logs are attached to the issue comment.

### `/remigrate`

Deletes the existing repository in the target GitHub organization and then performs a fresh migration.

### `/dryrun`

Simulates the migration process without making any changes. Useful for validating the migration setup.

### `/cutover`

Performs a two-step process:

1. **Archive**: Archives the existing repository in the target GitHub organization.
2. **Remigrate**: Deletes the archived repository and performs a fresh migration.

### Implementation Details for `/cutover`

- The `/cutover` command is handled in the `migrate_repos.rb` script.
- When `/cutover` is detected in the issue comment:
  1. The `archive_repo.rb` script is invoked to archive the repository.
  2. If the archive operation is successful, the command is internally converted to `/remigrate`.
  3. The `/remigrate` logic is executed, which deletes the existing repository and performs a fresh migration.
- This ensures that the repository is archived before being remigrated.

### Example Usage

- To perform a cutover for a repository:

  ```
  /cutover
  ```

  Add this comment to the issue, and the workflow will handle the archive and remigration process automatically.

### Notes

- Ensure that the `archive_repo.rb` script is properly configured and accessible.
- The `/cutover` command is useful for scenarios where a repository needs to be archived before being migrated again.

## Overview

...existing code...

## Requirements to Run This Tool

...existing code...

## Steps to Perform a Migration

...existing code...

## Post-Migration Tasks

...existing code...

## FAQ / Troubleshooting

...existing code...

## Implementation Details

...existing code...

## Additional Documentation

- [Jenkins Pipeline Rewiring](jenkins/JENKINS_PIPELINE_REWIRING.md)
- [TeamCity Pipeline Rewiring](teamcity/TEAMCITY_PIPELINE_REWIRING.md)

## Feature Branch Testing

### Overview

The Siphon migration tool includes a feature branch testing architecture that allows you to test migration changes in feature branches without merging to main first. This enables safe testing and validation of code changes before they affect production migrations.

### How It Works

The feature branch testing uses GitHub Actions workflow (`.github/workflows/feature-branch-test.yml`) that:

- Triggers on special test commands in issue comments
- Checks out your specific feature branch
- Runs migration tests using code from that branch
- Reports detailed results back to the issue

### Available Test Commands

The feature branch workflow triggers on the following commands in issue comments:

**Workflow Trigger Condition:**

```yaml
if: contains(fromJSON('["/feature-test", "/feature-dry-run", "/feature-migrate", "/feature-remigrate", "/feature-cutover", "/test-branch"]'), github.event.comment.body)
```

**Supported Commands:**

| Command                          | Description                                               | Usage Example                           |
| -------------------------------- | --------------------------------------------------------- | --------------------------------------- |
| `/feature-test`                  | Test with default branch (`feature-branch-testing-setup`) | `/feature-test`                         |
| `/feature-test branch-name`      | Test with your specific branch                            | `/feature-test feature/my-changes`      |
| `/feature-dry-run`               | Dry run test with default branch                          | `/feature-dry-run`                      |
| `/feature-dry-run branch-name`   | Dry run test with your specific branch                    | `/feature-dry-run feature/my-changes`   |
| `/feature-migrate branch-name`   | Full migration test with your specific branch             | `/feature-migrate feature/my-changes`   |
| `/feature-remigrate branch-name` | Re-migration test with your specific branch               | `/feature-remigrate feature/my-changes` |
| `/feature-cutover branch-name`   | Cutover test with your specific branch                    | `/feature-cutover feature/my-changes`   |
| `/test-branch branch-name`       | Alternative test command                                  | `/test-branch feature/my-changes`       |
