# Issue Comment Commands: Archive & Cutover Process

Implements a standardized process for archiving and cutover operations via issue comments. The process now requires specifying an approval location for each command, which will be reflected in the status labels.

## Archive Process

### Issue Comment Command

- **Old Syntax:**  
  `/archive`

- **New Syntax:**  
  `/archive <approval-location>`

  Example:  
  `/archive Email`

#### After a successful run:
A label will be added to the issue in the format:
```
status-approval-<approval-location>
```
Example:  
`status-approval-Email`

### Bulk Operation

For bulk archiving, select two labels on the issue:

- `cmd-archive`
- `status-approval-<approval-location>`

> **Note:**  
> If the label `status-approval-<approval-location>` does not exist, create it before proceeding.

---

## Cutover Process

### Issue Comment Command

- **Old Syntax:**  
  `/cutover`

- **New Syntax:**  
  `/cutover <approval-location>`

  Example:  
  `/cutover Excel`

#### After a successful run:
A label will be added to the issue in the format:
```
status-approval-<approval-location>
```
Example:  
`status-approval-Excel`

### Bulk Operation

For bulk cutover, select two labels on the issue:

- `cmd-cutover`
- `status-approval-<approval-location>`

> **Note:**  
> If the label `status-approval-<approval-location>` does not exist, create it before proceeding.

---

## Label Format

When creating approval labels, always use the format:
```
status-approval-<custom-string>
```
Replace `<custom-string>` with the relevant approval location (e.g., `Email`, `Excel`, etc.).

---

## Summary Table

| Operation | Command Syntax                 | Bulk Labels Required                  | Label Creation Format                |
|-----------|-------------------------------|---------------------------------------|--------------------------------------|
| Archive   | `/archive <approval-location>`| `cmd-archive`, `status-approval-<approval-location>`| `status-approval-<approval-location>`|
| Cutover   | `/cutover <approval-location>`| `cmd-cutover`, `status-approval-<approval-location>`| `status-approval-<approval-location>`|

---

## Example Workflow

1. **Comment on issue:**  
   `/archive Email`
2. **System adds label:**  
   `status-approval-Email`
3. **For bulk operation:**  
   - Ensure both `cmd-archive` and `status-approval-Email` labels are present.

---

## Notes

- Always specify the approval location when using archive or cutover commands.
- Labels must be created in the specified format if they do not exist.
- Make sure only one approval label is present for bulk operations.
