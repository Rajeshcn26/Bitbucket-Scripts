# Monthly True Up Procedure


**Frequency:** Monthly  
**Responsible Role:** Migrator

**Overview:** There are 2 halves to the process
   1) Run automation to create new issues in Siphon to find and analyze Repos created in Bitbucket since the last time it was run.
   2) Examine items in the Tracker that do not have Siphon issues created.
**Purpose:** Ensure Bitbucket-to-GitHub project mapping file is up-to-date and reconciled with tracking sources.

# 1) Create Issues/Analyze
## Prerequisites
- Access to Bitbucket and GitHub organization mapping files
- Access to tracking spreadsheet/source
- Required permissions for file updates

## Steps
1. **Review Mapping File**
   - Open the latest mapping file.
   - Compare with tracking spreadsheet/source.
2. **Identify Missing Projects**
   - List projects present in tracking but missing in mapping.
3. **Add New Projects**
   - Use the mapping script to append new projects (do not overwrite existing).
4. **Verify Updates**
   - Confirm new entries are correctly added.
   - Ensure no duplicates.
5. **Document Changes**
   - Log changes in change log or commit message.

## Inputs
- `bitbucket_projects_mapping.csv`
- Tracking spreadsheet/source

## Outputs
- Updated mapping file
- Change log entry

## Related Files
- [procedures.md](procedures.md)

## Notes
- This procedure should be performed at the start of each month.
- Contact Data Steward for questions or issues.

# 2) Examine Tracker Items
Find Items in the spreadsheet that do not have a corresponding Issue in Siphon. 

| Step                                   | Details                                                      |
|-----------------------------------------|--------------------------------------------------------------|
| On the Repo Tracker Tab                 | Filter the State column to only show blank lines (hide OPEN and CLOSED) |
| Check if the Repo exists in Bitbucket   | Click  on the hyperlink in the ID field/column (the column immediately to the left of the State column<br>- If the repo is missing, document that in the "Comment / Next Step" Column<br>- If the repo is there in Bitbucket. <br>&nbsp;&nbsp;&nbsp;&nbsp;--- Check that the name hasn't been changed. If it has been changed then there should be another issue in Siphon with the right name if the monthly true-up process has been run recently.  Document this in the "Comment / Next Step" Column<br>&nbsp;&nbsp;&nbsp;&nbsp;--- Check that the repo is not marked to be ignored in the output/excluded_repos.txt - if it's in there mark it as such in the spreadsheet |
