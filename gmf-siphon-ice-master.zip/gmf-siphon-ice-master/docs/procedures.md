# Procedures Index

| Procedure Name      | Frequency      | Responsible Role | Description                | Link                        |
|---------------------|----------------|------------------|----------------------------|-----------------------------|
| Monthly True Up     | Monthly        | Migrator         | Reconcile project mapping  | [monthly-true-up.md](monthly-true-up.md) |
| Analyze Overview    | As needed      | Analyst          | Overview of Analyze docs   | [Analyze/README.md](Analyze/README.md) |
| Procedures Overview | As needed      | Owner            | Overview of Procedures     | [README.md](README.md) |
<!-- Add more rows as you add more procedures -->

.