# Monthly process:
## Delete Dry Run repos created in Prod (OWNER)
- Since we don't have a sandbox environment, dry runs have just been created in the production environment. To keep our environment clean, periodically we need to remove these dry run repositories.
- Locally, you can run the following command to delete dry run repos: (change the path to point to where you have cloned down the Siphon repo)

```
ruby "c:\code\xsiphon\misc-scripts\rm_repos_by_name.rb" --org OWNER --repo-pattern _dryrun_ --execute
```
- If the `--execute` flag is not passed in, the script will only list the repos that match the pattern and would therefore be deleted.
- The script will prompt for confirmation before actually deleting any repositories.
- It's possible repos could contain the word dryrun so make sure you use the underscores before and after ("_dryrun_").
- Repos that are deleted are recoverable via GH's admin interface.
