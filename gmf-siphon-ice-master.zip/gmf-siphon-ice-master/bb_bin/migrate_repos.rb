# frozen_string_literal: true

#
# copyright © Xebia. All rights reserved. No unauthorized duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz
#
# This software is provided "as is," without warranty of any kind, express or implied, including but not limited to
# the warranties of merchantability, fitness for a particular purpose, and noninfringement. In no event shall the
# authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract,
# tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.
# Use of this software is at your own risk, and no indemnification is provided for any damages or losses incurred.
# this consists of a github actions workflow, and a ruby script that generates a bash migration script.
# the ruby script gets executed by a workflow that is kicked off when a issue comment is created
#
# if the github comment contains "/migrate-these" it gets the list of repos to migrate from the comment, generates the migration script
#   the workflow then attaches the script to the comment body
#   the workflow then executes the script which migrates the repos
#   the workflow then attaches the logs to the comment body.
#
#   if the comment contains "/migrate-all" the ruby script does the same as above, except that it gets the list of repos to migrate
#   from the issue body (not the comment). the workflow then does the same as above.
# the output bash migration will be a script will contain the following line for each repo in the issue body or issue comment (values for the arguments are described below):
#
# Exec { gh bbs2gh migrate-repo --bbs-server-url "http://localhost:7990/" --bbs-password "rich" --bbs-project "EINS" --bbs-repo "thefirst" --github-org "dest" --github-repo "thefirst" --target-repo-visibility private }
#   --bbs-server-url will be got from a gh repo level variable (BB_URL)
#   --bbs-password will be got from a gh org level secret (BB_PAT)
#   --bbs-project is the first column in the list of repos
#   --bbs-repo is the second column
#   --github-org is the third column
#   --github-repo is the fourth column
#
# The following environment variables must be set before calling this script:
#   BB_SERVER_URL
#   BB_ACCT_USER
#   BB_ACCT_PASSWORD
#   BB_SHARED_HOME_DIR
#   BB_SSH_USER
#   BB_SSH_HOST
#   BB_SSH_PORT
#   BB_SSH_KEY
#   GH_TOKEN
#

require "base64"
require "optparse"
require "fileutils"
require "octokit"
require_relative "../lib/helpers"
ERROR_LOG_FILE="error_log.txt"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def split_and_strip(string)
  string.split(",").map { |item| item.gsub(/^::/, "").chomp }
end

def handle_error(errMessage)
  puts errMessage

  File.open($script_path, "a") do |file|
    file.puts(errMessage)
  end

  File.open("migration_result.txt", "a") do |file|
    file.puts("Fail")
  end

  raise errMessage
end

def parse_arguments
  options = {}
  OptionParser.new do |opts|
    opts.on("-c", "--comment COMMENT", "The comment") do |v|
      options[:comment] = v
    end

    opts.on("-b", "--body BODY", "The body") do |v|
      options[:body] = v
    end
  end.parse!

  if options[:comment].nil? || options[:comment].empty?
    puts "Error: Issue Comment must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body' --issue-id 'issue_id'"
    abort
  end

  if options[:body].nil? || options[:body].empty?
    puts "Error: Issue Body must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body' --issue-id 'issue_id'"
    abort
  end

  options
end

def create_migration_script(migration_details, script_path)
  File.open(script_path, "a") do |file|
    repoMigrationScript = <<~TEXT
      # env | sort

      echo "Starting migration for repo: #{migration_details[:bb_repo]}"

      time gh bbs2gh migrate-repo --bbs-project '#{migration_details[:bb_project]}' \\
        --bbs-repo '#{migration_details[:bb_repo]}' \\
        --github-org '#{migration_details[:gh_org]}' \\
        --github-repo '#{migration_details[:gh_repo]}' \\
        --bbs-server-url "$BB_SERVER_URL" \\
        --bbs-username "$BB_ACCT_USER" \\
        --bbs-password "$BB_ACCT_PASSWORD" \\
        --ssh-user "$BB_SSH_USER" \\
        --bbs-shared-home "$BB_SHARED_HOME_DIR" \\
        --ssh-private-key "$BB_SSH_KEY" \\
        --archive-download-host "$BB_SSH_HOST" \\
        --ssh-port "$BB_SSH_PORT" \\
        --target-repo-visibility #{migration_details[:visibility]} \\
        --use-github-storage \\
        --verbose

      EXIT_CODE=$(echo $?)

      for log_file in *octoshift.log; do
        new_name="${log_file/.octoshift/___#{migration_details[:bb_repo]}}";#{' '}
        echo "mv $log_file $new_name"; mv "$log_file" "$new_name";#{' '}
      done

      for log_file in *octoshift.verbose.log; do#{' '}
        new_name="${log_file/.octoshift/___#{migration_details[:bb_repo]}}";#{' '}
        echo "mv $log_file $new_name"; mv "$log_file" "$new_name";#{' '}
      done

      grep '\[ERROR\]' $new_name | grep -v 'Migration ID' | sed 's/.*___//' > error_log.txt

      gh bbs2gh download-logs --github-org '#{migration_details[:gh_org]}' \\
        --github-pat "$GH_TOKEN" \\
        --github-repo '#{migration_details[:gh_repo]}' \\
        --migration-log-file "migration-log_#{migration_details[:gh_org]}_#{migration_details[:gh_repo]}.log"

      rm -f *.octoshi*.log #deletes the logs created by download-logs

      exit $EXIT_CODE
    TEXT

    puts repoMigrationScript
    file.puts(repoMigrationScript)
    file.chmod(0o755)
  end
end

def _handle_verbose_logs(verbose_folder)
  Dir.glob("*verbose*.log").each do |log_file|
    FileUtils.mv(log_file, verbose_folder)
  end
end

def _handle_non_verbose_logs(log_folder)
  Dir.glob("*.log").each do |log_file|
    FileUtils.mv(log_file, log_folder)
  end
end

def _create_migration_result_file(migration_successful)
  File.open("migration_result.txt", "w") do |file|
    file.write(migration_successful ? "Success" : "Fail")
  end
  puts "creating migration result file with #{migration_successful ? 'Success' : 'Fail'}"
end

def collect_and_process_logs(migration_successful)
  logFolder = "logs"
  verboseFolder = "#{logFolder}/verbose"

  Dir.mkdir(logFolder) unless Dir.exist?(logFolder)
  Dir.mkdir(verboseFolder) unless Dir.exist?(verboseFolder)

  _handle_verbose_logs(verboseFolder)
  _handle_non_verbose_logs(logFolder)
  _create_migration_result_file(migration_successful)
end

def remove_existing_repo(migration_details)
  begin
    repo_name = "#{migration_details[:gh_org]}/#{migration_details[:gh_repo]}"

    if client.repository?(repo_name)
      puts "Repo #{repo_name} exists, deleting it..."
      client.delete_repository(repo_name)
    end
  rescue Octokit::Error => e
    puts "Error deleting repo: #{e.response_body}"
    abort
  end
end

def main
  options    = parse_arguments
  comment    = Base64.decode64(options[:comment])
  issue_body = Base64.decode64(options[:body])

  if !comment.match?(/\/((re)?migrate|dryrun|cutover|test)/)
    puts "::error:: The comment passed into this script must contain either '/migrate', '/remigrate', '/dryrun', '/cutover', or '/test'."
    abort
  end

  migration_details = Helper.parse_issue_body(issue_body, comment)

  # Assert - output directory exists
  output_dir = "./output"
  Dir.mkdir(output_dir) unless Dir.exist?(output_dir)
  script_path = "#{output_dir}/migration.sh"

  # Setup the labels file for writing
  labels_file_path = "labels_output.txt"
  File.open(labels_file_path, "w") do |file|
    # Initialize the file without adding any content
  end # end of File.open block

  # If we are performing a cutover, archive the repo first, then remigrate
  if comment.include?("/cutover")
    puts "\n\n:::::::::::::::::::::::::\nPerforming cutover: Archiving the repository first..."
    archive_comment = Base64.encode64("/archive") # Encode the archive command
    archive_exit_code = system("ruby bb_bin/archive_repo.rb --comment '#{archive_comment.strip}' --body '#{options[:body]}'")
    if $?.exitstatus != 0
      puts "::error:: Archiving FAILED with exit code: #{$?.exitstatus}"
      puts "Reason for failure: #{archive_exit_code.inspect}"
      abort
    end
    remove_existing_repo(migration_details)
  end

  # If we are remigrating, we need to delete the old repo first
  if comment.include?("/remigrate")
    remove_existing_repo(migration_details)
  end

  # If /test is passed in, skip migration script execution and set exit_code to success
  if comment.include?("/test")
    puts "::debug:: /test command detected. Skipping migration script execution."
    exit_code = 0
  else
    create_migration_script(migration_details, script_path)

    # Execute the script
    puts "Executing Migration Script: #{script_path}..."

    system("bash #{script_path}")
    exit_code = $?.exitstatus
  end # end of /test check block

  def exit_code_zero?(exit_code)
    exit_code.is_a?(Integer) && exit_code == 0
  end # end of exit_code_zero? method

  if exit_code != 0
    puts "::error:: Migration FAILED!"
    puts "\n\n#:#:#:#:#:#:#:# Migration Script Exit status: #{$?.exitstatus}\n\n"
  else
    puts "::debug::✅ Migration SUCCESSFUL!"
    system("echo 'MIGRATED_REPO_NAME=#{migration_details[:gh_repo]}' >> \"$GITHUB_ENV\"")
    unless comment.include?("/dryrun")
      begin
        team_result = add_repo_to_teams(migration_details) # If add_repo_to_teams returns non-zero, treat as failure
        puts "add_repo_to_teams result: #{team_result.inspect}"
        if !team_result.to_s.include?("name")
          puts "::error:: add_repo_to_teams failed with code: #{team_result}"
          exit_code = team_result
        end
      rescue => e
        puts "Error adding repo to teams: #{e.message}"
        puts e.backtrace.join("\n")
      end
    else
      puts "::debug:: /dryrun detected, skipping add_repo_to_teams."
    end
  end

  collect_and_process_logs(exit_code_zero?(exit_code))
  exit exit_code
end # end of main of the block

# Add the repo to the teams with correct permissions after migration
def add_repo_to_teams(migration_details)

  $client = Helper.setup_octokit_client(ENV["GH_TOKEN"])

  require_relative "../client/frozen/frozen_lib"
  project_key = migration_details[:bb_project]
  repo_name = migration_details[:gh_repo]
  org = migration_details[:gh_org]

  roles = get_team_data(project_key)&.fetch("Roles", {})
  if roles.nil? || roles.empty? # Ensure roles are present before proceeding
    File.open("labels_output.txt", "a") do |file|
      file.puts("status-migration-failure-team")
    end
    puts "::error:: No teams found for project key '#{project_key}' (didnt exist in team_repos.json). Adding 'status-migration-failure-team' label." # GitHub Actions error message
    _create_migration_result_file(false) # this file is read in by the workflow to determine if the migration was successful

    return 9 # end of block if roles are empty
  end

  roles.each do |perm_type, teams|
    perm = perm_type.to_s.downcase == "ro" ? "pull" : "push"
    Array(teams).each do |team_obj|
      team_name = team_obj["name"]
      next unless team_name
      result = add_team_to_repo(org, repo_name, team_name, perm)
      if result == 9
        puts "::error:: Stopping further team processing due to previous error."
        return 9
      end
    end
  end
end # end of add_repo_to_teams of the block

# Add a team to a repo with the specified permission
def add_team_to_repo(org, repo, team_name, permission)
  begin
    teams  = $client.organization_teams(org)
    team   = teams.find { |t| t.name == team_name || t.slug == team_name }
    # puts "this was returned from teams.find: #{team.inspect}"

    if team.nil?
      puts "::error:: Team '#{team_name}' not found in org '#{org}'."
      File.open(labels_file_path, "a") do |file|
        file.puts("status-migration-failure-team")
      end
      # Append error message to error log file
      File.open(ERROR_LOG_FILE, "a") do |f|
        f.puts("[ERROR] Failed to add team '#{team_name}' to repo '#{repo}' in org '#{org}'. Migration failed.")
      end

      _create_migration_result_file(false) # this file is read in by the workflow to determine if the migration was successful

      puts "Available teams:"
      teams.each { |t| puts "  - name: #{t.name}, slug: #{t.slug}, id: #{t.id}" }
      return 9
    end
    puts "  team name: #{team.name} slug: #{team.slug} id: #{team.id}"

    # Find the repo
    repo_full_name = "#{org}/#{repo}"

    result = $client.add_team_repository(team.id, repo_full_name, permission: permission)
    # puts "add_team_repository result: #{result.inspect}"
    if result == false
      puts "Warning: add_team_repository returned false. This is unexpected. Octokit should return true or raise an error."
      puts "This may indicate a problem with the Octokit version or the GitHub API. Please check your Octokit gem version and API compatibility."
      puts "See: https://github.com/octokit/octokit.rb/issues/1486"
    end
    puts "Added '#{repo}' to team '#{team.slug}' with #{permission}"

    add_recore_team_to_repo(org, repo, teams)
  rescue => e
    puts "::error:: Error adding team #{team_name} to repo #{repo}: #{e.message}"
    _create_migration_result_file(false) # this file is read in by the workflow to determine if the migration was successful
    File.open(ERROR_LOG_FILE, "a") do |f|
      f.puts("[ERROR] Exception while adding team '#{team_name}' to repo '#{repo}' in org '#{org}': #{e.message}")
    end # end of File.open block
    return 9
  end # end of begin block
end # end of add_team_to_repo of the block

# Add the repo to the 'recore' team with write access
def add_recore_team_to_repo(org, repo, teams)
  recore_team = teams.find { |t| t.name.downcase == "recore" || t.slug.downcase == "recore" }
  repo_full_name = "#{org}/#{repo}"
  if recore_team
    begin
      recore_result = $client.add_team_repository(recore_team.id, repo_full_name, permission: "push")
      # puts "add_team_repository (recore) result: #{recore_result.inspect}"
      puts "Added #{repo} to recore with push"
      puts "recore_result is: #{recore_result.inspect}"
    rescue => e
      puts "::error: 'recore' team add failed in org '#{org}': #{e.message}"
      _create_migration_result_file(false)
      return 9
    end
  else
    puts "::error: 'recore' team not found in org '#{org}'."
    _create_migration_result_file(false)
    return 9
  end
end # end of add_recore_team_to_repo of the block

if __FILE__ == $0
  main
end
