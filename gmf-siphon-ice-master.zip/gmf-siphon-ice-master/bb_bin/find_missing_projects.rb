# This script prints project keys from projs.txt that do not have a corresponding mapping in bitbucket_projects_mapping.csv (column 2).

projs_path = "output/projs.txt"
mapping_path = "output/bitbucket_projects_mapping.csv"

# Read all project keys from projs.txt (strip whitespace, ignore empty lines)
projs = File.readlines(projs_path).map(&:strip).reject(&:empty?).to_set

# Read all mapped project keys from column 2 of the mapping file (skip comments and header)
mapped = Set.new
File.foreach(mapping_path) do |line|
  next if line.start_with?("#") || line.start_with?("project-id") || line.strip.empty?
  cols = line.split(",")
  mapped.add(cols[1].strip.upcase) if cols.size > 1
end

# Helper to find a sample row for a given project key (to copy structure)
def sample_mapping_row(mapping_path)
  File.foreach(mapping_path) do |line|
    next if line.start_with?("#") || line.start_with?("project-id") || line.strip.empty?
    return line.strip
  end
  nil
end # end of sample_mapping_row method

# Helper to construct a mapping line for a missing project key
def construct_mapping_line(project_key, sample_row)
  cols = sample_row.split(",")
  # project-id,project-key,project-name,project-url,github-org,visibility,github-repo-prefix,issue-user-label
  [
    "TODO_ID", # project-id placeholder
    project_key, # project-key
    project_key, # project-name (default to key)
    "https://stash.OWNER.net/projects/#{project_key}", # project-url
    cols[4] || "OWNER", # github-org
    cols[5] || "private", # visibility
    "#{project_key}.", # github-repo-prefix
    "" # issue-user-label
  ].join(",")
end # end of construct_mapping_line method

sample_row = sample_mapping_row(mapping_path)

missing = projs.reject { |p| mapped.include?(p.to_s.strip.upcase) }.sort
puts "Projects in projs.txt missing from mapping file (column 2):"
missing.each do |p|
  if sample_row
    puts construct_mapping_line(p, sample_row)
  else
    puts p
  end
end
# end of script
