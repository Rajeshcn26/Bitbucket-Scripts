# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2025-03-11
# Author: Matt Olson
#
#
# This script is intended to update the issue body of a Siphon IssueOps issue with updated
# metadata for a Bitbucket Server repository.  It will:
# 1. Get the issue ID from the command line argument
# 2. Get the metadata for the Bitbucket Server repository
# 3. Update the issue body with the new metadata
#
# This script is designed to be run as part of the Siphon IssueOps process, and is not
# intended to be run manually.  It may be run manually for testing purposes.
#
# Usage:
# ruby update-issue.rb --issue-id <issue_id>
#
# Example:
# ruby update-issue.rb --issue-id 12345
#
# This script requires the following environment variables to be set:
# - BB_ACCT_USER: The Bitbucket Server account username for API calls
# - BB_ACCT_PASSWORD: The Bitbucket Server account password for API calls
# - BB_ACCT_TOKEN: The Bitbucket Server account token for repository clone
# - BB_SERVER_URL: The Bitbucket Server URL for API calls
# - GITHUB_ORG: The GitHub organization where the issue is located.
# - GITHUB_REPO: The GitHub repository where the issue is located.
# - SIPHON_APP_PRIVATE_KEY: The private key for the Siphon app used to authenticate with GitHub.
# - SIPHON_APP_ID: The app ID for the Siphon app used to authenticate with GitHub.
#
# This script requires the following gems to be installed:
# - octokit
# - json
# - rufus-scheduler
# - optparse
#

require "octokit"
require "json"
require "rufus-scheduler"
require "optparse"
require_relative "../lib/helpers"
require_relative "../lib/github_helper"
require_relative "./analyze_repo"
require_relative "./bbs_api_helper"

def process_args
  options = {
    issue_id: nil
  }

  parser = OptionParser.new do |opts|
    opts.banner = "Usage: update-issue.rb [options]"

    opts.on("-i", "--issue-id ISSUE_ID", "The issue ID to update") do |v|
      options[:issue_id] = v
    end

    opts.on("-h", "--help", "Show this help message") do
      puts opts
      exit
    end
  end

  parser.parse!

  if options[:issue_id].nil?
    puts "Error: Issue ID is required."
    puts parser.help
    abort
  end

  options
end

def client
  @client = Helper.setup_octokit_client(nil)
  ENV["TZ"] = "Europe/London"
  scheduler = Rufus::Scheduler.new
  scheduler.interval "45m" do
    @client = Helper.setup_octokit_client(nil)
  end
  @client
end

def update_issue(issue_id, gh_issue)
  gh_repo = "#{ENV["GITHUB_ORG"]}/#{ENV["GITHUB_REPO"]}"
  gh_issue_metadata = Helper.parse_issue_body(gh_issue.body, "update")
  bbs_repo = BbsApi.get("/rest/api/latest/projects/#{gh_issue_metadata[:bb_project]}/repos/#{gh_issue_metadata[:bb_repo]}")

  result = get_metadata(bbs_repo)
  updated_metadata = result[:metadata]

  if !updated_metadata
    puts "Error: Unable to retrieve updated metadata for BBS repository #{gh_issue_metadata[:project_key]}/#{gh_issue_metadata[:repo_name]}"
    abort
  end

  issue_data = {
    "bbs_project_key" => bbs_repo["project"]["key"],
    "bbs_repo_slug" => bbs_repo["slug"],
    "bbs_repo_url" => bbs_repo["links"]["self"][0]["href"],
    "gh_org" => gh_issue_metadata[:gh_org],
    "gh_repo" => gh_issue_metadata[:gh_repo],
    "visibility" => gh_issue_metadata[:visibility],

    "command_result" => result[:command_result],
    "metadata" => updated_metadata,

    "labels" => gh_issue.labels,
    "issue-user-label" => nil
  }

  issue_body = create_github_issue_body(issue_data)
  labels = create_github_issue_labels(issue_data)

  puts "labels: #{labels}"

  Helper.assert_gh_issue_labels(client, labels)

  puts "Updating #{gh_issue.title}..."
  client.update_issue(gh_repo, gh_issue.number, title: gh_issue.title, body: issue_body, labels: labels)
  puts "Issue updated successfully."
end

def main
  options = process_args
  issue_id = options[:issue_id]
  repo = "#{ENV["GITHUB_ORG"]}/#{ENV["GITHUB_REPO"]}"
  gh_issue = client.issue(repo, issue_id)

  puts "[DEBUG] Issue Body: #{gh_issue.body}"

  update_issue(issue_id, gh_issue)
end

main
