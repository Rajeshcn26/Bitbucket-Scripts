# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz
#
#
# this script goes through the bb to gh org mapping file (contains a list of bb projects, some hl data,
# and a place holder for someone to put in the correct gh org that the project should be migrated to)
# for each project in the file
#   create a gh issue with similar mapping data but at the repo level
#     (e.g. CMA,CMA-Gen-AI-Search,X-CMA-GH-Org,CMA-Gen-AI-Search)
#     project key, repo name, github org, target repo name

require "csv"
require "octokit"
require "json"
require "optparse"
require "rufus-scheduler"
require "time"
require_relative "../lib/helpers"
require_relative "../lib/github_helper"
require_relative "../lib/extension_manager"
require_relative "./analyze_repo"
require_relative "./bbs_api_helper"


# for testing purposes it's often helpful to limit the number of repos per project to do
$max_repos_to_process = ENV["MAX_REPOS_TO_PROCESS"]&.to_i || 10_000 # Get from env var or default to 10,000
$log_file = "output/log_#{Time.now.getlocal('-05:00').strftime('%Y%m%d')}.log"
Helper.log($log_file, "\n\n###############\nScript started at #{Time.now.getlocal('-05:00').strftime('%Y-%m-%d %H:%M:%S')}", false)

$bb_key = nil # Initialize global variable to avoid warnings
$input_file = nil # Initialize global variable to avoid warnings
$mode = "create" # Initialize mode to 'create' by default

# Creates or updates a GitHub issue for a given Bitbucket Server (BBS) repository.
#
# @param repo [Hash] A hash representing the Bitbucket Server repository. It should include:
#   - "slug" [String]: The repository slug.
#   - "project" [Hash]: A hash containing project details:
#     - "name" [String]: The project name.
#     - "key" [String]: The project key.
#   - "links" [Hash]: A hash containing repository links:
#     - "self" [Array]: An array of hashes with "href" [String] pointing to the repository URL.
#
# @param project_mapping [Hash] A hash mapping project details to GitHub. It should include:
#   - "github-org" [String]: The GitHub organization name.
#   - "github-repo-prefix" [String]: A prefix for the GitHub repository name.
#   - "visibility" [String]: The visibility of the GitHub repository (e.g., "public" or "private").
#   - "issue-user-label" [String]: A label to associate with the issue for user identification.
#
# @return [void]
#
# The method performs the following steps:
# 1. Constructs the issue title using the Bitbucket Server project name, key, and repository slug.
# 2. Checks if an issue with the same title already exists in the GitHub repository.
# 3. Retrieves metadata for the repository using the `get_metadata` method.
# 4. Prepares issue data, including repository details, metadata, and labels.
# 5. Generates the issue body and labels using helper methods.
# 6. Ensures the required labels exist in the GitHub repository.
# 7. Updates the existing issue if found, or creates a new issue if not.
# 8. Outputs the URL of the created or updated issue.

def create_github_issue(repo, project_mapping)

  issue_title = "#{repo['project']['name']}::#{repo['project']['key']}/#{repo['slug']}"
  existing_issue = $open_issues.find { |issue| issue.title == issue_title }

  # Skip updating existing issues if mode is 'create'
  if $mode == "create" && existing_issue
    Helper.log($log_file, "Skipping existing issue: #{issue_title} (mode: create)", true)
    return
  end
  Helper.log($log_file, "############################################ Creating GitHub issue for repo: #{repo['project']['key']}/#{repo['slug']}", true, true)

  result = get_metadata(repo)

  issue_data = {
    "bbs_project_key" => repo["project"]["key"],
    "bbs_repo_slug" => repo["slug"],
    "bbs_repo_url" => repo["links"]["self"][0]["href"],
    "gh_org" => project_mapping["github-org"],
    "gh_repo" => project_mapping["github-repo-prefix"] + repo["slug"],
    "visibility" => project_mapping["visibility"],

    "command_result" => result[:command_result],
    "metadata" => result[:metadata],

    "labels" => existing_issue&.labels,
    "issue-user-label" => project_mapping["issue-user-label"]
  }

  issue_body = create_github_issue_body(issue_data)
  issue_body = handle_large_issue_body(issue_body)
  labels = create_github_issue_labels(issue_data)

  Helper.log($log_file, "  labels: #{labels}", true)
  Helper.assert_gh_issue_labels($client, labels)

  if existing_issue
    updated_issue = $client.update_issue($thisRepo, existing_issue.number, title: issue_title, body: issue_body, labels: labels)
    Helper.log($log_file, "  Updated issue #{issue_title} : #{updated_issue.html_url}", true)
  else
    new_issue = $client.create_issue($thisRepo, issue_title, issue_body, labels: labels)
    Helper.log($log_file, "  Created issue #{issue_title} : #{new_issue.html_url}\n\n", true)
  end
  puts "\n\n"
end


def handle_large_issue_body(issue_body, max_size = 65000)
  if issue_body.size > max_size
    truncated_chars = issue_body.size - max_size
    puts "::warning:: Issue body exceeds the maximum size of #{max_size} characters. Truncating #{truncated_chars} characters..."
    truncated_body = issue_body[0...(max_size - 30)] + "..."

    return truncated_body
  end

  return issue_body
end

#
## for a given BB project, call the API to get a list of all the Repos
#
def get_all_repos_for_project(project_data)
  Helper.log($log_file, "Retrieving repos for project: #{project_data['project-key']}", true, true)

  repos = []
  start = 0
  limit = 25
  is_last_page = false

  begin
    until is_last_page
      data = BbsApi.get("/rest/api/1.0/projects/#{project_data['project-key']}/repos?start=#{start}&limit=#{limit}")
      repos += data["values"]
      is_last_page = data["isLastPage"]
      start += limit
    end # end of until
  rescue StandardError => e
    if e.message.include?("No project with key") || e.message.include?("Resource has moved")
      Helper.log_type($log_file, "WARNING: Project '#{project_data['project-key']}' does not exist or has moved. Skipping...", true, Helper::WARNING)
      Helper.log_type($log_file, "URL = /rest/api/1.0/projects/#{project_data['project-key']}/repos?start=#{start}&limit=#{limit}", true, Helper::WARNING)
    else
      puts "caught error in get_all_repos_for_project, reraising Error: #{e.message}"

      # skip this project and continue with the next one
      return [] # Return empty array to avoid processing any repos for this project
      # raise # Re-raise other exceptions
    end # end of if
  end   # end of begin

  repos.shuffle
end # end of get_all_repos_for_project

# This method processes command-line arguments and sets up global variables
# for use in the script. It uses the OptionParser library to define and parse
# the available options. The following options are supported:
#
# -o, --org ORG
#   Specifies the GitHub organization. If not provided, it attempts to use
#   the GITHUB_ORG environment variable.
#
# -r, --repo REPO
#   Specifies the GitHub repository. If not provided, it attempts to use
#   the GITHUB_REPO environment variable.
#
# -f, --mapping-file MAPPING_FILE
#   Specifies the path to the Bitbucket Project -> GitHub Organization mapping file.
#   Defaults to "./output/bitbucket_projects_mapping.csv" if not provided.
#
# -k, --bbkey BB_KEY
#   Specifies the Bitbucket project key to process. This is stored in the global
#   variable `$bb_key` and a message is printed to indicate the project being processed.
#
# -f, --file FILE
#   Specifies the path to an input file in the output directory. This is stored in
#   the global variable `$input_file` and a message is printed to indicate the file
#   being processed.
#
# --mode MODE
#   Specifies the mode of operation: 'create' or 'refresh'. Defaults to 'create'.
#
# -h, --help
#   Prints the help message and exits the script.
#
# The method also validates the presence of required arguments such as the GitHub
# organization and repository. If these are missing, it prints an error message
# and terminates the script.
#
# Global variables set by this method:
# - $gh_org: The GitHub organization.
# - $gh_repo: The GitHub repository.
# - $gh_token: The GitHub token, retrieved from the GITHUB_TOKEN environment variable.
# - $map_file: The path to the mapping file.
# - $bb_key: The Bitbucket project key to process.
# - $input_file: The path to the input file.
def process_args
  options = {}
  OptionParser.new do |opts|
    opts.banner = "Usage: createGHIssuesForBBProjects.rb [options]"

    opts.on("-o", "--org ORG", "GitHub organization") do |org|
      options[:org] = org
    end
    opts.on("-r", "--repo REPO", "GitHub repository") do |repo|
      options[:repo] = repo
    end
    opts.on("-f", "--mapping-file MAPPING_FILE", "Path to BB Project -> GH Org mapping file") do |map_file|
      options[:map_file] = map_file
    end
    opts.on("-i", "--ignore-file IGNORE_FILE", "Path to file with projects to ignore") do |ignore_file|
      options[:ignore_file] = ignore_file
    end
    opts.on("-k", "--bbkey BB_KEY", "Bitbucket project key to process") do |bb_key|
      $bb_key = bb_key
      Helper.log($log_file, "Processing Bitbucket project with key: #{bb_key}", true)
    end
    opts.on("-b", "--bbrepo BB_REPO", "Bitbucket project key to process") do |bb_repo|
      $bb_repo = bb_repo
      Helper.log($log_file, "Processing Bitbucket repository: #{bb_repo}", true)
    end
    opts.on("-p", "--project-file FILE", "Path to input file in the output directory") do |file|
      $input_file = file
      Helper.log($log_file, "Processing Bitbucket projects listed in file: #{file}", true) # Ensure the file name is printed
    end
    opts.on("--mode MODE", "Mode of operation: 'create' or 'refresh'") do |mode|
      $mode = mode.downcase
      unless %w[create refresh].include?($mode)
        Helper.log_type($log_file, "Invalid mode: #{$mode}. Allowed values are 'create' or 'refresh'.", true, Helper::ERROR)
        abort
      end
      Helper.log($log_file, "Mode set to: #{$mode}", true)
    end
    opts.on("-h", "--help", "Prints this help") do
      puts opts
      abort
    end
  end.parse! # end of OptionParser.new

  $gh_org = options[:org] || ENV["GITHUB_ORG"] # Get GitHub organization from command-line argument or environment variable
  $gh_repo = options[:repo] || ENV["GITHUB_REPO"] # Get GitHub repository from command-line argument or environment variable

  $gh_token = ENV["GITHUB_TOKEN"] # Get GitHub token from environment variable. Handy for runing local. if empty, helper creates from GitHub App

  $map_file = options[:map_file] || ENV["MAPPING_FILE"] || "./output/bitbucket_projects_mapping.csv"
  $ignore_file = options[:ignore_file] || ENV["IGNORE_FILE"] || "./output/projects_to_ignore.txt"

  if $bb_key
    Helper.log($log_file, "Processing only the specified Bitbucket project key: #{$bb_key}", true)

    if $bb_repo
      Helper.log($log_file, "Processing only the specified Bitbucket repository: #{$bb_repo}", true)
    end
  else
    if ARGV.empty? && $input_file.nil?
      # $input_file = "default_project_list.txt"
      # Helper.log($log_file, "No arguments passed. Using default project file: #{$input_file}", true)
      Helper.log($log_file, "No arguments passed - not filtering by file.", true)
    end
  end

  if $gh_org.nil? || $gh_org.empty?
    Helper.log_type($log_file,
      "GitHub organization is missing. Please set the GITHUB_ORG environment variable, or pass in with --org.",
      true,
      Helper::ERROR)
    abort
  end

  return unless $gh_repo.nil? || $gh_repo.empty?

  Helper.log_type($log_file,
    "GitHub repository is missing. Please set the GITHUB_REPO environment variable, or pass in with --repo.",
    true,
    Helper::ERROR)
  abort
end # end of process_args method

def load_excluded_repos
  File.exist?("output/excluded_repos.txt") \
    ? File.readlines("output/excluded_repos.txt", chomp: true)
           .map { |line| line.split("#").first.strip } # Ignore everything after '#'
           .reject(&:empty?)
           .map(&:downcase) \
    : []
end # end of load_excluded_repos

# Processes a project by retrieving its repositories and creating GitHub issues for them.
#
# @param project_row [Hash] A hash containing project details, including the 'project-key'.
# @note Limits the number of repositories processed to a predefined maximum.
#       Outputs progress and details to the console.
def process_project(project_row)

  Helper.log($log_file, "\n\n:::::: Processing project: #{project_row['project-key']}", true)
  repos = get_all_repos_for_project(project_row)

  if repos.length > $max_repos_to_process
    Helper.log_type($log_file,
      "NOTE: Limiting processing to the first #{$max_repos_to_process} repositories out of #{repos.length}. This limit is set by the MAX_REPOS_TO_PROCESS environment variable or defaults to 10,000.",
      true,
      Helper::WARNING)

    repos = repos.first($max_repos_to_process)
  end

  repos.each do |repo|
    repo_full_name = "#{project_row['project-key']}/#{repo['slug']}".downcase

    if $excluded_repos.include?(repo_full_name)
      Helper.log($log_file, "::warning:: Skipping excluded repository: #{repo_full_name}", true)
      next
    end

    if $bb_repo && repo["slug"].downcase != $bb_repo.downcase
      Helper.log($log_file, "::warning:: Skipping repository: #{repo_full_name} (does not match specified BB repo: #{$bb_repo})", true)
      next
    end

    # Save repo details as a JSON file in the output folder - useful if we need a json to use in a test harness but commented out until needed
    # File.open("output/#{repo['slug']}.json", "w") do |file|
    #   file.write(JSON.pretty_generate(repo))
    # end

    create_github_issue(repo, project_row)
  end
end # end of process_project method


def fetch_all_issues(repo_full)
  owner, repo_name = repo_full.split("/")

  query = <<~GRAPHQL
    query($cursor: String) {
      repository(owner: "#{owner}", name: "#{repo_name}") {
        issues(first: 100, after: $cursor, states: [OPEN]) {
          edges {
            node {
              number
              title
              labels(first: 50) {
                nodes {
                  name
                }
              }
            }
          }
          pageInfo {
            endCursor
            hasNextPage
          }
        }
      }
    }
  GRAPHQL

  issues = []
  cursor = nil
  page_count = 0

  print "Issue page indices: " # Print header for indices

  loop do
    response = execute_graphql_query(query, { cursor: cursor })
    if response.code.to_i != 200
      puts "[ERROR] GraphQL query failed with status: #{response.code}"
      puts "[ERROR] Response body: #{response.body}"
      exit(1)
    end

    result = JSON.parse(response.body)
    if result["errors"]
      puts "[ERROR] GraphQL query returned errors: #{result["errors"]}"
      exit(1)
    end

    repository_data = result.dig("data", "repository")
    if repository_data.nil?
      puts "[ERROR] No repository data found in response. Check if the org/repo is correct."
      puts "[DEBUG] Response body: #{result.inspect}"
      exit(1)
    end

    issues_data = repository_data["issues"]
    if issues_data.nil? || issues_data["edges"].empty?
      break
    end

    issues += issues_data["edges"].map { |edge| edge["node"] }
    page_count += 1
    print "#{issues.size} " # Print the cumulative count (i.e. 100, 200, ...) for each page

    page_info = issues_data["pageInfo"]
    break unless page_info["hasNextPage"]

    cursor = page_info["endCursor"]
  end # end of loop

  puts # Print newline after all indices
  issues
end # end of fetch_all_issues method

def execute_graphql_query(query, variables = {})
  uri = URI("https://api.github.com/graphql")
  token = ENV["GITHUB_TOKEN"]

  if token.nil? || token.strip.empty?
    puts "[ERROR] No GitHub token set in ENV['GITHUB_TOKEN']. Please set GITHUB_TOKEN environment variable."
    exit(1)
  end

  request = Net::HTTP::Post.new(uri)
  request["Authorization"] = "Bearer #{token}"
  request["Content-Type"] = "application/json"
  request.body = { query: query, variables: variables }.to_json

  response = Net::HTTP.start(uri.hostname, uri.port, use_ssl: true) do |http|
    http.request(request)
  end

  if response.code.to_i == 401
    puts "[ERROR] Authentication failed: Invalid GitHub token or insufficient permissions."
    puts "[DEBUG] Ensure the GH_PAT environment variable is set correctly and has the required scopes."
    exit(1)
  end

  response
end # end of execute_graphql_query method

def main
  process_args
  ExtensionManager.process_extensions # Load extensions from YAML files for client specific methods

  $thisRepo = "#{$gh_org}/#{$gh_repo}"

  # $client = Helper.setup_octokit_client(nil) # running from workflow
  $client = Helper.setup_octokit_client($gh_token)
  ENV["TZ"] = "Europe/London"
  scheduler = Rufus::Scheduler.new
  scheduler.interval "45m" do
    # $client = Helper.setup_octokit_client(nil) # running from workflow
    $client = Helper.setup_octokit_client($gh_token) # running local
  end # end of scheduler


  $excluded_repos = load_excluded_repos # Load excluded repositories once
  puts "\n\n:: warning :: Excluded Repositories: #{$excluded_repos.join(', ')}\n\n"

  bb_projects = []

  if $input_file && !$input_file.strip.empty?
    # Read the input file and collect BB project names
    file_path = File.join("output", $input_file)

    unless File.exist?(file_path)
      Helper.log_type($log_file, "Error: File '#{$input_file}' does not exist in the output directory.", true, Helper::ERROR)
      return
    end

    puts "Reading projects from: #{file_path}"

    File.foreach(file_path) do |line|
      line.strip!
      next if line.empty? || line.start_with?("#")

      Helper.log($log_file, "Adding Project: #{line} from file: #{file_path}", true)
      bb_projects << line.downcase
    end # end of File.foreach
  end   # end of if

  puts "Getting Open issues for #{$thisRepo} -- this could take several minutes..."
  # $open_issues = fetch_all_issues($thisRepo)
  $open_issues = $client.list_issues($thisRepo, state: "open")

  ### we dont ignore projects anymore - except for DCSM
  # ignored_projects = File.exist?($ignore_file) \
  #   ? File.readlines($ignore_file, chomp: true).map(&:strip).reject(&:empty?).map(&:downcase) \
  #   : []

  # add dcsm to list of ignored projects
  ignored_projects = []
  ignored_projects << "dcsm"

  processed_any = false

  # Read the CSV file and filter based on BB project names
  CSV.foreach($map_file, headers: true) do |project_row|
    project_key = project_row["project-key"].to_s.strip.downcase

    # Skip blank lines, or rows where all fields are nil/empty
    # next if project_row.to_s.strip.empty? || project_row.to_s.strip.start_with?("#") || project_row.to_h.values.all?(&:nil?) # lines starting with #,
    # we will process lines starting with # - the code line above is commented out
    next if project_row.to_s.strip.empty? || project_row.to_h.values.all?(&:nil?)

    # If a specific BB key is provided, skip rows that don't match (case-insensitive)
    next if $bb_key && project_key != $bb_key.to_s.downcase

    # If an input file is provided, filter rows based on BB project names (case-insensitive)
    next if $input_file && !bb_projects.include?(project_key)

    if ignored_projects.include?(project_key)
      Helper.log_type($log_file, "Project '#{project_key}' is on the ignored list. Skipping...", true, Helper::WARNING)
      next
    end

    process_project(project_row)
    processed_any = true
  end # end of CSV.foreach

  unless processed_any
    key_info = $bb_key ? "Project key: #{$bb_key}" : ($input_file ? "Project(s) from file: #{$input_file}" : "No project key or input file specified")
    Helper.log_type($log_file, "\n\nERROR: No projects were processed. Check to ensure '#{key_info}' is in #{$map_file}\n\n", true, Helper::ERROR)
  end

  Helper.log($log_file, "Script ended at #{Time.now.getlocal('-05:00').strftime('%Y-%m-%d %H:%M:%S')}\n###############\n", false)
end # end of main

main
