# frozen_string_literal: true

require "base64"
require "concurrent"
require "shellwords" # Add this line to load the Shellwords module
require "fileutils" # Add this to handle folder operations
require "open3"
require_relative "../lib/helpers"
require_relative "../lib/extension_manager"
require_relative "./bbs_api_helper"


def sanitize_filename(filename)
  # Replace invalid characters with underscores
  filename.gsub(/[<>:"\/\\|?*]/, "_")
end

def prepare_repos_folder
  repos_folder = File.join(Dir.pwd, "_repos")

  # Ensure the folder exists
  FileUtils.mkdir_p(repos_folder)
  # puts "Prepared _repos folder at: #{repos_folder}" # Debugging output

  # Clear the folder before each run
  FileUtils.rm_rf(Dir.glob("#{repos_folder}/*"))
  # puts "Cleared _repos folder." # Debugging output

  repos_folder
end

def get_pr_metadata(repo)
  puts "Retreiving metadata for repository '#{repo['slug']}'..."

  pr_data = []
  start = 0
  limit = 50

  loop do
    data = BbsApi.get("/rest/api/1.0/projects/#{repo['project']['key']}/repos/#{repo['slug']}/pull-requests?withAttributes=false&withProperties=false&state=all&start=#{start}&limit=#{limit}")
    pr_data += data["values"]
    break unless data["isLastPage"] == false

    start += limit
  end

  pr_count = pr_data.length

  ranges = {
    (0...100)    => "recordcount-small",
    (101...500)  => "recordcount-medium",
    (501...5000) => "recordcount-large"
  }.freeze

  count_label = ranges.find { |range, _| range.include?(pr_count) }&.last || "recordcount-verylarge"

  issue_body_string = <<~MARKDOWN
    | Pull Requests: #{pr_count} |
    | --------------------- |
  MARKDOWN

  {
    issue_body: issue_body_string,
    labels: [count_label]
  }
end

def get_general_metadata(repo)
  error_labels = [] # Track error labels

  # Get default branch...
  begin
    data = BbsApi.get("/rest/api/1.0/projects/#{repo['project']['key']}/repos/#{repo['slug']}/branches/default")
    default_branch = data["displayId"]
    last_commit_default_branch = data["lastCommit"]

    # Get default branch last commit date...
    data = BbsApi.get("/rest/api/1.0/projects/#{repo['project']['key']}/repos/#{repo['slug']}/commits/#{last_commit_default_branch}")
    last_commit_default_branch_timestamp = data["values"][0]["authorTimestamp"]
    last_commit_default_branch_date = Time.at(last_commit_default_branch_timestamp / 1000)
  rescue StandardError => e
    puts "Error: Failed to retrieve default branch metadata. Details: '#{e.message}'"
    default_branch = "The default branch is set to a value that does not exist. Configure the default branch in the repository settings."
    last_commit_default_branch = Time.at(0) # Default to epoch time
    last_commit_default_branch_date = Time.at(0) # Default to epoch time
    last_commit_date = Time.at(0) # Default to epoch time
    error_labels << "error-missing-default-branch"
  end

  # Get most recently changed branch
  # puts "  Getting most recently changed branch..."
  begin
    data = BbsApi.get("/rest/api/1.0/projects/#{repo['project']['key']}/repos/#{repo['slug']}/branches?orderBy=MODIFICATION&limit=1")
    last_commit = data["values"][0]["lastCommit"]
  rescue StandardError => e
    puts "Error: Failed to retrieve most recently changed branch metadata. Details: #{e.message}"
    last_commit = "unknown" # Set a default value to avoid nil errors
    error_labels << "error-missing-default-branch"
  end

  # Get most recently changed branch last commit date...
  # puts "  Getting most recently changed branch last commit date..."
  begin
    data = BbsApi.get("/rest/api/1.0/projects/#{repo['project']['key']}/repos/#{repo['slug']}/commits/#{last_commit}")
    last_commit_timestamp = data["values"][0]["authorTimestamp"]
    last_commit_date = Time.at(last_commit_timestamp / 1000)
  rescue StandardError => e
    puts "Error: Failed to retrieve last commit metadata. Details: #{e.message}"
    last_commit_timestamp = 0 # Default to epoch time
    last_commit_date = Time.at(0) # Default to epoch time
    error_labels << "error-missing-default-branch"
  end

  updated_timespan = Time.now - last_commit_date

  one_month = 30 * 24 * 60 * 60
  six_months = 6 * one_month
  one_year = 12 * one_month

  time_ranges = {
    (0...one_month)        => "age-month",
    (one_month...six_months) => "age-1to6-months",
    (6 * one_month...one_year) => "age-6to12-months"
  }.freeze

  updated_label = time_ranges.find { |range, _| range.include?(updated_timespan) }&.last || "age-1-year"

  # Get Repo Size...
  data = BbsApi.get("/projects/#{repo['project']['key']}/repos/#{repo['slug']}/sizes")
  repo_size_bytes = data["repository"]
  repo_size = repo_size_bytes.to_f / 1024 / 1024 # convert to MB

  size_ranges = {
    (0...100)    => "size-small",
    (101...400)  => "size-medium",
    (401...1000) => "size-large"
  }.freeze

  size_label = size_ranges.find { |range, _| range.include?(repo_size) }&.last || "size-huge"

  issue_body_string = <<~MARKDOWN
    | URL | Size | Updated | Last Commit | Default Branch |
    | --- | ---- | ------- | ----------- | -------------- |
    | <#{repo['links']['self'][0]['href']}> | #{repo_size.round(2)} MB | #{last_commit_default_branch_date.to_date} | #{last_commit_date.to_date} | #{default_branch} |
  MARKDOWN

  {
    labels: [updated_label, size_label] + error_labels,
    issue_body: issue_body_string
  }
end

def _get_large_blobs(repo)
  puts "  Scanning repository for large blobs..."

  # Thread-safe collections to hold things
  mutex = Mutex.new
  large_blobs = Concurrent::Hash.new

  # Get all revisions...
  command = "cd _repos/#{repo['slug']}.git && git rev-list --objects --all 2>NUL"
  objects = `#{command}`.force_encoding("ASCII-8BIT").encode("UTF-8", invalid: :replace, undef: :replace, replace: "?").split("\n")

  # Use a thread pool to process the objects in parallel
  puts "  Processing objects in parallel... using #{Concurrent.processor_count} threads"
  pool = Concurrent::FixedThreadPool.new([Concurrent.processor_count, 8].max)
  processed = Concurrent::AtomicFixnum.new(0)
  total = objects.length

  # Process each object in parallel
  objects.each do |object|
    pool.post do
      blob_hash, path = object.split(" ", 2)

      # Skip if no path (could be a tree or a commit)
      next unless path

      # Get blob size
      command = "cd _repos/#{repo['slug']}.git && git cat-file -s #{blob_hash}"
      blob_size_bytes = `#{command}`.strip.to_i
      blob_size_mb = blob_size_bytes.fdiv(1024**2) # convert to MB

      # Log progress...
      current = processed.increment
      if (current % 1000).zero?
        puts "  Processed #{current} of #{total} objects (#{(current.fdiv(total) * 100).round(1)}%)"
      end

      # Record large blobs
      if blob_size_mb > 99
        mutex.synchronize do
          large_blobs[blob_hash] = { blob: blob_hash, path: path, size: blob_size_mb }
        end
      end
    end
  end

  # Wait for the pool to finish...
  pool.shutdown
  pool.wait_for_termination
  puts "  Found #{large_blobs.length} large blobs"

  # For each large blob, find the initial commit
  puts "  Finding earliest commits for each large blob..."

  results = []
  large_blobs.each_with_index do |(blob_hash, blob_data), index|
    repo_path = File.join(Dir.pwd, "_repos", sanitize_filename(repo["slug"])) # Use full path to the repo
    repo_path = "#{repo_path}.git" # Append .git to the path

    puts "  Processing blob #{index + 1} of #{large_blobs.length}: #{blob_hash} - #{blob_data[:path]} (#{blob_data[:size]} MB)"
    puts blob_data

    # Check if the repo_path exists
    unless Dir.exist?(repo_path)
      puts "Error: Repository path does not exist: #{repo_path}"
      next
    end

    command = "cd #{repo_path} && git log --all --format=%H --reverse --find-object=#{blob_hash} | head -n 1"
    earliest_commit = `#{command}`.strip

    results << blob_data.merge({ commit: earliest_commit }) unless earliest_commit.empty?
  end

  puts "  Found #{results.length} large blobs with initial commits"
  results.sort_by! { |blob| -blob[:size] }

  results
end # end of _get_large_blobs

def _get_blob_metadata(repo)
  puts "Scanning repository #{repo['slug']} for large blobs..."

  large_blobs = _get_large_blobs(repo)

  blob_label = "blob-size-ok"
  issue_body_string = nil

  # If there are large blobs, create a table
  if large_blobs.any?
    issue_body_string = <<~MARKDOWN
      | Blob Hash | Initial Commit | Blob Path | Blob Size (MB) |
      | --------- | -------------- | --------- | --------------- |
      #{large_blobs.map { |blob| "| #{blob[:blob]} | #{blob[:commit]} | #{blob[:path]} | #{blob[:size]} |" }.join("\n")}
    MARKDOWN

    # If any blob is larger than 375MB, set the label to "blob-size-error"
    #   This is to avoid the 400MB limit for GitHub blobs (and adds a cushion)
    blob_label = large_blobs.any? { |blob| blob[:size] > 375 } ? "blob-size-error" : "blob-size-warning"
  end

  {
    labels: [blob_label],
    issue_body: issue_body_string.to_s
  }
end

def _get_lfs_metadata(repo)
  puts "Scanning repository #{repo['slug']} for LFS files..."

  lfs_files = []
  command = "cd _repos/#{repo['slug']}.git && git lfs ls-files -s"
  output = `#{command}`

  # output format: "{{file name}} ({{file size in MB}})"
  # split this into 2 parts - the file name and size
  # keep in mind - file names can have spaces
  output.each_line do |line|
    line = line.strip
    # Ensure the line contains the expected format before processing
    next unless line.include?(" (") && line.end_with?(")")

    file_size = line.split(" (")[1].gsub(")", "").to_f
    file_name = line.split(" (")[0]
    lfs_files.append({ file: file_name, size: file_size })
  end

  lfs_label = nil
  issue_body_string = nil

  if lfs_files.any?
    lfs_label = "lfs"
    total_lfs_size = lfs_files.sum { |file| file[:size] }

    issue_body_string = <<~MARKDOWN
      | LFS File Path | LFS File Size (MB) |
      | ------------- | ------------------ |
      #{lfs_files.map { |file| "| #{file[:file]} | #{file[:size]} |" }.join("\n")}
      | **Total LFS Size** | **#{total_lfs_size} MB** |
    MARKDOWN
  end

  {
    labels: lfs_label ? [lfs_label] : [],
    issue_body: issue_body_string.to_s
  }
end

def get_file_size_metadata(repo)
  puts "Scanning repository #{repo['slug']} for LFS files..."

  blob_metadata = _get_blob_metadata(repo)
  lfs_metadata = _get_lfs_metadata(repo)

  {
    labels: lfs_metadata[:labels] + blob_metadata[:labels],
    issue_body: "#{lfs_metadata[:issue_body]}\n\n#{blob_metadata[:issue_body]}"
  }
end

def get_webhooks_metadata(repo)
  puts "Scanning repository #{repo['slug']} for webhooks..."

  webhooks = []
  start = 0
  limit = 50
  loop do
    data = BbsApi.get("/rest/api/latest/projects/#{repo['project']['key']}/repos/#{repo['slug']}/webhooks/search?scopeType=repository&scopeType=project&limit=#{limit}&start=#{start}")
    webhooks += data["values"]
    break unless data["isLastPage"] == false

    start += limit
  end

  webhooks_label = nil
  issue_body_string = nil

  if webhooks.any?
    webhooks_label = "webhooks"
    issue_body_string = <<~MARKDOWN
      | Webhook Name | Scope | Active | URL | Events |
      | ------------ | ----- | ------ | --- | ------ |
      #{webhooks.map { |webhook| "| #{webhook['id']} (#{webhook['name']}) | #{webhook['scopeType']} | #{webhook['active']} | #{webhook['url']} | #{webhook['events'].join(', ')} |" }.join("\n")}
    MARKDOWN
  end

  {
    labels: webhooks_label ? [webhooks_label] : [],
    issue_body: issue_body_string.to_s
  }
end

def get_submodules_metadata(repo)
  puts "Scanning repository #{repo['slug']} for submodules..."

  submodules = []
  command = "git config --file .gitmodules --get-regexp url"
  output = `#{command}`

  output.each_line do |line|
    # Each line should be something like "submodule.<name>.url <url>"
    line.strip!
    submodule, submodule_url = line.split(" ", 2)
    submodule_name = submodule.split(".", 3)[1]
    submodules << { name: submodule_name, url: submodule_url }
  end

  submodules_label = nil
  issue_body_string = nil

  if submodules.any?
    submodules_label = "submodules"
    issue_body_string = <<~MARKDOWN
      | Submodule Name | URL |
      | -------------- | --- |
      #{submodules.map { |sub| "| #{sub[:name]} | #{sub[:url]} |" }.join("\n")}
    MARKDOWN
  end

  {
    labels: submodules_label ? [submodules_label] : [],
    issue_body: issue_body_string.to_s
  }
end # end of get_submodules_metadata

def get_extensions_metadata(repo)
  puts " "
  puts "::: Getting extension metadata for: #{repo['slug']}"
  # puts "#{repo}"

  extensions = ExtensionManager.extensions
  results = []

  extensions.each do |ext|
    begin
      output = ExtensionManager.run_extension(ext, repo)

      results << {
        labels: output[:labels] || [],
        issue_body: output[:issue_body] || ""
      }
    rescue => e
      warn "Exception in #{ext['name']}: #{e.message}"
    end
  end

  merged_labels = results
    .flat_map { |r| Array(r[:labels]).map(&:strip) }
    .reject(&:empty?)
    .uniq

  merged_issue_body = results
    .map { |r| r[:issue_body].to_s.strip }
    .reject(&:empty?)

  return  { labels: merged_labels, issue_body: merged_issue_body }
end

# Method to truncate or split issue body if it exceeds the maximum allowed size
def handle_large_issue_body(issue_body, max_size = 65000)
  if issue_body.size > max_size
    truncated_chars = issue_body.size - max_size
    puts "::warning:: Issue body exceeds the maximum size of #{max_size} characters. Truncating #{truncated_chars} characters..."
    truncated_body = issue_body[0...(max_size - 30)] + "..." # Truncate and add ellipsis
    return truncated_body
  end # end of if block

  issue_body # Return the original body if it's within the size limit
end # end of handle_large_issue_body method



def get_metadata(repo)

  # Prepare the _repos folder
  repos_folder = prepare_repos_folder

  # Get the clone URL
  clone_url = repo["links"]["clone"].find { |link| link["name"].include?("http") }["href"]

  # Set GIT_LFS_SKIP_SMUDGE environment variable for Windows compatibility
  ENV["GIT_LFS_SKIP_SMUDGE"] = "1"

  # Construct the sanitized local directory name
  sanitized_repo_name = sanitize_filename(repo["slug"])
  repo_path = File.join(repos_folder, "#{sanitized_repo_name}.git")
  puts "\n\n::: Repo: #{repo_path} - #{Time.now}" # Debugging output with timestamp

  # Construct the git clone command
  command = %(git clone "#{clone_url}" "#{repo_path}" -c core.protectNTFS=true -c core.protectHFS=true -c http.extraHeader="Authorization: Bearer #{ENV['BB_ACCT_TOKEN']}")

  # Execute the command and capture the output
  output = %x(#{command} 2>&1)

  # puts "\n\nOutput: \n#####\n#{output}\n#####\n\n" # Debugging output

  # Check if the process status is available
  if $?
    exit_code = $?.exitstatus
  else
    puts "Error: Unable to retrieve the exit status of the last executed process."
    exit_code = -1 # Assign a default error code
  end

  if exit_code != 0
    puts "Error: Failed to clone repository '#{repo['slug']}'. Skipping..."
    return { metadata: nil, command_result: "Failed to clone repository", labels: [] }
  end

  # Check for empty repository
  if output.include?("You appear to have cloned an empty repository") || output.include?("Response Code 204")
    puts "Warning: Repository '#{repo['slug']}' is empty. Skipping..."
    # Return a metadata hash with the labels in the general section so downstream code picks them up
    metadata = {
      general: {
        labels: ["error-empty-repo", "status-do-not-migrate"], # Updated label
        issue_body: "Repository is empty or not initialized."
      },
      pull_requests: { labels: [], issue_body: "" },
      file_size: { labels: [], issue_body: "" },
      webhooks: { labels: [], issue_body: "" },
      submodules: { labels: [], issue_body: "" },
      extensions: { labels: [], issue_body: "" }
    }
    return { metadata: metadata, command_result: "Empty repository" }
  end

  # Verify the cloned repository exists
  unless Dir.exist?(repo_path)
    puts "Error: Repository path does not exist: #{repo_path}"
    return { metadata: nil, command_result: "Repository path does not exist" }
  end

  # Perform metadata analysis
  metadata = {
    general: get_general_metadata(repo),
    pull_requests: get_pr_metadata(repo),
    file_size: get_file_size_metadata(repo),
    webhooks: get_webhooks_metadata(repo),
    submodules: get_submodules_metadata(repo),
    extensions: get_extensions_metadata(repo)
  }
  puts "   extensions: get_extensions_metadata(repo)"
  puts "     #{metadata[:extensions]}"

  # Combine all issue bodies into one
  combined_issue_body = metadata.values.map { |section| section[:issue_body] }.join("\n\n")
  puts "frozen_lib.rb::get_metadata() Combined issue body size before truncation: #{combined_issue_body.size} characters"

  # Truncate the combined issue body
  processed_body = handle_large_issue_body(combined_issue_body)

  puts "Final issue body size after truncation: #{processed_body.size} characters"

  # Ensure the metadata structure is correct
  metadata[:combined_issue_body] = processed_body

  puts ":::  Metadata analysis completed for repository '#{repo['slug']}'"
  { metadata: metadata, command_result: "Metadata analysis completed successfully" }
end # end of get_metadata method
