#!/usr/bin/env bash

# This script finds new Bitbucket repositories not present in the migration Excel file.
# It runs the same logic as the GitHub Actions workflow but can be run locally.
# Usage:
#   export BB_SERVER_URL="http://your-bitbucket-server"
#   export BB_ACCT_USER="your-username"
#   export BB_ACCT_PASSWORD="your-password"
#   ./bb_bin/find-new-bitbucket-repos.sh
# Output:
#   - output/trimmed_bbs_repo_file.csv: All Bitbucket repos (trimmed)
#   - output/new_repos_not_in_excel.csv: New Bitbucket repos not in Excel

set -euo pipefail

# Check required environment variables
if [[ -z "${BB_SERVER_URL:-}" ]]; then
  echo "Please set BB_SERVER_URL: export BB_SERVER_URL=..." >&2
  exit 1
fi
if [[ -z "${BB_ACCT_USER:-}" ]]; then
  echo "Please set BB_ACCT_USER: export BB_ACCT_USER=..." >&2
  exit 1
fi
if [[ -z "${BB_ACCT_PASSWORD:-}" ]]; then
  echo "Please set BB_ACCT_PASSWORD: export BB_ACCT_PASSWORD=..." >&2
  exit 1
fi

# Optionally, set these if you want to override the default file locations
IGNORE_FILE="output/projects_to_ignore.txt"
BITBUCKET_CSV="output/trimmed_bbs_repo_file.csv"
EXCEL_FILE="output/Bitbucket GHEC Migration Calendar.xlsm"
OUTPUT_FILE="output/new_repos_not_in_excel.csv"

# Ensure output directory exists
mkdir -p output

echo "==> Running Bitbucket inventory exporter..."
ruby -e "
  require_relative './bb_bin/bbs_inventory_exporter'

  server_url = ENV['BB_SERVER_URL']
  username   = ENV['BB_ACCT_USER']
  password   = ENV['BB_ACCT_PASSWORD']

  exporter = BbsInventoryExporter.new(
    server_url: server_url,
    username: username,
    password: password,
    ignore_file: '$IGNORE_FILE',
    output_file: '$BITBUCKET_CSV'
  )
  exporter.run
"

echo "==> Comparing Bitbucket repos to Excel..."
ruby -e "
  require_relative './lib/excel_helper'
  require_relative './bb_bin/repository_comparer'

  bitbucket_csv = '$BITBUCKET_CSV'
  excel_file    = '$EXCEL_FILE'
  output_file   = '$OUTPUT_FILE'

  comparer = RepositoryComparer.new(
    bitbucket_csv: bitbucket_csv,
    excel_file: excel_file,
    output_file: output_file
  )
  comparer.run
"

echo "==> Done. Output file: $OUTPUT_FILE"
