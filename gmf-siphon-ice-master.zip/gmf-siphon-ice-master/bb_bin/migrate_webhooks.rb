# frozen_string_literal: true

require "octokit"
require "optparse"
require "base64"
require_relative "./bbs_api_helper"
require_relative "../lib/helpers"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

BITBUCKET_TO_GITHUB_EVENTS = {
  "pr:merged" => "pull_request",
  "pr:reviewer:updated" => "pull_request",
  "pr:opened" => "pull_request",
  "repo:secret_detected" => "secret_scanning_alert", # GHAS feature, smth to keep in mind
  "repo:comment:added" => "commit_comment",
  "repo:forked" => "fork",
  "repo:refs_changed" => "push",
  #"repo:comment:edited" => "commit_comment", this is not supported in GitHub
  "pr:declined" => "pull_request",
  "pr:from_ref_updated" => "pull_request",
  "pr:modified" => "pull_request",
  "pr:reviewer:needs_work" => "pull_request_review",
  "pr:reviewer:approved" => "pull_request_review",
  "repo:modified" => "repository",
  "pr:comment:added" => "pull_request_review_comment",
  "pr:reviewer:unapproved" => "pull_request_review"
}

def map_bitbucket_events_to_github(bitbucket_events)
  bitbucket_events.map { |event| BITBUCKET_TO_GITHUB_EVENTS[event] }.compact.uniq
end

def get_bitbucket_webhooks(bbs_project, bbs_repo)
  begin
    all_hooks = []
    start = 0
    limit = 50
    loop do
      data = BbsApi.get("/rest/api/latest/projects/#{bbs_project}/repos/#{bbs_repo}/webhooks/search?scopeType=repository&scopeType=project&limit=#{limit}&start=#{start}")
      all_hooks += data["values"]
      break unless data["isLastPage"] == false

      start += limit
    end
    puts "Total webhooks to be migrated: #{all_hooks.count}"
    all_hooks
  rescue StandardError => e
    puts "Error fetching Bitbucket webhooks: #{e.message}"
    []
  end
end

def map_hooks(hooks, is_dry_run)
  hooks.map do |hook|
    {
      name: hook["name"],
      options: {
        events: map_bitbucket_events_to_github(hook["events"]),
        active: is_dry_run ? false : hook["active"],
      },
      config: {
          url: hook["url"],
          content_type: "json",
          insecure_ssl: !hook["sslVerificationRequired"],
          secret: hook["configuration"]["secret"],
      }
    }
  end
end

def create_github_webhooks(hooks, gh_org, gh_repo)
  hooks.each do |payload|
    repo_full_name = "#{gh_org}/#{gh_repo}"
    begin
      client.create_hook(repo_full_name, "web", payload[:config], payload[:options])
    rescue Octokit::UnprocessableEntity => e
      if e.message.include?("Hook already exists")
        puts "Hook already exists for #{repo_full_name} with URL #{payload[:config][:url]}. Skipping..."
      else
        raise e
      end
    end
  end
end

def migrate_webhooks(migration_details, is_dry_run)
  begin
    puts "Starting the migration of webhooks..."

    bitbucket_webhooks = get_bitbucket_webhooks(migration_details[:bb_project], migration_details[:bb_repo])

    mapped_hooks = map_hooks(bitbucket_webhooks, is_dry_run)
    puts "Mapped #{mapped_hooks.count} webhooks to GitHub format."

    create_github_webhooks(mapped_hooks, migration_details[:gh_org], migration_details[:gh_repo])
    puts "Successfully finished webhooks migration."
  rescue StandardError => e
    puts "Error during webhook migration: #{e.message}"
  end
end


def parse_arguments
  options = {}
  OptionParser.new do |opts|
    opts.on("-c", "--comment COMMENT", "The comment") do |v|
      options[:comment] = v
    end
    opts.on("-b", "--body BODY", "The body") do |v|
      options[:body] = v
    end
  end.parse!

  if options[:comment].nil? || options[:comment].empty?
    puts "Error: Issue Comment must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body'"
    abort
  end

  if options[:body].nil? || options[:body].empty?
    puts "Error: Issue Body must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body'"
    abort
  end

  options
end

def main
  options = parse_arguments

  comment = Base64.decode64(options[:comment])
  body = Base64.decode64(options[:body])

  migration_details = Helper.parse_issue_body(body, comment)

  is_dry_run = comment.match?(/\/dryrun/)
  migrate_webhooks(migration_details, is_dry_run)
end

main
