# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2025-02-03
# Author: Matt Olson
#

# This script is used to set custom properties on a migrated repository.  It is called by a
# github actions workflow, triggered by a label being applied to an issue.  This script automatically
# adds custom properties to the repository so that the repository can be traced back to the original
# repository in the Bitbucket Server instance.

require "base64"
require "optparse"
require "octokit"
require "json"
require_relative "../lib/helpers"
require_relative "../lib/extension_manager"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def parse_arguments
  options = {}
  OptionParser.new do |opts|
    opts.on("-b", "--body BODY", "The body") do |v|
      options[:body] = v
    end
  end.parse!

  if options[:body].nil? || options[:body].empty?
    puts "Error: Issue body must be passed in."
    puts "Usage: ruby add_custom_properties_to_repo.rb --body 'body'"
    abort
  end

  options
end

def truncate_value(value)
  if value.length > 75
    truncated_value = value[0, 63] + " [truncated]"
    puts "Truncating Custom Properties: #{value} to: #{truncated_value}"
    truncated_value
  else
    value
  end
end # end of truncate_value method

def set_custom_properties(migration_details)
  # puts "Setting custom properties for: #{migration_details}"

  # get the repository name from the environment variable instead of the issue body since dry runs
  # have a different repository name, that is never captured in the issue body
  repo_name = "#{migration_details[:gh_org]}/#{ENV['MIGRATED_REPO_NAME']}"

  puts "\n\nRetrieving Existing custom properties for repository: #{repo_name}\n\n"

  # Convert existing_custom_properties from Sawyer resources to a hash table
  custom_properties = []
  begin
    existing_custom_properties = client.get("/repos/#{repo_name}/properties/values")
    custom_properties = existing_custom_properties.map do |property|
      {property_name: property[:property_name], value: property[:value]}
    end
  rescue
    # Ignore if there are no existing properties or mapping fails
    puts "No existing custom properties found for repository: #{repo_name}"
    custom_properties = []
  end

  # get_custom_properties_for_repo(migration_details[:bb_project], migration_details[:bb_repo])
  # if frozen_custom_properties.is_a?(Array)
  #   frozen_custom_properties.each do |new_prop|
  #     existing_index = custom_properties.index { |p| p[:property_name] == new_prop[:property_name] }
  #     if existing_index
  #       custom_properties[existing_index] = new_prop
  #     else
  #       custom_properties << new_prop
  #     end
  #   end
  # end # end of if frozen_custom_properties.is_a?(Array)

  #TODO: These are custom and require the issue body to have the proper data in it
  new_properties = [
    {property_name: "bbs-source-project-key", value: truncate_value(migration_details[:bb_project])},
    {property_name: "bbs-source-repo", value: truncate_value(migration_details[:bb_repo])},
    {property_name: "bbs-source-link", value: truncate_value(migration_details[:bb_url])},
  ]

  new_properties.each do |new_prop|
    existing_index = custom_properties.index { |p| p[:property_name] == new_prop[:property_name] }
    if existing_index
      custom_properties[existing_index] = new_prop
    else
      custom_properties << new_prop
    end
  end

  properties = {
    properties: custom_properties
  }
  puts "\n\nSetting custom properties for repository: #{repo_name}"
  puts "::::::::Properties:"
  custom_properties.each do |prop|
    puts "  :: #{prop[:property_name]}: #{prop[:value]}"
  end
  puts "::::::::\n"

  client.patch("/repos/#{repo_name}/properties/values", properties)
end # end of set_custom_properties method

def main
  options = parse_arguments
  # puts "Body: #{options[:body]}"

  issue_body = Base64.decode64(options[:body])
  migration_details = Helper.parse_issue_body(issue_body, "")
  # puts "Issue Body: #{issue_body} that can be passed into set_custom_properties method"
  set_custom_properties(migration_details)
end # end of main method

main
