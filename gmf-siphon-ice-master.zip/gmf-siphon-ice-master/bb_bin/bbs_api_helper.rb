# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz
#

# helpers.rb

require "net/http"
require "json"

module BbsApi
  def self.http = setup_bb_client

  def self.setup_bb_client
    # Define your Bitbucket server URL and credentials
    bitbucket_server_url = ENV["BB_SERVER_URL"]

    # Create a new HTTP object
    uri = URI(bitbucket_server_url)
    http = Net::HTTP.new(uri.host, uri.port)

    # Configure SSL for our API request
    if uri.scheme == "https"
      http.use_ssl = uri.scheme == "https" # Do we use SSL?
      http.verify_mode = OpenSSL::SSL::VERIFY_NONE # Ignore SSL verification
    else
      http.use_ssl = false
    end
    http
  end

  def self.get(url)
    request = Net::HTTP::Get.new(url)
    request.basic_auth(ENV["BB_ACCT_USER"], ENV["BB_ACCT_PASSWORD"])
    max_retries = 6 # Define a maximum retry limit
    retries = 0

    begin
      response = http.request(request)
      # puts "  Url: #{url}"
      if response.code == "404"
        retries += 1
        if retries <= max_retries
          sleep 2 # Wait for 2 seconds before retrying
          puts "\n  Retrying... (caught a 404 error, attempt #{retries})\n"
          raise StandardError.new("Retrying due to 404 error") # Trigger rescue for retry
        else
          puts "::error::  Max retries reached for 404 error."
          raise StandardError.new("Error - Response Code #{response.code}, Message: #{response.message}")
        end
      end
      if response.code != "200" && response.code != "201"
        puts "::error:: - response.code != 200 && response.code != 201 Response Code #{response.code} Message: #{response.message}"
        raise StandardError.new("Error - Response Code #{response.code}, Message: #{response.message}")
      end
    rescue StandardError => e
      if e.message.include?("Retrying due to 404 error")
        retry
      else
        puts "Error during GET request: #{e.message}"
        if response && response.body
          sanitized_body = response.body.gsub(/\r?\n/, " ") # Remove new lines
          puts "::error:: rescue block: Bitbucket Response: #{sanitized_body}"
        end
        raise e
      end
    end # end of begin-rescue block

    JSON.parse(response.body)
  end

  def self.put(url, body)
    request = Net::HTTP::Put.new(url)
    request.basic_auth(ENV["BB_ACCT_USER"], ENV["BB_ACCT_PASSWORD"])
    request["Content-Type"] = "application/json"
    request.body = body.to_json
    response = http.request(request)

    if response.code != "200" && response.code != "201"
      # sanitized_msg = response.message.gsub(/\r?\n/, " ") # Remove new lines
      # puts "::error:: bbs_api_helper.rb::self.put() #{sanitized_msg} - Response Code #{response.code}"
      if response.body
        sanitized_body = response.body.gsub(/\r?\n/, " ") # Remove new lines
        begin
          json_body = JSON.parse(sanitized_body)
          error_message = json_body.dig("errors", 0, "message") || "No message in response"
          puts "::error:: bbs_api_helper.rb::self.put() Bitbucket Response Message: #{error_message}"
        rescue JSON::ParserError
          puts "::error:: bbs_api_helper.rb::self.put() Bitbucket Response: #{sanitized_body}"
        end
      end
      # puts "::error:: in self.put() processing Request: #{request.body} - Response Code #{response.code}, Message: #{response.message}"
      raise StandardError.new("Error - Response Code #{response.code}, Message: #{response.message}")
    end # end of response code check

    JSON.parse(response.body)
  end
end
