# frozen_string_literal: true

require "base64"
require "optparse"
require "fileutils"
require "octokit"
require_relative "./bbs_api_helper"
require_relative "../lib/helpers"

def client
  @client ||= Helper.setup_octokit_client(ENV["GH_TOKEN"])
end

def split_and_strip(string)
  string.split(",").map { |item| item.gsub(/^::/, "").chomp }
end # end of split_and_strip

def parse_arguments
  options = {}
  OptionParser.new do |opts|
    opts.on("-c", "--comment COMMENT", "The comment") do |v|
      options[:comment] = v
    end
    opts.on("-b", "--body BODY", "The body") do |v|
      options[:body] = v
    end
  end.parse!

  if options[:comment].nil? || options[:comment].empty?
    puts "Error: Issue Comment must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body'"
    abort
  end

  if options[:body].nil? || options[:body].empty?
    puts "Error: Issue Body must be passed in."
    puts "Usage: ruby migrate_repos.rb --comment 'comment' --body 'body'"
    abort
  end

  options
end

def _get_clone_url(bbs_project, bbs_repo)
  repo = BbsApi.get("/rest/api/1.0/projects/#{bbs_project}/repos/#{bbs_repo}")

  # repo['links']['clone'] should have an entry with "name" set to "http" (or https)...  find that one.
  clone_url = repo["links"]["clone"].find { |link| link["name"].include?("http") }
  clone_url
end

def migrate_lfs(migration_details)
  # clone the repo and pull the LFS files
  clone_url = _get_clone_url(migration_details[:bb_project], migration_details[:bb_repo])
  command = "git clone #{clone_url["href"]} -c 'http.#{clone_url["href"]}.extraHeader=Authorization: Bearer #{ENV['BB_ACCT_TOKEN']}' && cd #{migration_details[:bb_repo]} && git lfs fetch --all"
  output = `#{command}`
  puts output

  # push the LFS files to the new repo
  command = <<~COMMAND
    cd #{migration_details[:bb_repo]} && \
    git remote add github https://x:#{ENV['GH_TOKEN']}@github.com/#{migration_details[:gh_org]}/#{migration_details[:gh_repo]}.git && \
    git lfs push --all github
  COMMAND

  output = `#{command}`
  puts output
end

def main
  options = parse_arguments

  comment = Base64.decode64(options[:comment])
  body = Base64.decode64(options[:body])

  migration_details = Helper.parse_issue_body(body, comment)

  migrate_lfs(migration_details)
end

main
