require "net/http"
require "uri"
require "json"
require "base64"


class BitbucketAPIClient
  attr_reader :base_url, :username, :password

  def initialize(host_url, username:, password:)
    @username = username
    @password = password
    @base_url = "#{host_url}/rest/api/latest"
  end


  def get(path, params = {}, headers = {})
    return request(:get, path, params: params, headers: headers)
  end

  def request(method, path, params: {}, body: nil, headers: {})
    accumulated = []
    start = 0

    loop do
      paged_params = params.merge({ limit: 100, start: start })
      response = raw_request(method, path, params: paged_params, body: body, headers: headers)

      if response.is_a?(Hash) && response.key?("values") && response.key?("isLastPage")
        accumulated.concat(response["values"])

        break if response["isLastPage"]
        start = response["nextPageStart"]
      else
        return response
      end
    end

    return accumulated
  end

  protected

  def raw_request(method, path, params: {}, body: nil, headers: {})
    puts "[BitbucketAPIClient] #{method.to_s.upcase} #{base_url}/#{path} params=#{params.inspect} body=#{body.inspect}"

    uri = URI.join(base_url + "/", path)
    uri.query = URI.encode_www_form(params) unless params.empty?

    http = Net::HTTP.new(uri.host, uri.port)
    http.use_ssl = uri.scheme == "https"

    klass = {
      get: Net::HTTP::Get,
      post: Net::HTTP::Post,
      put: Net::HTTP::Put,
      patch: Net::HTTP::Patch
    }[method]

    raise ArgumentError, "Unsupported HTTP method: #{method}" unless klass

    request = klass.new(uri)
    basic = Base64.strict_encode64("#{username}:#{password}")

    request["Authorization"] = "Basic #{basic}"
    request["Content-Type"] = "application/json"
    headers.each { |key, value| request[key] = value }

    request.body = JSON.dump(body) if body
    response = http.request(request)

    puts "[BitbucketAPIClient] Response: HTTP #{response.code} (#{response.message})"
    return handle_response(response)
  end

  def handle_response(response)
    case response
    when Net::HTTPSuccess
      return JSON.parse(response.body) rescue response.body
    else
      raise "Bitbucket API Error (#{response.code}): #{response.body}"
    end
  end

end
