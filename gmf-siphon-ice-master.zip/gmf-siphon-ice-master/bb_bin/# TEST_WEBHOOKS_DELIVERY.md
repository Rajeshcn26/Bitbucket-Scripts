# Bitbucket Server vs GitHub webhooks comparison

| Bitbucket Server Event   | GitHub Event                  | Explanation (Bitbucket Server)                                     | Explanation (GitHub)                                                                                                                                            |
| ------------------------ | ----------------------------- | ------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `pr:merged`              | `pull_request`                | Triggered when a pull request is merged.                           | GitHub triggers `pull_request` with `action: closed` and `merged: true`.                                                                                        |
| `pr:reviewer:updated`    | `pull_request`                | Fires when a reviewer is assigned or changed on a PR.              | GitHub includes reviewer updates within `pull_request` events.                                                                                                  |
| `pr:opened`              | `pull_request`                | Triggered when a pull request is created.                          | GitHub triggers `pull_request` with `action: opened`.                                                                                                           |
| `repo:secret_detected`   | `secret_scanning_alert`       | Bitbucket detects secrets in the repository.                       | GitHub Advanced Security (GHAS) triggers `secret_scanning_alert`.                                                                                               |
| `repo:comment:added`     | `commit_comment`              | Triggered when commit comments are added in this repository.       | GitHub triggers `commit_comment` for comments on a pull request.                                                                                                |
| `repo:forked`            | `fork`                        | Fires when a repository is forked.                                 | GitHub has a `fork` event for repository forks.                                                                                                                 |
| `repo:refs_changed`      | `push`                        | Triggered when pushes and branches or tags are created or deleted. | GitHub triggers `push` when commits are pushed to a branch.                                                                                                     |
| `pr:declined`            | `pull_request`                | Fires when a pull request is declined.                             | GitHub triggers `pull_request` with `action: closed` but does not differentiate between declined and manually closed.                                           |
| `pr:from_ref_updated`    | `pull_request`                | Fires when the source branch of a PR is updated.                   | GitHub includes this within `pull_request` updates.                                                                                                             |
| `pr:modified`            | `pull_request`                | Fires when a pull request is edited.                               | GitHub triggers `pull_request` with `action: edited`.                                                                                                           |
| `pr:reviewer:needs_work` | `pull_request_review`         | Fires when a user marks a pull request as changes requested.       | GitHub triggers `pull_request_review` with `state: changes_requested`.                                                                                          |
| `pr:reviewer:approved`   | `pull_request_review`         | Fires when a reviewer approves a PR.                               | GitHub triggers `pull_request_review` with `state: approved`.                                                                                                   |
| `repo:modified`          | `repository`                  | Fires when a user updates the **Name** of a repository.            | GitHub triggers `repository` events when there is activity relating to repositories.                                                                            |
| `pr:comment:added`       | `pull_request_review_comment` | Fires when a comment is added to a pull request.                   | GitHub triggers `pull_request_review_comment` for PR comments.                                                                                                  |
| `pr:reviewer:unapproved` | `pull_request_review`         | Fires when a user removes an approval from a pull request.         | GitHub triggers `pull_request_review` with `state: dismissed`.                                                                                                  |
| `repo:comment:edited`    | `-`                           | Fires when a user edits a comment on a commit in a repository.     | No direct equivalent. GitHub does not generate webhook events when commit comments are edited, meaning updates to commit comments are not tracked via webhooks. |

## Write code to handle webhook deliveries

[GitHub Docs: Handling webhook deliveries](https://docs.github.com/en/webhooks/using-webhooks/handling-webhook-deliveries)

In order to handle webhook deliveries, you need to write code that will:

- Initialize your server to listen for requests to your webhook URL
- Read the HTTP headers and body from the request
- Take the desired action in response to the request

Before starting your setup make sure to run those commands, so that you have the latest node version installed:

```sh
nvm install node
```

```sh
nvm use node
```

## Ruby example

For your testing project just create a new folder where you'll have your testing script and navigate to that location in your terminal to run the commands.

To use this example, you must install the `sinatra` gem in your Ruby project. For example, you can do this with `bundler`.

Run the following commands to setup your environment:

1. If you don't already have `bundler` installed, run the following command in your terminal:

   ```text
   gem install bundler
   ```

2. If you don't already have a `Gemfile` for your app, run the following command in your terminal:

   ```sh
   bundle init
   ```

3. If you don't already have a `Gemfile.lock` for your app, run the following command in your terminal:

   ```sh
   bundle install
   ```

4. Install the `sinatra` gem by running the following command in your terminal:

```sh
bundle add sinatra
```

## Ruby example: Write the code

Create a Ruby file with the following contents. Modify the code to handle the event types that your webhook is subscribed to, as well as the ping event that GitHub sends when you create a webhook. This example handles the issues, pull_request, push and ping events.

```ruby
require 'sinatra'
require 'json'

post '/webhook' do

status 202

github_event = request.env['HTTP_X_GITHUB_EVENT']

if github_event == "issues"
    data = JSON.parse(request.body.read)
    action = data['action']
    if action == "opened"
      puts "An issue was opened with this title: #{data['issue']['title']}"
    elsif action == "closed"
      puts "An issue was closed by #{data['issue']['user']['login']}"
    else
      puts "Unhandled action for the issue event: #{action}"
    end
  elsif github_event == "ping"
    puts "GitHub sent the ping event"
  elseif github_event == "push"
    puts "GitHub sent the push event"
  elsif github_event == "pull_request"
    data = JSON.parse(request.body.read)
    action = data['action']
    puts "GitHub sent the pull_request event with the following action: #{action}"
  else
    puts "Unhandled event: #{github_event}"
  end
end
```

## Ruby example: Test the code

1. Make sure that you are forwarding webhooks. To ensure that this setup will work correctly before running the script to go to the [**Setup**](#setup) section and finish all the steps.

2. Now that you're forwarding your webhooks, in a separate terminal window, run the following command to start a local server on your computer or codespace. Replace `FILE_PATH` with the path to the file where your code from the previous section is stored. Note that `PORT=3000` matches the port that you specified for the webhook forwarding in the previous step.

   ```sh
   PORT=3000 ruby FILE_NAME
   ```

   You should see output that indicates something like `Sinatra has taken the stage on 3000`.

3. Trigger your webhook. For example, if you created a repository webhook that is subscribed to the issues event, open an issue in your repository.

4. Navigate to your webhook proxy URL on `smee.io`. You should see an event that corresponds to the event that you triggered or redelivered. This indicates that GitHub successfully sent a webhook delivery to the payload URL that you specified.

5. In the terminal window where you ran `smee --url WEBHOOK_PROXY_URL --path /webhook --port 3000`, you should see something like `POST <http://127.0.0.1:3000/webhook> - 202`. This indicates that smee successfully forwarded your webhook to your local server.

## Setup

In order to test your webhook locally, you can use a webhook proxy URL to forward webhooks from GitHub to your computer or codespace. This article uses `smee.io` to provide a webhook proxy URL and forward webhooks.

### Get a webhook proxy URL

1. In your browser, navigate to [smee.io](https://smee.io).
2. Click **Start a new channel**.
3. Copy the full URL under **Webhook Proxy URL**. You will use this URL in the following setup steps.
4. Go to your GitHub repository and create a GitHub webhooks using proxy url from `smee.io` with the event you want to test.

### Forward webhooks

1. If you don't already have `smee-client` installed, run the following command in your terminal:

   ```sh
   npm install --global smee-client
   ```

2. To receive forwarded webhooks from `smee.io`, run the following command in your terminal. Replace `WEBHOOK_PROXY_URL` with your webhook proxy URL from earlier.

   ```sh
   smee --url WEBHOOK_PROXY_URL --path /webhook --port 3000
   ```

   You should see output that looks like this, where `WEBHOOK_PROXY_URL` is your webhook proxy URL:

   ```sh
   Forwarding WEBHOOK_PROXY_URL to http://127.0.0.1:3000/webhook
   Connected WEBHOOK_PROXY_URL
   ```

   If you see errors in the terminal you might be missing some gems or using a different version of some dependencies. Try running those commands:

   ```sh
   gem install rackup puma
   ```

   Note that the path is `/webhook` and the port is `3000`. You will use these values later when you write code to handle webhook deliveries.

3. Keep this running while you test out your webhook. When you want to stop forwarding webhooks, enter `Ctrl+C`.
