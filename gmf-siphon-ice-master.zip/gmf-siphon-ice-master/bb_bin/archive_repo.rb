# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz
#

# This script is executed by a GitHub Actions workflow triggered by an issue comment.
# It decodes base64 encoded inputs for the issue comment and issue body,
# verifies that the comment contains "/archive" and then parses the issue body to
# extract the Bitbucket source project key and repository slug.
# Using these details, it calls the Bitbucket API to archive the source repository.
# Usage: ruby archive_repo.rb --comment 'base64_encoded_comment' --body 'base64_encoded_body'

require "base64"
require "optparse"
require_relative "./bbs_api_helper"
require_relative "../lib/helpers"

def parse_arguments
  options = {}
  OptionParser.new do |opts|
    opts.on("-c", "--comment COMMENT", "The comment") do |v|
      options[:comment] = v
    end
    opts.on("-b", "--body BODY", "The body") do |v|
      options[:body] = v
    end
  end.parse!

  if options[:comment].nil? || options[:comment].empty?
    puts "Error: Issue Comment must be passed in."
    puts "Usage: ruby archive_repo.rb --comment 'comment' --body 'body'"
    abort
  end

  if options[:body].nil? || options[:body].empty?
    puts "Error: Issue Body must be passed in."
    puts "Usage: ruby archive_repo.rb --comment 'comment' --body 'body'"
    abort
  end

  options
end

def archive_source_repository(migration_details)
  puts "Archiving source repository: #{migration_details[:bb_project]}/#{migration_details[:bb_repo]}"
  request_body = {
    archived: true,
    forkable: false
  }

  begin
    response_data = BbsApi.put(
      "/rest/api/1.0/projects/#{migration_details[:bb_project]}/repos/#{migration_details[:bb_repo]}",
      request_body
    )
    puts "Repository archived successfully: #{response_data.inspect}"
  rescue StandardError => e
    if e.message.include?("409")
      puts "::warning:: API call to archive repository ignored: Repository already archived."
      puts "API Endpoint: /rest/api/1.0/projects/#{migration_details[:bb_project]}/repos/#{migration_details[:bb_repo]}"
    else
      puts "archive_repo.bb::archive_source_repository() Failed to archive repository: #{e.message} #{e.backtrace.join("\n")}"
      raise e # Re-raise the error to propagate it properly
    end
  end
end

def main
  options = parse_arguments

  comment    = Base64.decode64(options[:comment])
  issue_body = Base64.decode64(options[:body])

  if !comment.match?(/\/(un)?archive/)
    puts "::error:: The comment passed into this script must contain either '/archive' or '/unarchive'"
    abort
  end

  migration_details = Helper.parse_issue_body(issue_body, comment)

  archive_source_repository(migration_details)
end

if __FILE__ == $0
  main
end
