#!/usr/bin/env ruby
require "csv"
require_relative "bbs_api_client"


class BbsInventoryExporter

  def initialize(server_url:, username:, password:, ignore_file:, output_file:)
    @bbs_client = BitbucketAPIClient.new(server_url, username: username, password: password)
    @ignore_file = ignore_file
    @output_file = output_file
  end


  def run
    projects = fetch_projects
    trimmed_projects = trim_projects(project_list: projects)
    write_csv(project_list: trimmed_projects)

    puts "Done. Trimmed CSV saved to #{@output_file}"
  rescue => e
    warn "Error: #{e.message}"
    exit 1
  end

  private

  def fetch_projects
    puts "Fetching projects..."

    projects = @bbs_client.get("projects")
    return projects.map { |p| { "name" => p["name"], "key" => p["key"] } }
  end

  def trim_projects(project_list:)
    puts "Trimming #{project_list.size} projects..."

    ignore_list = File.readlines(@ignore_file).map(&:strip).reject { |l| l.empty? || l.start_with?("#") }
    return project_list.reject { |p| ignore_list.include?(p["key"].to_s.strip) }
  end

  def fetch_repositories(project_key:)
    puts "Fetching repositories for project #{project_key}..."
    return @bbs_client.get("projects/#{project_key}/repos")
  end

  def write_csv(project_list:)
    puts "Writing CSV to #{@output_file}..."

    CSV.open(@output_file, "w") do |csv|
      csv << ["project_name", "project_key", "repo_name", "repo_slug"]

      project_list.each_with_index do |project, idx|
        puts "Index: #{idx}"
        puts "Project: #{project}"

        repos = fetch_repositories(project_key: project["key"])

        repos.each do |repo|
          csv << [project["name"], project["key"], repo["name"], repo["slug"]]
        end
      end

    end
  end
end
