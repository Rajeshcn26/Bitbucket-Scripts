# frozen_string_literal: true

# copyright © Xebia. All rights reserved. No unauthorised duplication, distribution or copying.
# Date: 2024-08-26
# Author: Rich Schwarz
#
#
require "net/http"
require "json"
require "uri"
require "optparse"
require_relative "../lib/helpers"
require_relative "./bbs_api_helper"


def parse_data(project)
  output = {
    "project-id" => project["id"],
    "project-key" => project["key"],
    "project-name" => project["name"],
    "project-url" => project["links"]["self"][0]["href"],
    "github-org" => ENV["GITHUB_ORG"] || "X_SANDBOX",
    "visibility" => project["public"] ? "internal" : "private",
    "github-repo-prefix" => "#{project['key']}#{$separator}",
    "issue-user-label" => ENV["ISSUE_LABELS"]
  }

  output_values = output.values
  Helper.log($bitbucket_projects_mapping_file, output_values.join(","), true)
  output
end

def parse_args
  options = {
    separator: "."
  }

  OptionParser.new do |opts|
    opts.banner = "Usage: createBBProjects2GHOrgMappingFile.rb [options]"

    opts.on("-o", "--output-folder OUTPUT_FOLDER", "Mapping File Path (ex: ./output/)") do |output_folder|
      options[:output_folder] = output_folder
    end

    opts.on("-f", "--output-file OUTPUT_FILE",
            "Mapping File Name (ex: bitbucket_projects_mapping.csv)") do |output_file|
      options[:output_file] = output_file
    end

    opts.on("-s", "--separator SEPARATOR", "Separator between the repository prefix and name") do |separator|
      options[:separator] = separator
    end
  end.parse!

  # Set global values for output folder and file...
  # TODO - refactor to use one option containing path and file name...
  $outputFolder = options[:output_folder] || ENV["OUTPUT_FOLDER"] || "./output"
  $output_file = options[:output_file] || ENV["OUTPUT_FILE"] || "bitbucket_projects_mapping.csv"
  $bitbucket_projects_mapping_file = "#{$outputFolder}/#{$output_file}"
  $separator = options[:separator] || "_"
end

def get_bbs_projects
  page = 0
  limit = 50 # Adjust this value as per your requirement
  projects = []

  loop do
    data = BbsApi.get("/rest/api/1.0/projects?limit=#{limit}&start=#{page * limit}")
    projects.concat(data["values"])
    break unless data["isLastPage"] == false

    page += 1
  end

  # puts "Response Code: #{response.code}"
  # puts "Response Message: #{response.message}"
  project_names = projects.map { |project| project["name"] }
  puts "::: Projects :::\n#{project_names.join(', ')}\n\n"

  projects
end

def existing_project_keys(file_path)
  return [] unless File.exist?(file_path)
  keys = []
  File.foreach(file_path) do |line|
    next if line.strip.empty?
    # Remove comment marker if present
    line_content = line.sub(/^#/, "").strip
    fields = line_content.split(",")
    keys << fields[1] if fields.size > 1 # field 2 is project-key
  end
  keys
end # end of existing_project_keys method

def generate_file(projects)
  header = "project-id,project-key,project-name,project-url,github-org,visibility,github-repo-prefix,issue-user-label"
  Helper.create_output_folders($outputFolder)
  unless File.exist?($bitbucket_projects_mapping_file)
    Helper.create_output_csv_file($bitbucket_projects_mapping_file, header)
  end

  existing_keys = existing_project_keys($bitbucket_projects_mapping_file)

  File.open($bitbucket_projects_mapping_file, "a") do |file|
    projects.each do |project|
      key = project["key"]
      next if existing_keys.include?(key)
      output = [
        project["id"],
        key,
        project["name"],
        project["links"]["self"][0]["href"],
        ENV["GITHUB_ORG"] || "X_SANDBOX",
        project["public"] ? "internal" : "private",
        "#{key}#{$separator}",
        ENV["ISSUE_LABELS"]
      ]
      file.puts(output.join(","))
    end
  end
end # end of generate_file method

def main
  parse_args

  $outputFolder = "./output"

  projects = get_bbs_projects
  generate_file(projects)
end

main
