require "csv"
require_relative "../lib/excel_helper"


class RepositoryComparer

  def initialize(bitbucket_csv:, excel_file:, output_file:)
    @bitbucket_csv = bitbucket_csv
    @excel_file    = excel_file
    @output_file   = output_file
  end


  def run
    bitbucket_entries = load_bitbucket_csv
    excel_entries = load_excel_entries

    missing = bitbucket_entries - excel_entries

    if missing.any?
      puts "Found #{missing.size} new repos not in Excel."
      write_output(missing)
    else
      puts "No missing repos. Excel matches Bitbucket inventory."
    end
  end

  private

  def load_bitbucket_csv
    CSV.read(@bitbucket_csv, headers: true).map do |row|
      [
        row["project_key"].to_s.strip.downcase,
        row["repo_slug"].to_s.strip.downcase
      ]
    end
  end

  def load_excel_entries
    excel = ExcelHelper.new(@excel_file)
    excel.switch_tab("Repo Tracker")
    raw_data = excel.read_columns_by_letter(["A", "B"], start_row: 4)

    raw_data.map do |row|
      [
        row["A"].to_s.strip.downcase,
        row["B"].to_s.strip.downcase
      ]
    end
  end

  def write_output(missing)
    CSV.open(@output_file, "w") do |csv|
      csv << ["project_key", "repo_slug"]
      missing.each { |entry| csv << entry }
    end

    puts "Output written to #{@output_file}"
  end
end
