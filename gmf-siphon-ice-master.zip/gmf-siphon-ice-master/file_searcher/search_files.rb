require "pathname"
require "set"
require "parallel"
require "etc"
require_relative "../lib/log_manager"

def start_scanner(repo, keyword_file:, write_issue_body: true, issue_header: "Issue Header", default_label: nil)
  KeywordScanner.new(
    repo,
    keyword_file: keyword_file,
    write_issue_body: write_issue_body,
    issue_header: issue_header,
    default_label: default_label
  ).scan
end

class KeywordScanner
  DEFAULT_MAX_DEPTH = 5
  DEFAULT_IGNORED_FILE_NAMES = %w[log logs]
  DEFAULT_IGNORE_EXTS = %w[adoc md sql txt csv html tmp exe jar xml confluence log]
  DEFAULT_IGNORED_PATH_GLOBS = "**/log/**,**/logs/**,**/tmp/**,**/.git/**,**/bin/**,**/obj/**,**/node_modules/**"

  def initialize(repo, keyword_file:, write_issue_body:, issue_header:, default_label: nil)
    script_base = Pathname.new(__FILE__).dirname.expand_path
    keyword_file_path = script_base.join(keyword_file).expand_path

    @repo = deep_symbolize_keys(repo)
    @repo_path = script_base.join("../_repos/#{@repo[:slug]}.git").expand_path
    @ignore_exts = DEFAULT_IGNORE_EXTS
    @ignore_path_globs = DEFAULT_IGNORED_PATH_GLOBS.split(",").map(&:strip)
    @max_depth = DEFAULT_MAX_DEPTH
    @keywords_by_category = load_keywords(keyword_file_path)
    @default_label = default_label&.downcase&.gsub(/\s+/, "-")
    @write_issue_body = write_issue_body
    @issue_header = issue_header
    @verbose = true

    debug "::: Loaded Keyword Categories"
    @keywords_by_category.each do |cat, regexes|
      debug "  #{cat}: #{regexes[:patterns].map(&:inspect).join(', ')}"
    end
  end

  def scan
    debug "::: Scanning repository for files and content matching defined keyword patterns..."
    files = list_files
    mutex = Mutex.new

    @results = []

    Parallel.each(files, in_threads: Etc.nprocessors) do |file|
      next if file.count("/") > @max_depth
      next if ignore_ext?(file)
      next if ignore_path_glob?(file)
      next if ignore_filename?(file)

      result = process_file(file)
      next unless result

      mutex.synchronize { @results << result }

      result = nil
      GC.start if rand < 0.001
    end

    debug "::: Results"
    @results.each do |res|
      file = res[:file]
      categories = res[:matches]
      debug "  #{file}: #{categories.keys.join(', ')}"
    end

    format_scan_results(@results, @write_issue_body, @issue_header, @default_label)
  end

  private

  def process_file(file)
    file_results = {}
    content = nil
    content_loaded = false

    @keywords_by_category.each do |(category, type), data|
      patterns = data[:patterns]
      matched = nil

      case type
      when "file"
        matched = keyword_matches_from_filename(file, category, patterns)
      when "content"
        unless content_loaded
          content = get_file_content(file)
          content_loaded = true
        end
        next unless content

        matched = match_content_patterns(file, content, category, patterns)
      else
        warn "Unknown keyword type: #{type} in category #{category}"
      end

      matched&.each do |k, v|
        file_results[k] ||= Set.new
        file_results[k].merge(v)
      end
    end

    content = nil
    file_results.empty? ? nil : { file: file, matches: file_results.transform_values(&:to_a) }
  end

  def match_content_patterns(file, content, category, patterns)
    matched = Hash.new { |h, k| h[k] = Set.new }

    content.each_line.with_index(1) do |line, lineno|
      patterns.each do |regex|
        matched[category] << lineno if line.match?(regex)
      end
    end

    matched.empty? ? nil : matched
  end

  def list_files
    Dir.chdir(@repo_path) { Dir.glob("**/*", File::FNM_CASEFOLD).select { |f| File.file?(f) } }
  rescue => e
    puts "Exception in list_files: #{e.class} #{e.message}"
    []
  end

  def get_file_content(file)
    full_path = @repo_path.join(file)
    File.open(full_path, "r:bom|utf-8") do |f|
      f.read.encode("UTF-8", invalid: :replace, undef: :replace, replace: "")
    end
  rescue => e
    warn "Skipping unreadable file: #{file} (#{e.class}: #{e.message})"
    nil
  end

  def keyword_matches_from_filename(file, category, patterns)
    matched = Hash.new { |h, k| h[k] = Set.new }
    matched[category] << 1 if patterns.any? { |regex| file.match?(regex) }
    matched.empty? ? nil : matched
  end

  def load_keywords(file_path)
    return {} unless File.exist?(file_path)

    categories = {}
    current_category = "uncategorized"
    current_type = "content"
    buffer = []

    File.foreach(file_path) do |line|
      line = line.strip
      next if line.empty? || line.start_with?("#")

      if line.match(/^\[(.+?)\](?:\[(.+?)\])?$/)
        unless buffer.empty?
          categories[[current_category, current_type]] ||= []
          categories[[current_category, current_type]].concat(buffer)

          buffer.clear
        end

        current_category = Regexp.last_match(1)
        current_type = (Regexp.last_match(2) || "content").downcase
      else
        buffer.concat(line.split(",").map(&:strip))
      end
    end

    categories[[current_category, current_type]] ||= []
    categories[[current_category, current_type]].concat(buffer) unless buffer.empty?

    categories.transform_values do |values|
      patterns = values.map do |val|
        regex_like?(val) ? compile_regex(val) : wildcard_to_regex(val)
      end
      { patterns: patterns }
    end
  end

  def compile_regex(val)
    Regexp.new(val, Regexp::IGNORECASE | Regexp::MULTILINE)
  rescue RegexpError
    Regexp.new(Regexp.escape(val), Regexp::IGNORECASE | Regexp::MULTILINE)
  end

  def regex_like?(str)
    str.include?("\n") || str =~ /[()\[\]{}|\\.+?^$]/
  end

  def wildcard_to_regex(keyword)
    pattern = "^" + keyword.gsub(".", "\\.").gsub("*", ".*") + "$"
    Regexp.new(pattern, Regexp::IGNORECASE)
  end

  def ignore_filename?(file)
    base = File.basename(file).downcase
    DEFAULT_IGNORED_FILE_NAMES.include?(base)
  end

  def ignore_ext?(file)
    ext = File.extname(file).downcase.delete_prefix(".")
    @ignore_exts.include?(ext)
  end

  def ignore_path_glob?(file)
    @ignore_path_globs.any? do |pattern|
      File.fnmatch?(pattern, file, File::FNM_PATHNAME | File::FNM_EXTGLOB | File::FNM_CASEFOLD)
    end
  end

  def deep_symbolize_keys(obj)
    case obj
    when Hash
      obj.each_with_object({}) do |(k, v), result|
        key = k.is_a?(String) ? k.to_sym : k
        result[key] = deep_symbolize_keys(v)
      end
    when Array
      obj.map { |e| deep_symbolize_keys(e) }
    else
      obj
    end
  end

  def debug(msg)
    puts msg if @verbose
  end

  def format_scan_results(results, write_issue_body, issue_header, default_label)
    return {} if results.empty?

    keyword_categories = results.flat_map { |r| r[:matches].keys }
                                .uniq
                                .map { |cat| cat.downcase.gsub(/\s+/, "-") }
                                .sort

    project = @repo.dig(:project, :key) || "unknown"
    slug = @repo[:slug] || "unknown"

    rows = results.map do |res|
      file = res[:file]
      categories = res[:matches]
      line_numbers = categories.values.flatten.uniq.sort
      line_anchor = line_numbers.any? ? "##{line_numbers.join(',')}" : ""

      file_display = "`#{file}`"
      categories_display = categories.sort.map { |cat, lines| "#{cat} (line #{lines.sort.join(', ')})" }.join(", ")
      url = "https://stash.OWNER.net/projects/#{project}/repos/#{slug}/browse/#{file}#{line_anchor}"
      link_display = "[View File](#{url})"

      "| #{file_display} | #{categories_display} | #{link_display} |"
    end

    header = "| File | Reference Type | Link |\n|------|----------------|------|"
    issue_body = write_issue_body ? "### #{issue_header}\n\n" + ([header] + rows).join("\n") : ""

    max_chars = 60_000
    if issue_body.size > max_chars
      truncated_chars = issue_body.size - max_chars
      issue_body = issue_body[0...max_chars] + "\n\n::warning:: Truncated #{truncated_chars} characters to fit the limit."
    end

    labels = default_label.nil? || default_label.empty? ? keyword_categories : [default_label]

    { labels: labels.uniq, issue_body: issue_body }
  end
end
