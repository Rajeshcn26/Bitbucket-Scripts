# File Searcher

This module provides functionality to scan a code repository for files and content that match specified keywords or patterns. It is designed to help identify files of interest, such as those containing sensitive information, deprecated code, or other custom-defined patterns.

## Features

- Scans files in a repository up to a configurable depth.
- Supports keyword matching by filename or file content.
- Allows definition of keyword categories and types (filename or content).
- Ignores files by extension and path patterns (e.g., logs, binaries, node_modules).
- Parallel processing for faster scanning.
- Outputs results in a format suitable for issue creation or reporting.

## Usage

1. **Prepare a keyword file**
   Define your keywords and categories in a text file. The first category will be the label returned if a match if found unless overridden. The second category is the scan type. full regex is supposed to the best of Ruby's abilities, which isn't much.

   Scan Types supported:

   - Content: will scan the content of all files x levels deep
   - File: is a filename or extension

   Example format:

   ```
   [Sensitive][content]
   password, secret, api_key

   [Deprecated][file]
   *.bak, *.old
   ```

2. **Call the scanner**  
   Use the `start_scanner` method from `search_files.rb`:

   ```ruby
   require_relative "file_searcher/search_files"

   repo = { slug: "my-repo", project: { key: "PROJ" } }
   result = start_scanner(repo, keyword_file: "keywords.txt")
   puts result[:issue_body]
   ```

3. **Result**  
   The scanner returns a hash with:
   - `:labels` — Array of detected keyword categories.
   - `:issue_body` — Markdown table summarizing findings.

## Configuration

- **Ignored Extensions:**  
  By default: `adoc`, `md`, `sql`, `txt`, `csv`, `html`, `tmp`, `exe`, `jar`
- **Ignored Paths:**  
  By default: `logs`, `tmp`, `.git`, `bin`, `obj`, `node_modules`
- **Max Depth:**  
  By default: 5 directory levels

## Notes

- The repository should be cloned under `_repos/<slug>.git` relative to this script.
- The scanner is intended for internal use and may require adaptation for other environments.

## License

See project-level LCLDNSE file.
